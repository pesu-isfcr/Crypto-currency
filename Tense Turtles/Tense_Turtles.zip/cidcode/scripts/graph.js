
let jsonList = {
	"1NDyJtNTjmwk5xPNhjgAMu4HDHigtobu1s": {
		"Name": "Binance"
	},
	"bc1qdsrqvzfh2s330ggf7n9l86xkmxcjah3rhxu4k4": {
		"Name": "Binance"
	},
	"bc1qvgv6e8jrp4ratrsudf7zv4ldq8gct88rjxt2g4": {
		"Name": "Binance"
	},
	"bc1qaq4v5wfffquvcmj4he3786ex5vtxnt9p3p9kdu": {
		"Name": "Binance"
	},
	"bc1qaeav2hk5u2yn73st0fqkxp6zedefld6vyf04hz": {
		"Name": "Binance"
	},
	"bc1quvzhed9dk6hh8y86kjptswwm32304jchps7xwr": {
		"Name": "Binance"
	},
	"bc1qkcwwnsjtfp4snqyytxayjp9lctmj9z3ntcxaka": {
		"Name": "Binance"
	},
	"bc1q9um04kmt2ej5svsep9a7akvnckx3h6t3yqn8lh": {
		"Name": "Binance"
	},
	"bc1q3gvwrz86ull0p9hjs5k8sza3fpgfhsxhhz830x": {
		"Name": "Binance"
	},
	"bc1q4s0s7anxtydjmarh30p3xenm03h3c6k6qq7yzw": {
		"Name": "Binance"
	},
	"bc1q2r3snw3hyj9c6pc8ec5367dnfhhqzcy44jv9xs": {
		"Name": "Binance"
	},
	"bc1qe492vdgzwmlpgffgjjqgevwdf2ew257wqyex4s": {
		"Name": "Binance"
	},
	"bc1qqewsrjuue4kw9nkzff5v8fdd9qdc0cg3jllv6l": {
		"Name": "Binance"
	},
	"bc1qp2tm408z8mcdndw738mkyvudrspc5z56z29667": {
		"Name": "Binance"
	},
	"bc1q7vcewmnn0dh3kwkv2m3n6skrhmf60ch4e0j7ka": {
		"Name": "Binance"
	},
	"bc1q3h3yd4nuq3mgkdx38hephtqj5s84akl3emq9np": {
		"Name": "Binance"
	},
	"bc1q57z0d30nazzc84khpj69x4ajulv674sj2g9xjl": {
		"Name": "Binance"
	},
	"bc1qhf64z522aqc2mch79y3g74sc9yt5qzey7u0g4k": {
		"Name": "Binance"
	},
	"bc1qvk3rkrjepztn0ctk56n6gynjy7ysyx33hptdxx": {
		"Name": "Binance"
	},
	"bc1q5s20mf5pj650dha28xngphq054ntxr4emqcqdg": {
		"Name": "Binance"
	},
	"bc1qdeu46k8hdg90ely7rgu69jkkhudwhmr26jgvde": {
		"Name": "Binance"
	},
	"bc1qjs8zg53hdyxd87q6pna9tdujapng44dkvezmp6": {
		"Name": "Binance"
	},
	"bc1qtaey3dn46n40vlarfzecjctsgah3qe7dj64szl": {
		"Name": "Binance"
	},
	"bc1qky0qpy7wnjp0k2v8zcrrvu0xnfpfrwdmx6vzpr": {
		"Name": "Binance"
	},
	"bc1ql42rmpvvq488tkqxvg8wmaa7j3jsrkxgnm8cy6": {
		"Name": "Binance"
	},
	"bc1qrqlasfl7xd2fmn3ws60jux3d45qn6wn04zg8fn": {
		"Name": "Binance"
	},
	"bc1q4dwch4fdvm80gtl3qeyen4u045gvkhzm63xkph": {
		"Name": "Binance"
	},
	"bc1qx3k93wzhypnxdhqev2ny0luz9jgtmg9wtlcuu4": {
		"Name": "Binance"
	},
	"bc1qkawz79pqpqxushk9y6sm7s3tlvhzaphrzmgake": {
		"Name": "Binance"
	},
	"bc1qfj5y20npey9eetya0dtl7999nxmsw8dcll5wzz": {
		"Name": "Binance"
	},
	"bc1qqun8lw74peex5earja2z2p08kkpnxg7xasagtl": {
		"Name": "Binance"
	},
	"bc1qka7eafakws6ngn0xura6mh4qvasa2wm5rvfmvv": {
		"Name": "Binance"
	},
	"bc1qvwuwy4sryvxdvrmjmg2l0vzas3ulq0u8fhxaka": {
		"Name": "Binance"
	},
	"bc1qgf0v6pkx43487a7w85n6sek35kpa8qv5auq9zx": {
		"Name": "Binance"
	},
	"bc1q93xsn520w7mmeupse4zede6n8w0n2j5vavp2hv": {
		"Name": "Binance"
	},
	"bc1q55kfgpkuycs6vl7ds0h20uupcv0gqala5c7ccz": {
		"Name": "Binance"
	},
	"bc1qxn7t6cakz5pccpxfylvx8vpnelwrcnv3uk5gp0": {
		"Name": "Binance"
	},
	"bc1qxkvkeyqngzv6xxyqt8qtdqahahc7l6cgn8vkca": {
		"Name": "Binance"
	},
	"bc1qd7ezu7jzq0zg87tnxy49p4wluxyuk5sknk0dq0": {
		"Name": "Binance"
	},
	"bc1q5cttlkm2dv6cxjsp364h2nn6cg372qgnyn9hum": {
		"Name": "Binance"
	},
	"bc1qmvjfxq0qq9rvfmcwfeqvmm9d9ghjp340klyzu5": {
		"Name": "Binance"
	},
	"bc1qh6jaracpxnap0559xrs7h9d5yp04fg8s9vhhu2": {
		"Name": "Binance"
	},
	"bc1qvx8q0yw4gufy9559e9v6q0udqkucfkpfl6rspr": {
		"Name": "Binance"
	},
	"bc1qwdcgc9eqag7rjvkcs0rql8pk6eu074h5e2rkat": {
		"Name": "Binance"
	},
	"bc1q858p27enlk68gyeemhlku0nn5u4atvqye9hj6x": {
		"Name": "Binance"
	},
	"bc1q2g0erlkvt93ftkxredq800y8p26xwtz3ft0zya": {
		"Name": "Binance"
	},
	"bc1qn0ddvc0um290y9g75880x8etm2r9qt8p7a09yw": {
		"Name": "Binance"
	},
	"bc1qxh2kuuswt952cxrd9sj82r2s97fpmff4pm7jwv": {
		"Name": "Binance"
	},
	"bc1qld3779yth832ny4g33ugt69ehc4rt85d6mrj39": {
		"Name": "Binance"
	},
	"bc1qurfpglnfy9q8vf3a7ykusnz8pwakfk3edtqkr9": {
		"Name": "Binance"
	},
	"bc1qnccqdf75pvzs3vv55aefpjh0mxtulk9upg372d": {
		"Name": "Binance"
	},
	"bc1q22hk8d84tepl5rzeg36z0687yxwe82m06qz9x4": {
		"Name": "Binance"
	},
	"bc1qyxzuhmxmg30yscttnkdkzt3jyyj9u8tlex746t": {
		"Name": "Binance"
	},
	"bc1qkkc3mucef3sya35nfyexwhqn5har93q7jck3qs": {
		"Name": "Binance"
	},
	"bc1qrjwar4knzv9jfrcs9jgxa4ytvgmsj6yppg7yht": {
		"Name": "Binance"
	},
	"bc1q6kut773rv6ru7428gaa4tzvyu90c94re9qfkg4": {
		"Name": "Binance"
	},
	"bc1q5xp4nv8hs45vz6cucmy4l2ytl749javppen46g": {
		"Name": "Binance"
	},
	"bc1qdkjg4h0ldxuree74uw6juccsv6w3uhuz959a8a": {
		"Name": "Binance"
	},
	"bc1q3wwhf0rnpd8m26ppfphyv88aum3d88ham6y4hq": {
		"Name": "Binance"
	},
	"bc1qk3kjt6wu4e89758xek8st5xyujc8jjdur6dpnc": {
		"Name": "Binance"
	},
	"bc1q9edkz505kk53w8v59n3qc4z0dq72g607tguj77": {
		"Name": "Binance"
	},
	"bc1qv5mkwef88lnjhp8zkkaul438hrur4mz9lfah9q": {
		"Name": "Binance"
	},
	"bc1qe6wdj4yqaf6vpuh9pupsh8lll3asnh3vyc4cqr": {
		"Name": "Binance"
	},
	"bc1quqjvpeuuvmf8q6nx7h6087r8cffxwr5w4s5vfv": {
		"Name": "Binance"
	},
	"bc1qrxh62n4n223825uwzyfhd2un6v95utdxv2mqtw": {
		"Name": "Binance"
	},
	"bc1q69c38c7vp6rzte60zxzxxs9sjyadjql06d750r": {
		"Name": "Binance"
	},
	"bc1q3cjvrzuw3e2pn9c47vk0myh50jm9vaxdptgdh6": {
		"Name": "Binance"
	},
	"bc1qdsvsnkklujzc3yypmdzjlz4luzxky73sxd3z47": {
		"Name": "Binance"
	},
	"bc1q8k5u74rcmfj7hqf9p00wlll0kvl7czx8lv04d8": {
		"Name": "Binance"
	},
	"bc1qzp47r6dtymluh9yj6g5pxlew3e2x0ce9er604z": {
		"Name": "Binance"
	},
	"bc1qec7prul3z72n7pr9yh7mdkdhyzjzufpfjnfdf2": {
		"Name": "Binance"
	},
	"bc1qelhymna82sdw5ku0acr8lz725y3avmuxup6t57": {
		"Name": "Binance"
	},
	"bc1qtu4zqemzmz4v70a0ldxaqvjuntfawcvrq0wv0p": {
		"Name": "Binance"
	},
	"bc1qm2pdc4y928yjuah8aw3ctddj526v57jzerrsu8": {
		"Name": "Binance"
	},
	"bc1q8xgduykwlueqz3aluc8tk53x6hqp5jz0uvevpn": {
		"Name": "Binance"
	},
	"bc1q0k4txl9sdq9q6e99l2lg7duzl9mvrcylcj3q23": {
		"Name": "Binance"
	},
	"bc1qmdr3j5pen9u4rp2pz7njp7twzq6l6knnmk7qdl": {
		"Name": "Binance"
	},
	"bc1qtcmpm3p4gkcr7hs4la4c2f2cc6zqtnkeseaexm": {
		"Name": "Binance"
	},
	"bc1qvmyjmkp4k7vguy5t2gsnq9nrwzmmyryv7grzsf": {
		"Name": "Binance"
	},
	"bc1qjaft297lglw3u7acyhr07p5xurfyk66kfhx2th": {
		"Name": "Binance"
	},
	"bc1qgs4guj6f6qd8y86s7fcxrjwlata8r7j97mqgj3": {
		"Name": "Binance"
	},
	"bc1qeg5uxhzlg0t3t23lh4n3ydxh9kz5lx6kln5w8r": {
		"Name": "Binance"
	},
	"bc1qfzca0kmfsmcga98fcruk3sn5ep4phe7cxkeqnu": {
		"Name": "Binance"
	},
	"bc1qu30th5d6p0ktvgqlxv78yz6tv6euwqped6au8s": {
		"Name": "Binance"
	},
	"bc1qyzdw0tw84enk93yw7pz3m2u0fjxl9dp6v8klcd": {
		"Name": "Binance"
	},
	"bc1qtvj9lejajxwa8u7034036qruqmd4vdl8fa0ql0": {
		"Name": "Binance"
	},
	"bc1qf6f2ydl8dm0dwvpns0wfjvn2vzevykyequuf8r": {
		"Name": "Binance"
	},
	"bc1qnmyu4v3zffefghgx3k62aldmtqtlzdn7vz93yd": {
		"Name": "Binance"
	},
	"bc1qq68e6f0c9rda5a76h3d4r6mrxcnxny6kg8p7tt": {
		"Name": "Binance"
	},
	"bc1q59scxc9xzcq48vaplvene5vrednsvex96l6u9s": {
		"Name": "Binance"
	},
	"bc1q5qftr6ej264ey2srky006kx62wfjlaj0qnahf4": {
		"Name": "Binance"
	},
	"bc1q8t30r89j5eav8vx9w3rumqwmc8drsz00lnxxa2": {
		"Name": "Binance"
	},
	"bc1qde85knpn9p937u5d82s4mzckva5emrqu2gukn3": {
		"Name": "Binance"
	},
	"bc1qupr2e3npjwh0khv93gqc49qlsgdycrr92c6a4p": {
		"Name": "Binance"
	},
	"bc1q2n9y04g8an9t8wycptv0kajnt7zzcqhqfy9g0m": {
		"Name": "Binance"
	},
	"bc1q4meds6dupclcv3tksplzsf809rcxm6snlc232k": {
		"Name": "Binance"
	},
	"bc1q7usxuxuclzu5qp9thv8x88506xh8hrfc4qft2c": {
		"Name": "Binance"
	},
	"bc1q7z5ta9jqyyjdm0nfngwejeemst0yrhqwsrs7yn": {
		"Name": "Binance"
	},
	"bc1qd4revpqput9hp98083zqsq6dvhkhenzyl9jnjd": {
		"Name": "Binance"
	},
	"bc1qvfag9anytjyl8s66ed6g49aw6s79lzn30u46vt": {
		"Name": "Binance"
	},
	"address": {
		"Name": "Name"
	},
	"1EWLPzDyoe6gKv1S3jgW4BpcvRAqYbjyJw": {
		"Name": "Bitcoin.de"
	},
	"143iJ6gqQ9MMbXWRqKVNXhxXm2a8yUmQqd": {
		"Name": "Bitcoin.de"
	},
	"1F2maxS8Vg33boq2QHrVMGWMpoBmmLceV2": {
		"Name": "Bitcoin.de"
	},
	"1L3VrHjM5Z6FCg197vPtvDojF47LR6wxnh": {
		"Name": "Bitcoin.de"
	},
	"17rZJX1iy4vtZu8UjJLFSfzL678bBtKyas": {
		"Name": "Bitcoin.de"
	},
	"3PYA4pLLKmBC8Dq9bHsoA4U1JWqH57mFR8": {
		"Name": "Bitcoin.de"
	},
	"1ExEsDL28zSEpez55iU9xjCm6ye2US19PG": {
		"Name": "Bitcoin.de"
	},
	"3MNAYL5w5SRUPid6K5XJnCPvzNKCwyCCp3": {
		"Name": "Bitcoin.de"
	},
	"1GMQEF9k53Lws7Ke1ef44nGaJmNNH1CpFT": {
		"Name": "Bitcoin.de"
	},
	"3Ds8FFifQxJpYuM3zcTGGEuqwqAba3e6yZ": {
		"Name": "Bitcoin.de"
	},
	"3NwkApweoZ4AyYeetZNWTnhvMsbf5rkjK9": {
		"Name": "Bitcoin.de"
	},
	"1PcNBYmUP5b9ygM6dWup7h9FDZcUjWsZEa": {
		"Name": "Bitcoin.de"
	},
	"37zBn9RUZk4kCUgnggYY619zMTNSfLHBTN": {
		"Name": "Bitcoin.de"
	},
	"38QjxnsJtEWnkyi82hkGKJ8DZtiMPAa31B": {
		"Name": "Bitcoin.de"
	},
	"16Qujfg9k12sS1tACHLZUn1Hc4NTpsDCye": {
		"Name": "Bitcoin.de"
	},
	"1PA4rfhg1FK3E6jMbYddS6YR5zdf5XnFn3": {
		"Name": "Bitcoin.de"
	},
	"3ASJzEijF24jDPgAxWtTSw41QQmrG1kwhk": {
		"Name": "Bitcoin.de"
	},
	"1F746eyjC4r5gMs74mE5GCvusAYDHUw8LB": {
		"Name": "Bitcoin.de"
	},
	"1JHsTqH6NBAnghGWVzmLLcQ7LhUKugs3bT": {
		"Name": "Bitcoin.de"
	},
	"19AVigUQYNGh3qerGmWZM87jBjFYRGWhz2": {
		"Name": "Bitcoin.de"
	},
	"1D2wjA7YHZEyLwakfKpWpSPi6mugpJcj7x": {
		"Name": "Bitcoin.de"
	},
	"3DCfQQgU1gTMx9uicnGGbgH4A8GbWD1SkQ": {
		"Name": "Bitcoin.de"
	},
	"3GdpLZnFcSzu72Vq6KLb9w4BnfAdWdLoTS": {
		"Name": "Bitcoin.de"
	},
	"31vmVbb2jUsJDEH8hg4iU83VuYbMdZWkvq": {
		"Name": "Bitcoin.de"
	},
	"34AkfaaPQFGubN8Wg2MpjC1bDeNhqkwh7p": {
		"Name": "Bitcoin.de"
	},
	"1DBAdy6qTeNKEArh3mhDuxMJXBfoYw2jUB": {
		"Name": "Bitcoin.de"
	},
	"3MsZViNbeHY3NMuDGcYFSfGqDaK2UwMLdW": {
		"Name": "Bitcoin.de"
	},
	"3HgHuQ6LxkY6uo3n9nar8cXpSyRmt11w5Z": {
		"Name": "Bitcoin.de"
	},
	"1gsTGfkS8pwnUKi5xzXUVT9skWMVXHa24": {
		"Name": "Bitcoin.de"
	},
	"37v7MhVmhxrqdsR1mpSTz9cPpLoWCFEa3F": {
		"Name": "Bitcoin.de"
	},
	"3BSDxKtEitq1jQ75L84mgSGrv1uVvSGWon": {
		"Name": "Bitcoin.de"
	},
	"1GfhyarBTEGcf7r9EMbfBtZYXLnpDQVyHa": {
		"Name": "Bitcoin.de"
	},
	"1ETocH9W1PQTYxohp3FkVuUX2rFmjPorvc": {
		"Name": "Bitcoin.de"
	},
	"1FZ99SrCRvL5wGcZtnWdGZ5cHHsHHeLDp2": {
		"Name": "Bitcoin.de"
	},
	"3Gf5NQrcsw4kpEPwSyzfM4mBo1Yqujx5BW": {
		"Name": "Bitcoin.de"
	},
	"3PL3GW3dqv2zZ3NEQShmP6F5nfxUZtmi2E": {
		"Name": "Bitcoin.de"
	},
	"13FaxNjGY3AGF9BcbZcdJocXUUfbo6owj4": {
		"Name": "Bitcoin.de"
	},
	"1K9ASC1XNJd8CVtpcbaBkF6VuuHcJfN6J7": {
		"Name": "Bitcoin.de"
	},
	"142d2ruFF4raYzn3KT4jitq1v15swQwMcU": {
		"Name": "Bitcoin.de"
	},
	"34QqziuZ8FZFUbhNa6MEHVwAcHLnCTXgTa": {
		"Name": "Bitcoin.de"
	},
	"1AVEDGP5JD2ifoQNPov92puUmMDRkWyc7B": {
		"Name": "Bitcoin.de"
	},
	"16FN6Ds4KLmywuU2bcHnciydhrGX1RB3Ar": {
		"Name": "Bitcoin.de"
	},
	"3PgDobj4Nx4m6xbj2yc9qQTC2M1DaG9rD8": {
		"Name": "Bitcoin.de"
	},
	"3GBMgGFDDVnsHZXQ2PudsnZZwoyjiqqPex": {
		"Name": "Bitcoin.de"
	},
	"16s4Z93A93SujE8denGVq3dQ9XMUjqwa79": {
		"Name": "Bitcoin.de"
	},
	"165ZFaeoXapk2C4UZSoR8AQU9JzzKS4GTn": {
		"Name": "Bitcoin.de"
	},
	"1JsLiNonN5oarZZSJiy13Z76YC9PyWSB2d": {
		"Name": "Bitcoin.de"
	},
	"3CQSaJRfX33xZfsDcdaQ8JrWPfuR5outc8": {
		"Name": "Bitcoin.de"
	},
	"34LqpfqBLwjaHywSgnTeUpjmL7k34yuCss": {
		"Name": "Bitcoin.de"
	},
	"3BHbsXJMefYyqEnVVcRM4zsKmRqfvdC8C5": {
		"Name": "Bitcoin.de"
	},
	"36xyjFy7b5DVjX1KLU19utELfNEApJTwur": {
		"Name": "Bitcoin.de"
	},
	"13o87bmvQ8LwbkdsMNLxT2HScehdzXWVPt": {
		"Name": "Bitcoin.de"
	},
	"3BekQ2k2i93WtZRMR1MU9sB6dcMR7BUQJy": {
		"Name": "Bitcoin.de"
	},
	"35SQJTRnqcm3oiiye4tXnzTP9DyyS3BgRy": {
		"Name": "Bitcoin.de"
	},
	"1Mu7eK7ERSojPUxKivkEG5rSCnyFyb1y2Z": {
		"Name": "Bitcoin.de"
	},
	"1KA8PAp8J4WgpCu3qaqzUutW8BG9JMg4ZJ": {
		"Name": "Bitcoin.de"
	},
	"1Kp8xQD7Ut7gjQVk4XDmDAtWG5UbrHHHPW": {
		"Name": "Bitcoin.de"
	},
	"18WnT8PUidLs1LdyWNxHzkBGLFwHfVxcxx": {
		"Name": "Bitcoin.de"
	},
	"1KZ4hpnfsWvm6Aquq4tAVZFbii9xyvSz84": {
		"Name": "Bitcoin.de"
	},
	"19wszqcJGF4Tk34wWQqwEg2S1NYqRHCFAZ": {
		"Name": "Bitcoin.de"
	},
	"3PrSGcNV4iQvnN7uSHtHBGKsvKxSxQ8umS": {
		"Name": "Bitcoin.de"
	},
	"3DYrugSinb3EPTXHHj4jq9t33QMfNRudXo": {
		"Name": "Bitcoin.de"
	},
	"3DDergZDVVBXzSp6yb7AuDTQiDKrgxiCED": {
		"Name": "Bitcoin.de"
	},
	"387VqjVLvQECpdsxwc9kGf1Bv1tDyUnkJj": {
		"Name": "Bitcoin.de"
	},
	"16T8dFwLi7V7yZCo3yVcqBXzbJXhdWwSkK": {
		"Name": "Bitcoin.de"
	},
	"15yM9zKBMp32ADnHnv7ZevGmE6dSRMmCNp": {
		"Name": "Bitcoin.de"
	},
	"14cLYpd1oYgWNxc1D1HKoKYeUqziXS49Fw": {
		"Name": "Bitcoin.de"
	},
	"37AdV34uyJwcRPRRci41QqeohSZv77oS37": {
		"Name": "Bitcoin.de"
	},
	"3MiAc9sXdCLZXsXjBjkMNZuiWxkhgkZBgF": {
		"Name": "Bitcoin.de"
	},
	"179qp15AvCYVjWbtz3Zqb31UWpUaTXodsB": {
		"Name": "Bitcoin.de"
	},
	"16GzTt9Ywr3UB726yYH1zvSkduFMzknpgf": {
		"Name": "Bitcoin.de"
	},
	"1DF2a7YxaENby58kmU43tpdBvwMRosJqz9": {
		"Name": "Bitcoin.de"
	},
	"1HdNFtBG4oK3ezDYEHBTxmwD99ogjhxsqE": {
		"Name": "Bitcoin.de"
	},
	"1NUi7EYBZHXpDoEFVgYkTCUBvLfzv2TDB9": {
		"Name": "Bitcoin.de"
	},
	"1AwvpH9ygM3an5iSeHdMCEauYkpwwCAED7": {
		"Name": "Bitcoin.de"
	},
	"3GtU9d7PXtQMm6CUWwzt1iUtRKHqBhfVxS": {
		"Name": "Bitcoin.de"
	},
	"36mb29VYyQKT7m9uzkmQatUX6uBcHstsRw": {
		"Name": "Bitcoin.de"
	},
	"17GKzFhftMPFSKgSiKUkyC5Z3g8tiUEtwi": {
		"Name": "Bitcoin.de"
	},
	"18mt6F1LHW2cjmG1XPz7aAUBAefZJ7sxSy": {
		"Name": "Bitcoin.de"
	},
	"1H7G2Q4xn4rwDCqz6P38m8RMtBPUQecWX1": {
		"Name": "Bitcoin.de"
	},
	"3PMGsiktih4MBC3pw3ozCB76ZvaKR57L52": {
		"Name": "Bitcoin.de"
	},
	"1E5FWadVSPc8ZqNGguU8cv5JvDDfb2Gzfc": {
		"Name": "Bitcoin.de"
	},
	"1NnhFG8KxyJWZaMtbfByPYGCCjkQJuQwAK": {
		"Name": "Bitcoin.de"
	},
	"1NzY9kDfjm1wJjfgTF5B53Y4Lcq7WgwRjM": {
		"Name": "Bitcoin.de"
	},
	"1MxZNr8ngAhWtmWJDx2u5gRU2ouMJsjgcs": {
		"Name": "Bitcoin.de"
	},
	"1KbsqTQukvxSExTMUA92syatLzufB5xkdz": {
		"Name": "Bitcoin.de"
	},
	"37VhbmqdVoyZYcfddSbBfUgewfTJEYXc7h": {
		"Name": "Bitcoin.de"
	},
	"1Gaj7dfprb39waPd1S4CrRYxsddWqsbVBh": {
		"Name": "Bitcoin.de"
	},
	"17y1WefXpuiigspQmyhg9HrQv9kaecysUC": {
		"Name": "Bitcoin.de"
	},
	"1A6JEy3LsU6Adv5dEcDmFXzmhiegssDNko": {
		"Name": "Bitcoin.de"
	},
	"1DMn6hoLcTKMLrZ37qVhbGYjKEHYr5aSFK": {
		"Name": "Bitcoin.de"
	},
	"1BxDQnkTZno7Zd2nVVYwxJ51aXjb5SmFHU": {
		"Name": "Bitcoin.de"
	},
	"15mKC3HtXbv8zs4SozT5fqZgsrEDySYf2X": {
		"Name": "Bitcoin.de"
	},
	"16G3edXJy3c9YvyAxL9ybHBLuGpCybqiqY": {
		"Name": "Bitcoin.de"
	},
	"1CwcdoYnUdECn4co98kGXMZrngSaVkYYAo": {
		"Name": "Bitcoin.de"
	},
	"1K9pCCbpoBnSuJXJAG34chwLpJkfdYEF4k": {
		"Name": "Bitcoin.de"
	},
	"3EKpr11cwStYVfvmvCwqwnczdgDwqCgaN4": {
		"Name": "Bitcoin.de"
	},
	"1GwV1BSGkKex6yet4uMw2RaHqrwdR9zjqd": {
		"Name": "Bitcoin.de"
	},
	"177oSUWdX1MerV2VNiiqmcEMz9JeMbthXN": {
		"Name": "Bitcoin.de"
	},
	"35q1VpwxzuS7PKVGGD2gdMGHerZNtEg7y8": {
		"Name": "Bitcoin.de"
	},
	"3EGdfMJbhPCnxN44SKNZ94AVt9wwULd67S": {
		"Name": "Kraken"
	},
	"3J1oFuTTWhHGJF2vLorfvReLkirX1JtWJj": {
		"Name": "Kraken"
	},
	"3HcEUguUZ4vyyMAPWDPUDjLqz882jXwMfV": {
		"Name": "Kraken"
	},
	"36JDC6y4dQDs5as5FqUMWa4WrcmJrJpKTr": {
		"Name": "Kraken"
	},
	"32retgqZViwtgbaJJYDMMVop9J55G3w6cC": {
		"Name": "Kraken"
	},
	"3EeHsUEnyYQkjdV7zT2v4KHid6B16RjkHn": {
		"Name": "Kraken"
	},
	"38pPcA8T4Tdx9hm2gPecSofhYb8nDVuUE4": {
		"Name": "Kraken"
	},
	"399ELQAoc3W2W6dApSc9Q8wZXKFmhKn2ZD": {
		"Name": "Kraken"
	},
	"3E2adcep2NRRpriLnWn1AvW3AHKqBx2mMr": {
		"Name": "Kraken"
	},
	"34FULEPXq3LDa4wWZYXtKKZ1Vu6Lj9agHe": {
		"Name": "Kraken"
	},
	"3B1wiS8KHASA47LrBx4hvrut2U28dZYR4T": {
		"Name": "Kraken"
	},
	"3GR57WCCJj7HwiEKvwNTuCh5H8s2tAYg5S": {
		"Name": "Kraken"
	},
	"bc1qkcg8puz0y5m6gl8lw2ah27q932yd229v8sfhhxp8tfpwugz5ukwspuyst5": {
		"Name": "Kraken"
	},
	"32YMNehwbtDZZxMFLibdcwN8TZmB9zr682": {
		"Name": "Kraken"
	},
	"3NzQDJcArDeZLN5eHoSDrDEZqTqD1VYMwy": {
		"Name": "Kraken"
	},
	"3MCMZjWAMdGqAhi1iF1oyiiE2jY5yBAYzV": {
		"Name": "Kraken"
	},
	"37RL7gCz99X9rTwCbXeLxhy4ARYAYmxnVs": {
		"Name": "Kraken"
	},
	"3BtrCCV8PxLXCS4ZuTVCxBTSTTyaeZSXmV": {
		"Name": "Kraken"
	},
	"382mwFY791y83oyHEcpSRRdAzKZtQbCAxu": {
		"Name": "Kraken"
	},
	"3Lmdpm5brGGobT4m87z8VxDc5KegRn3y4B": {
		"Name": "Kraken"
	},
	"3ECRXy3YTQket1NiXRs5pgePxecrEwX68w": {
		"Name": "Kraken"
	},
	"3DxqUY5un4hh6U1pGbnxR4G9hkdsFCywor": {
		"Name": "Kraken"
	},
	"3JeKFHZp1bpi8ppNyGi8uj8ZfRyikEhZJQ": {
		"Name": "Kraken"
	},
	"3Af5ChpCn3uegSBSrmaizVC8xXdHHZcjTd": {
		"Name": "Kraken"
	},
	"3MCFxJMqVbw5aNnzoEArZRUi1SbDTTP9SU": {
		"Name": "Kraken"
	},
	"3Gqj3v8jRWz6KnZn7Ams5dqH3UFpgRHmWi": {
		"Name": "Kraken"
	},
	"38o1vXfNfMG1vZZotMCr4aEMLtYydSNqTQ": {
		"Name": "Kraken"
	},
	"3QeMhR8zWaxN1bsb9BYRmzLUFxRYjteeQv": {
		"Name": "Kraken"
	},
	"31ivFCL4Sve1AqzUtanVKXZYPZmn33YMJF": {
		"Name": "Kraken"
	},
	"3GVZeTYqFkRVQ6kSKa4GdUxDrvEr6k7UAY": {
		"Name": "Kraken"
	},
	"3KTQYXvjteNoMECi62JYuqXobYQpcHjoVs": {
		"Name": "Kraken"
	},
	"3Hnuv1KfUFk44hjogxDjwgJ1QJnikhmKMv": {
		"Name": "Kraken"
	},
	"3Hs8zqkzVxjEepuQPA6ZJcjZzA8j2rQa8d": {
		"Name": "Kraken"
	},
	"3MVYNzSrVdojtfWcxbJTrgbjnxkcNPnUc6": {
		"Name": "Kraken"
	},
	"3BobtAvvVwWvSpqDBgPxSYp8efEvA5e2BY": {
		"Name": "Kraken"
	},
	"33ajG9PRsQWZ6KhPpX2F8j2b6naDXojp2M": {
		"Name": "Kraken"
	},
	"3Qm18LReKMVnBQKk3PtDdfxciHWGsaxaBC": {
		"Name": "Kraken"
	},
	"3NM18Me5jX5Kfg3VtMZg8b1iuKBY3fCcRW": {
		"Name": "Kraken"
	},
	"39eRtjDz6SHbx4ooNxV8rPnMKePrMXDgJr": {
		"Name": "Kraken"
	},
	"3BTkVV49MLooaQgzMgJZBZetngtoenB6AP": {
		"Name": "Kraken"
	},
	"3Gmhgzu6p2Dy2RiK14X5fCjbQ4gnYu6rJ5": {
		"Name": "Kraken"
	},
	"32nZjhgYDLL8SxYnTsD3FqP8eJpk1JE6kt": {
		"Name": "Kraken"
	},
	"39rDyE6zebBTWcmSny9rrVje33Qx7yjoCq": {
		"Name": "Kraken"
	},
	"32cgeXK61kqJM3SsVes8oL2Tb5YsfXH5Ta": {
		"Name": "Kraken"
	},
	"3QjhAA4bdPbCQaYf3EcnG8tbyNC7X2GPeB": {
		"Name": "Kraken"
	},
	"3DyVNzwHi5x9eh3FyTrnq3oyMvc2fStnmS": {
		"Name": "Kraken"
	},
	"3AifRAmkri2XQ7aSac9REsx9FV4hL8sY1p": {
		"Name": "Kraken"
	},
	"3NCibzJqRqKRXZpgcJtnud7gtzaUmnVYBB": {
		"Name": "Kraken"
	},
	"39ZEWfSkZ2Ahu8QNKbHG8g5jCKMcYXwM9P": {
		"Name": "Kraken"
	},
	"32A68SisBHyZtmhCR4XJMBXJzhKDjQMtSa": {
		"Name": "Kraken"
	},
	"36aRWWfwUgqwQTFkcw7LXG5mbirh9pbUn1": {
		"Name": "Kraken"
	},
	"38zg99VrKjjbWur81LCye7yJmFK4tpX8cB": {
		"Name": "Kraken"
	},
	"35eXd3jwequvGCxn1y2WXuABkD28LWmCWQ": {
		"Name": "Kraken"
	},
	"3LBM8CA6bPdpQpeQqpwVSr9P92MhwZqrmK": {
		"Name": "Kraken"
	},
	"3KVUeosP2vULof9SxDGDJu2x4BXx39QmW8": {
		"Name": "Kraken"
	},
	"37nMYMkmxxYahgokxQEfc9Ey1PVZo9AxQu": {
		"Name": "Kraken"
	},
	"3G3VG4X1WquWjqXT27JRwrRoyZgdyWf1dT": {
		"Name": "Kraken"
	},
	"38FpnMsxEinUckdhL4FcB6atQha77FWijP": {
		"Name": "Kraken"
	},
	"3H8ULsFTQacLmWHUo4FAnEkC3i6XEw8c7M": {
		"Name": "Kraken"
	},
	"3KA5xLgefA3orziTRZCZZVCpr8vny5gcXh": {
		"Name": "Kraken"
	},
	"3EYr5iVotDD8manJ9GxuwJ9p46PB8xB494": {
		"Name": "Kraken"
	},
	"3CUrMGKfDzkQQYAVZaehjU9bCFYZ2kdoye": {
		"Name": "Kraken"
	},
	"38Zj2nTwks5G7C6iYUkfks8AYMbmCjMUp3": {
		"Name": "Kraken"
	},
	"3FcR7iXk5aFcqaEhFYb7zyXnrePSnwqsNi": {
		"Name": "Kraken"
	},
	"3HoysScZ4rbkcjDoKtCqETByDJuvcSwYS7": {
		"Name": "Kraken"
	},
	"31hJpeNi8hL11VgkdeeDnnoxWufS78NHPX": {
		"Name": "Kraken"
	},
	"3CvMZdUypLMxAisC3HZUb6HR6CmoQMdrb5": {
		"Name": "Kraken"
	},
	"32EHjREGKZ314UztZ6RKeEf6Ve9om7td85": {
		"Name": "Kraken"
	},
	"3HgcXkFqTcy1wchhcjSZ1uJCYRsggvKoWB": {
		"Name": "Kraken"
	},
	"3KHuUEoXtN3R9kzD6hz5J9tiTYH5xcExe5": {
		"Name": "Kraken"
	},
	"37BYUfPff1Y6UAf3VRao1QFy6fW9mWVAWJ": {
		"Name": "Kraken"
	},
	"3AJhyFbUMHcF9krkkrqEy4Wm8MDJc13jXa": {
		"Name": "Kraken"
	},
	"3QRUVAuvJmFEwqxM8q2MNVDcEvLit7gG9X": {
		"Name": "Kraken"
	},
	"3MrrM31KaPAQG8ZdhHZwcPjG5qJXeH3aHo": {
		"Name": "Kraken"
	},
	"3QeMAHgzpKJfhKvAT5ubk2fj5eA7TQyhLP": {
		"Name": "Kraken"
	},
	"34aKaJs8cuetxYt8sLJZjv6UwNYmpQujKS": {
		"Name": "Kraken"
	},
	"35c6WyNWkkVhTXf7CMEcr2qUfEGsbzP5kc": {
		"Name": "Kraken"
	},
	"3EpD83AbXZ3GCbyYvYfwp57D1TEyjYNtpi": {
		"Name": "Kraken"
	},
	"34xJNdi6mGwCHpTAZuVc9DKmgrnS2HR3zB": {
		"Name": "Kraken"
	},
	"3ATRbgjJMDd9ZR5CnBYzRLptjFGBNSzLRk": {
		"Name": "Kraken"
	},
	"36gUz4Kw5zBzWg24E4pwUzvnbhVK3zv1H9": {
		"Name": "Kraken"
	},
	"3Gm7KwDKuMPgyUc4eA56Tt1N6PwwadXNg7": {
		"Name": "Kraken"
	},
	"38iV4pcjteuui6mRjSUW8qzgGdzDmieTd6": {
		"Name": "Kraken"
	},
	"3AiEo39ybBr5N8qBdszBz7XkvAoj41tuKn": {
		"Name": "Kraken"
	},
	"3GrFPWMXfD3WZnqxCfbjuxss8wvBfkyoQ8": {
		"Name": "Kraken"
	},
	"3JY82C9aKHeSsNuc23gNpTYTk7y48ZePKM": {
		"Name": "Kraken"
	},
	"3GddXVtz4PFooDdUDeoVzEo6mrJVNkEcEY": {
		"Name": "Kraken"
	},
	"35Yvq4GnXv77HjGNVR5AaUK54wqfu181kn": {
		"Name": "Kraken"
	},
	"379dwhyvyDJJxWNYid4DE1JEfUGRRsPe3X": {
		"Name": "Kraken"
	},
	"3ADHuqxqprJnt1mhotRvMbMyELq9TS5gfk": {
		"Name": "Kraken"
	},
	"34k7QdTH5efsKj4GjPdZ9tDDdoLe3Xia6G": {
		"Name": "Kraken"
	},
	"3M8MPemWa59jhFKnXiBfoddDBVktBv9KkK": {
		"Name": "Kraken"
	},
	"35Yo2hRQ1CTyehhmWn62syfDcqGpcHbTG8": {
		"Name": "Kraken"
	},
	"3Be2ZHpihKoMhTPfiBncVueicFEXak1FXR": {
		"Name": "Kraken"
	},
	"38wS7MgQzzrbQJtggGrzCqDpAbaB3Ppv7y": {
		"Name": "Kraken"
	},
	"3AUEjCbnp4wCpr7QvHZ9PXQjCD2m78cccN": {
		"Name": "Kraken"
	},
	"39EdQzkin47iMQof3DTGxDm1rWGGJY3kZS": {
		"Name": "Kraken"
	},
	"37h97BSAbDttDPBgs5Y1D4Vei8vs1YXsED": {
		"Name": "Kraken"
	},
	"33u6GN5SLraRanmntbC7DwdJ3rDfYkTX5T": {
		"Name": "Kraken"
	},
	"33MweK4YRsF9eUcAYhVhVH9DQEybN3oPcL": {
		"Name": "Kraken"
	},
	"1LgW4RA5iE98khRJ58Bhx5RLABP3QGjn9y": {
		"Name": "Poloniex"
	},
	"1AoFgNvfRjDirUV2YZynnnDChkzL73fEyU": {
		"Name": "Poloniex"
	},
	"1Po1oWkD2LmodfkBYiAktwh76vkF93LKnh": {
		"Name": "Poloniex"
	},
	"1LTBCyh9dKhNNZFaByPXfrkeuAD7yr6A4b": {
		"Name": "Poloniex"
	},
	"1FLDCfr9iG7n6bAdGsqBXmhaLgC4aSze72": {
		"Name": "Poloniex"
	},
	"1GEMZsZZQ32YqX3nzBptQLJBAtn1XByRCZ": {
		"Name": "Poloniex"
	},
	"1PbRmFhyCFQQwBPjxqUnyDBtivWeboyHze": {
		"Name": "Poloniex"
	},
	"1Po1oXMCWobE6kxWr8rJEP1SRq71JSD3t4": {
		"Name": "Poloniex"
	},
	"15PmQavqCQpgYp4VRKY8q4yuSnxeeASr1A": {
		"Name": "Poloniex"
	},
	"1B6knB3DCZXdUq9txrRBRXYzg9ZvjsPHx2": {
		"Name": "Poloniex"
	},
	"16gAfdKF8p9xJ6kWbCtX7J4AvmHz9Lsash": {
		"Name": "Poloniex"
	},
	"1iqXNJmU458rEjKH2B1vanXGMXUp7Gyfk": {
		"Name": "Poloniex"
	},
	"1J1dCYzS5EerUuJCJ6iJYVPytCMVLXrgM9": {
		"Name": "Poloniex"
	},
	"1DuH85keWtNbhqcnKutHAii6w4E2z8LwCz": {
		"Name": "Poloniex"
	},
	"1E25XTr3FkyRRGDaxBHkUxUCRHMrJfz36v": {
		"Name": "Poloniex"
	},
	"1DGAn6r5FhshrcQLcaUE7LWfPZyGaUFzyu": {
		"Name": "Poloniex"
	},
	"1GFkTe6qq6Lk9VzatenR1BFJkNz31JWJxq": {
		"Name": "Poloniex"
	},
	"19i7w4uBnj5M7L78yLKcjvHHchcBDZX9ag": {
		"Name": "Poloniex"
	},
	"1BTxUQ3fMS5rEHAQKdNrDbMignikRWDNd4": {
		"Name": "Poloniex"
	},
	"16K3dHGYe8jBogt52sTdZ8ECm2Mf9ELGZ8": {
		"Name": "Poloniex"
	},
	"1GDmEFBGb9P1D3ucWwoFAcXf1Hs9ytQsQj": {
		"Name": "Poloniex"
	},
	"1MgffMMmHt2UcSyzsSLRDHeDaBYeLEzwHm": {
		"Name": "Poloniex"
	},
	"1BymtJNZyXVLptmQjWgh6LmnM2bfe4E5EC": {
		"Name": "Poloniex"
	},
	"1LXV5aCo7sBEHK5AAbYAgzao3ynvphPKxc": {
		"Name": "Poloniex"
	},
	"1CLu5YPZwJYzVFKHrvAvb6V2jfoTZ3Mch8": {
		"Name": "Poloniex"
	},
	"1HmJJhJkfXYse6SYfT1szAZekcBe6q4CMS": {
		"Name": "Poloniex"
	},
	"1BN8JdeWaKMRewKki9HVHSm6yGyRaqHmMm": {
		"Name": "Poloniex"
	},
	"16dbbZ1mbpUfyx4B38SZhbBZLudabdN52T": {
		"Name": "Poloniex"
	},
	"1PSHJ8mQAByWC9czNbXTb24j2GzU2DaNBZ": {
		"Name": "Poloniex"
	},
	"13Cdo1tgqyEnTyDgfh8WcXmEJHqu4vwJYK": {
		"Name": "Poloniex"
	},
	"1EHHoYjRhHghDwsqvHVJreK2oZieosq8fZ": {
		"Name": "Poloniex"
	},
	"1KC9vKuRGWe6ag8MxSgnAZAn6hrz5Eg8AJ": {
		"Name": "Poloniex"
	},
	"1PTcE3fqRamuvbGmxjjAVnuzH4GYeAmcH8": {
		"Name": "Poloniex"
	},
	"14BbvtnzXVSkbdsydnqg5NNRrQmbNx8Rq2": {
		"Name": "Poloniex"
	},
	"1KMGLNtdbKAkQ9D5G3muFKEWXfc3SZXoc8": {
		"Name": "Poloniex"
	},
	"17RYUKUJcHNQVpi4Rx6hhGKcSrw7VYUMSG": {
		"Name": "Poloniex"
	},
	"176p7gWeMpwbrr13nhaVTNmJKzZ9f6FJFs": {
		"Name": "Poloniex"
	},
	"1HTHPLwe2FiEAdvKmjNu5jzsUnxnqNe1q6": {
		"Name": "Poloniex"
	},
	"1EPHhWBgpBkR1oAyTrFfLEmGEF68bhakj2": {
		"Name": "Poloniex"
	},
	"1NorNDYekFoWHzwUtujjZ3TAADAdygcyoi": {
		"Name": "Poloniex"
	},
	"141MUpzh3tYHJE1BcM4nKiY1DeUwbDBe5S": {
		"Name": "Poloniex"
	},
	"1FQSYCTZ2vrpRpgVqczpyNHuu3cSwmkSak": {
		"Name": "Poloniex"
	},
	"1PvEV76DCmFhY64TXW7dbhAM8ZjMru2Pzp": {
		"Name": "Poloniex"
	},
	"14cbjvraokrDSDC21EiMRjGwHkF5R7DjWY": {
		"Name": "Poloniex"
	},
	"1HnKJ7AmgKLLLapVYab9o25fNMYtQcXg7x": {
		"Name": "Poloniex"
	},
	"1G2fhiGsEKEKGpHpy1TeY4GaaV7WTsNCTf": {
		"Name": "Poloniex"
	},
	"1Nm7Y1oTz5xvLVtXKdLd1w79jYhye7uKu": {
		"Name": "Poloniex"
	},
	"1GSaYmxGzWKk9PHcA7YVt2RY61MECLCCPB": {
		"Name": "Poloniex"
	},
	"1LAHXGyukiS5sNVJRvG314qxfiEDZbFP76": {
		"Name": "Poloniex"
	},
	"1LVWstBhTt4A1ESLyciYo86HbbfPvsP8hf": {
		"Name": "Poloniex"
	},
	"1EAzEMW8FsbrE5eNbj6g4P4qmYGduXKAAs": {
		"Name": "Poloniex"
	},
	"1BK8RijHBvyGJPNm3zvF1joLU7cJidrmBr": {
		"Name": "Poloniex"
	},
	"13DQDXGrs6RCK9jAnXFZ9rNPqdoGNMCiF7": {
		"Name": "Poloniex"
	},
	"1LboQxHyreohR8VQB8TjH3HUrbNRAvgswq": {
		"Name": "Poloniex"
	},
	"15PVXkmYCHbvnweKQnJpMVfrxUSokYf4An": {
		"Name": "Poloniex"
	},
	"17rfmLrVcVBMfp6LtnbiprePimwAsGNykg": {
		"Name": "Poloniex"
	},
	"1Bv2KAJWSbjtAHBcCkmJKutKERUmNUH6N1": {
		"Name": "Poloniex"
	},
	"1JHqPtp7EzRXaJ5WZnNX8RAp3T9gvGxmBt": {
		"Name": "Poloniex"
	},
	"1KEmNd7q3kTfhESL5B1wzYd9892Uiyyasy": {
		"Name": "Poloniex"
	},
	"15r8VsyGPwp9iGbU33riFjtRMFhNgpLuzp": {
		"Name": "Poloniex"
	},
	"17heqPjPyRRgmc6mKTJv6aoDhFEDFZJV2K": {
		"Name": "Poloniex"
	},
	"1L4mkV4aGQ2Fg1VeqwHHMRnxwTeQjDqWm6": {
		"Name": "Poloniex"
	},
	"1EkZzD7WstZMSMAXAPPE2D4huagujtHjYS": {
		"Name": "Poloniex"
	},
	"15MqXyH1ZeZ2ErZGugEC4E3aCKN27stgYK": {
		"Name": "Poloniex"
	},
	"1H2CcmWJAspuqcfz1pgNwmwjQUd9DkVdg9": {
		"Name": "Poloniex"
	},
	"1LZ6R8o9EkhwG1N688XeLzc3tiygRRvaxt": {
		"Name": "Poloniex"
	},
	"17EB8hBrpEjLsgVHHMT3zvLJSJoVYwrR93": {
		"Name": "Poloniex"
	},
	"18msXy3xJdovX29eMkESW93fj6k1zVEHQP": {
		"Name": "Poloniex"
	},
	"1LvrheUwj4a5AWNX3QWYL6N2jVN2FMHL6n": {
		"Name": "Poloniex"
	},
	"1NKDRzv3yFqR1Dmz8vy9xnQh2ENmCCjQjE": {
		"Name": "Poloniex"
	},
	"1NBQCVqiqzydntka9x8pcAqSH7C3Eh3fwx": {
		"Name": "Poloniex"
	},
	"1CL7DWeceagpjZ1EUuUjrVaXmtEcezAkau": {
		"Name": "Poloniex"
	},
	"1CScAWXfQMrR5QwSdUwxoKiz4jQcjmndky": {
		"Name": "Poloniex"
	},
	"17oHLqLZFZsNPMzynfSRdbxXarfbcTbhyR": {
		"Name": "Poloniex"
	},
	"1LePsfBf8qcFYnAJe3VU7Z87ceDsuRZYZY": {
		"Name": "Poloniex"
	},
	"13pMyKCBSxiKhX1vFxHp7DdNUK3FDgz53k": {
		"Name": "Poloniex"
	},
	"16vGLQois89c7M2eogZkW4sXEbsfoJRvMg": {
		"Name": "Poloniex"
	},
	"12Z2iLSg9n9rX98SEfaXFCyTN3Q8re7FnN": {
		"Name": "Poloniex"
	},
	"15U4kQBpz7s9tzFUzu8z8uZ1z8zKuKHFYp": {
		"Name": "Poloniex"
	},
	"18zhAriVCwF3GLSipr984QP35sgWopGjw8": {
		"Name": "Poloniex"
	},
	"1GegBWbTgAYM99nmCejgEs4J6s1X38MGDt": {
		"Name": "Poloniex"
	},
	"1N7mYcC2H5V5xWCNGMFEoijky1CPjqrBp8": {
		"Name": "Poloniex"
	},
	"1GGNpn3xrAhCxKhLE38QJWwwVCq5oGEf4K": {
		"Name": "Poloniex"
	},
	"1KxVBErfjVe7U6ayWKTDkbpoJH927CpcjV": {
		"Name": "Poloniex"
	},
	"1KkoWvgrP5ZhNLMJmT447TkYD79nBXh4pR": {
		"Name": "Poloniex"
	},
	"1JkrWm4LShBNBk5UrNsN4ZDHQryPiRtt7X": {
		"Name": "Poloniex"
	},
	"19XowBhaYigP7dncichwC7BKVGNuCTr8WH": {
		"Name": "Poloniex"
	},
	"1EfUry2pybBj78m76ww4e7pYY5WmBEKnzj": {
		"Name": "Poloniex"
	},
	"19gYv5hycwmMpGPQpjKDTUS8jhdeBWPcTZ": {
		"Name": "Poloniex"
	},
	"1P8TkLUPxcszMmChguXPvxhnLW7kt7sbGn": {
		"Name": "Poloniex"
	},
	"1E75ATY8FptkGeCzU4F7mvFPv7Ay7k5oUB": {
		"Name": "Poloniex"
	},
	"1PRjUfLmNa1QsttL5DStrpTkxckRbCcS2m": {
		"Name": "Poloniex"
	},
	"1FBFzBoL9ckP7oxF5wrtqWr73SVBtYMFH2": {
		"Name": "Poloniex"
	},
	"1CU2PjoEr9JjaQd1AJaBinD6YrPfZfYr8u": {
		"Name": "Poloniex"
	},
	"1HbGHzyjyVhysNXFtDK1UUam6rpxkcPs69": {
		"Name": "Poloniex"
	},
	"1Dg2McNx22XeZkAgUqyfpNJDfrinVioYhE": {
		"Name": "Poloniex"
	},
	"115VA5mjQYX3SG9GKcFK2Vmea94c6qAKiJ": {
		"Name": "Poloniex"
	},
	"1HGjQ8K7mrz5fAdQrBu5u9NS6WWLR8GZ86": {
		"Name": "Poloniex"
	},
	"1K7sehKEr95WdZidvYL5r3qguWi5SjGugW": {
		"Name": "Poloniex"
	},
	"1PXUNur4kDox5PNsUfFjGBfp7JLDXFZDus": {
		"Name": "Poloniex"
	}
}
var addressTags = {
	"37762eEWdPaQKguMMaH5XGtjzgLzTXohfq": { "n": "Giveaway Official", "l": "http://btc-24h.com/", "v": 0 },
	"16hyiMGeCra6dQwz7b1RWm3S6JgsyAcrRQ": { "n": "LuckBiT Hot Wallet", "l": "http://luckybit.ga", "v": 0 },
	"1NqKaE5pPAFoEGDhTD2uVUm3Xt563ZH1aZ": { "n": "Aid Maldives", "l": "http://aidmaldives.ml", "v": 0 },
	"1AEmEqNivekwJLC2fH8xkHhDQpHir8JaD8": { "n": "Cancer fund for UNP", "l": "https://www.reddit.com/r/Cancersupportgroup/comments/8dit3q/my_dad_just_found_out_he_has_cancer_in_his/", "v": 0 },
	"1CBSqVZs4mVnhDXC536vimJNrkjDvdyAjc": { "n": "World War 3 donation for USA", "l": "https://www.reddit.com/r/BitcoinBeginners/comments/8fa8np/fund_me/", "v": 0 },
	"3AUAsY95FGpvQprEQfyyMbjTok9ipvyPJv": { "n": "Satoshi III", "l": "http://bitcoinwhoswho.com/address/3AUAsY95FGpvQprEQfyyMbjTok9ipvyPJv", "v": 0 },
	"1EVaFiG222E1kByfiV3Bj1NZApsDfAE3vt": { "n": "A blogger fund me. Check out", "l": "https://rudhay.wordpress.com/2017/08/24/maldives-the-sunny-side-of-life-?/", "v": 0 },
	"3H5UjM8zm4cqM7aJ5SArzp7n8a6h4y9BSt": { "n": "Donate for Maldives.", "l": "https://www.reddit.com/r/Bitcoin/comments/8f7age/sgin_guy/", "v": 0 },
	"12iL16ZCSyjU7gEaeLDasiEfsUBUaEozJ3": { "n": "jojo was here", "l": "https://j0j0gr.wordpress.com/2015/03/02/hello-world/", "v": 0 },
	"134ZnmvWpGDGSwU6AnkgSEqP3kZ2cKqruh": { "n": "asdfafdsarewr", "l": "https://blog.blockchain.com/2014/08/29/how-to-understand-the-blockchain-info-address-and-transactions-page/", "v": 0 },
	"1AfT83fMEGa43JQYAo8j9HMPouaZzzCyn7": { "n": "abcde", "l": "http://localhost:8080/tx/21581c0f34ea4927684d6046118ca9d601046ab658d93c2973214ee723693f94", "v": 0 },
	"1GLENCoJHdKjVnLUmQGnbL2SjYWKKKeRc9": { "n": "1GLENCo", "l": "http://uranus.glencooper.com/", "v": 0 },
	"1HeyNSA2TW3TixWRD6DnXipq4jhDVXePCP": { "n": "1GLENCo", "l": "http://1glenco.glencooper.com/", "v": 0 },
	"1GLENCoSJJHH7FahyhTi16iwZQcHtMbxA4": { "n": "1GLENCo", "l": "http://1glenco.glencooper.com/", "v": 0 },
	"3QercMjovsSjuPtJSaYNpzMtgiRb5SJuVd": { "n": "BX.in.th Cold Storage", "l": "https://bx.in.th/info/transparency/BTC", "v": 0 },
	"1FR6uK7J8JakrcEcuLbopjpnmL2hYK6wAa": { "n": "Leon03", "l": "http://block.okcoin.cn/btc/search/1FR6uK7J8JakrcEcuLbopjpnmL2hYK6wAa/", "v": 0 },
	"1CUBJE4zo7B5W54Wnm8FH41NGkvetZKKoL": { "n": "To build a church in Poland UE", "l": "http://block.okcoin.cn/btc/search/1CUBJE4zo7B5W54Wnm8FH41NGkvetZKKoL/", "v": 0 },
	"1F9v3DZKmaesQntE7imZt7581cqw6Zd51i": { "n": "Jesus Christ is risen !!!!!!!!", "l": "http://block.okcoin.cn/btc/search/1F9v3DZKmaesQntE7imZt7581cqw6Zd51i/", "v": 0 },
	"1ApPvzbESUjW1mrWwmyP6uxeQWXbMkX17f": { "n": "Europe ONLY to Christians !!!!", "l": "http://block.okcoin.cn/btc/search/1ApPvzbESUjW1mrWwmyP6uxeQWXbMkX17f/", "v": 0 },
	"1HZo14xXKRrzt1H3o6PpQBvPJbtbR4KFe2": { "n": "Bad dude tagggg", "l": "https://www.reddit.com/r/SheepMarketplace/comments/1rvlft/i_just_chased_him_through_a_bitcoin_tumbler_and/", "v": 0 },
	"1CbR8da9YPZqXJJKm9ze1GYf67eKAUfXwP": { "n": "testing", "l": "https://www.reddit.com/r/SheepMarketplace/comments/1rvlft/i_just_chased_him_through_a_bitcoin_tumbler_and/", "v": 0 },
	"1EEA3jsLMnSd1HUHVeCZCRsci9mZQPbXcT": { "n": "Bitcoin mining and sick miner", "l": "https://www.youtube.com/channel/UCNZEFVzz0XJEBX5zpya07Xg", "v": 0 },
	"1TsukiDkM4NMoj2n9xTUc2J2eckhahQNw": { "n": "TSUKI project", "l": "https://systemspace.link/", "v": 0 },
	"1LQbiYjToCbTHcgEe6niYb5bGvhc1maGmZ": { "n": "Bitcoin Sign Guy", "l": "http://block.okcoin.cn/btc/search/1LQbiYjToCbTHcgEe6niYb5bGvhc1maGmZ/", "v": 0 },
	"1FKxQvzjh3Fp4D2YbTmUuB3cv1ncoXb9Tr": { "n": "San Escobar official address", "l": "http://block.okcoin.cn/btc/search/1FKxQvzjh3Fp4D2YbTmUuB3cv1ncoXb9Tr/", "v": 0 },
	"1AFLzkNGvY3LuHh2Pgxu3XLdzJ8bqNL1WK": { "n": "Bitcoin24.su exchanger", "l": "https://bitcoin24.su", "v": 0 },
	"1HdWBxEfoqoVigdWpCqrXVbiJSnf529hGf": { "n": "EDMAR1981", "l": "https://www.walletexplorer.com/address/1HdWBxEfoqoVigdWpCqrXVbiJSnf529hGf", "v": 0 },
	"15DoXTDqmfCrhRcf33oaA99R5cbSka1fL6": { "n": "MIGHTY", "l": "https://webbtc.com/address/15DoXTDqmfCrhRcf33oaA99R5cbSka1fL6", "v": 0 },
	"1GcGyVjtcddAypEfUKTaQv9fNFaSRYh7pZ": { "n": "Donate Social Int. Pawn Shop", "l": "https://www.youtube.com/channel/UCNZEFVzz0XJEBX5zpya07Xg", "v": 0 },
	"1MEscEdiAkacRStk57FFb7MAd5rYSAYF7n": { "n": "mescedia.org Open Source EDI", "l": "http://www.mescedia.org", "v": 0 },
	"19AENxshHjdjsQrJfawCaudxaTAaNHxqbd": { "n": "bitrated.com", "l": "https://www.bitrated.com/security", "v": 0 },
	"1KZ7vMXg7FBRGUo4oEmRJat2TCieapxC97": { "n": "Cinema Mistica", "l": "http://cinemamistica.com/donate/", "v": 0 },
	"1PcTUmhARo1sggieNCw2JBykbr7vycrLmx": { "n": "IPFundBitcoinAddress", "l": "http://ipfund.loan", "v": 0 },
	"1GwV7fPX97hmavc6iNrUZUogmjpLPrPFoE": { "n": "SCAM SITE 1", "l": "https://bitcoin.org/en/", "v": 0 },
	"1GwtZF9QFKWNqCRHLx1Y9adGcrhQSUnNfY": { "n": "Bitcoin Sign Guy", "l": "https://www.reddit.com/r/Bitcoin/comments/6mw72g/bitcoin_sign_guys_address/", "v": 0 },
	"3Ez2wddHYXBUx6nXTtbLoLAUCUS7yg3L8C": { "n": "DONATE4_CapitalCultureCity2025", "l": "https://mannheim239.blogspot.com", "v": 0 },
	"1QLMoH6hSU8QbGcAHVBZi3zNZQm6zCz5yp": { "n": "Four_Wheel_Travel", "l": "http://reise-shop.4wheel.travel", "v": 0 },
	"1GcUbediMwmet3kA25FByJLHx34Zrx5dmE": { "n": "gCubed", "l": "https://www.gcubed.co/", "v": 0 },
	"1woukheyeacxfpxtpkxjqxureevdkbywj": { "n": "Ryan Castellucci", "l": "http://1woukheyeacxfpxtpkxjqxureevdkbywj.com/", "v": 0 },
	"18a5ZKhoKDhBoiCV7boagGLRXCQFmzgpDT": { "n": "Islam Of Headshots Clan Donate", "l": "https://sites.google.com/site/islamofheadshots/donate", "v": 0 },
	"12t9YDPgwueZ9NyMgw519p7AA8isjr6SMw": { "n": "Wannacry ransomware 3", "l": "https://securingtomorrow.mcafee.com/executive-perspectives/analysis-wannacry-ransomware-outbreak/", "v": 0 },
	"115p7UMMngoj1pMvkpHijcRdfJNXj6LrLn": { "n": "Wannacry ransomware 2", "l": "https://securingtomorrow.mcafee.com/executive-perspectives/analysis-wannacry-ransomware-outbreak/", "v": 0 },
	"13AM4VW2dhxYgXeQepoHkHSQuy6NgaEb94": { "n": "Wannacry ransomware 1", "l": "https://securingtomorrow.mcafee.com/executive-perspectives/analysis-wannacry-ransomware-outbreak/", "v": 0 },
	"1Lzkycjf6ffFSRKwbwEz87SjYNeTLNxAxD": { "n": "12345", "l": "http://d214mfsab.org/same2.html", "v": 0 },
	"1LXcth7SuXE7rXac4sJwALdCcovSYooJ7y": { "n": "Minerstat.XYZ", "l": "http://minerstat.xyz", "v": 0 },
	"1D95JKWUJvoFHkgJv9qhiJYSwQ5PrHxhxQ": { "n": "SV Satoshi", "l": "http://svsatoshi.com", "v": 0 },
	"1FuckPxy7L5iVsdxqAWtdxwi84uFibJubv": { "n": "TOM NICHEL", "l": "http://www.tngif.ml/main.php", "v": 0 },
	"1KEyvenDoR2pPGsioybSZhcMKHKvi7JsMk": { "n": "KeyVendor.net", "l": "http://KeyVendor.net", "v": 0 },
	"1561fQSyaNLgo7ebQpSgMFFe6L2XDhWzGE": { "n": "ebitbux.com deposits", "l": "https://www.ebitbux.com/", "v": 0 },
	"1GkTjPKQkCWJ37FjxHf2D2ZiXrvMoXoTQA": { "n": "ebitbux.com withdraw", "l": "https://ebitbux.com/", "v": 0 },
	"1wyKoPRsRe5e7aA99sMxj1pKF7YDsVFXU": { "n": "Wykop.pl", "l": "http://www.wykop.pl/tag/bitcoin/wszystkie/", "v": 0 },
	"1Bpqs8zwvERi7PCXtppUfTuaiLPtEj1uFB": { "n": "btc multiplier", "l": "http://btc-multiplier.com/invest-now.html", "v": 0 },
	"1Br7kBfwwTsZj4VnavLCgFESou6Doh8dMB": { "n": "PFMGP", "l": "http://pfmgp.de/impressum.php", "v": 0 },
	"1PTU9uvhjWvKaRgDjhBFFY3vMgZCRM4uoT": { "n": "hello_world", "l": "http://tklist.us/bitcoin.php", "v": 0 },
	"1ZNaZDh2RRFs8ayGUzrgZ35woHJyTAZ51": { "n": "ceramic", "l": "http://friga.tel/", "v": 0 },
	"198gdVP9JsySL8UiJL6KgfnZBy3Nk29QfU": { "n": "NZBplus", "l": "https://nzb.plus/donate/", "v": 0 },
	"16Wx67UjD3xfvfDg7RWF73kU3PZReMMVLZ": { "n": "vpscoin.me", "l": "https://vpscoin.me", "v": 0 },
	"1FEWYDWeg5qQByT5WxuzNuT8zwJZvKT5P3": { "n": "vpscoin.org", "l": "https://vpscoin.org", "v": 0 },
	"19Ps2jKjVLEZmCMubMDSQzGJxiLpdY3UP": { "n": "Comunes Association", "l": "http://comunes.org/donate/", "v": 0 },
	"1553kfKvBK24xi3kozWka3HWhPUW94kJNH": { "n": "BTC100X", "l": "http://btc100x.net", "v": 0 },
	"1J9XPSZmNjxbGtFPZ1NtGMheoP9PSpUmXR": { "n": "BTC100X", "l": "http://btc100x.net/", "v": 0 },
	"14CJ5jhGHSNA5DtsauyjbKf4wkScZNowy2": { "n": "boy--------------girlbtc.com", "l": "http://www.girlbtc.com", "v": 0 },
	"1LgjCtjkTLaCBUjKxyWoRQYTeoqKJUQjDS": { "n": "girl---------------girlbtc.com", "l": "http://www.girlbtc.com", "v": 0 },
	"159WUrwFsvEpP9PtQSPZCZ8jVPjSFpp6tH": { "n": "Forex2Daily Pvt Ltd.", "l": "https://forex2daily.com", "v": 0 },
	"1Dq7Jrttwsfab4H4KHa7BpboBWPnpm8wft": { "n": "Bonvivani", "l": "https://bonvivani.sk", "v": 0 },
	"3KSxaYdX1tMpSpVjPLS8cep2Bec5HxQvv4": { "n": "NodeCounter Rented Hashpower", "l": "http://nodecounter.com/mining_donation_fund.php", "v": 0 },
	"1DYrggF83bLKzhdEwQ5Quajnb6xzDHJSHe": { "n": "Secondstrade TXDICE 2pct DOWN", "l": "http://secondstrade.com", "v": 0 },
	"15LT5hhS74Zc2E4safN8a3XVsPf2jsghH3": { "n": "Secondstrade TXDICE 2pct UP", "l": "http://secondstrade.com", "v": 0 },
	"1AiHxxx4EKnjBsw2Src3gYZA1SqCZiRWF7": { "n": "Secondstrade TXDICE 18pct UP", "l": "http://secondstrade.com", "v": 0 },
	"173KdueXnt9xSxLNWQNEsxpEBrJehpn2vs": { "n": "Secondstrade TXDICE 18pct DOWN", "l": "http://secondstrade.com", "v": 0 },
	"18t4DNrFhbVNNouRsUwv8npijSStXMP6Aq": { "n": "Secondstrade TXDICE 82pct DOWN", "l": "http://secondstrade.com", "v": 0 },
	"1H8UvkQM1cUhJJph5hVHA32Zd8KP8E4q76": { "n": "Secondstrade TXDICE 82pct UP", "l": "http://secondstrade.com", "v": 0 },
	"14Zh6FR68RaL5m4Jc6jygWavjrbgUk3Jww": { "n": "Secondstrade TXDICE 91pct DOWN", "l": "http://secondstrade.com", "v": 0 },
	"19Y9CZ1ooDqTHb92LumhkPfqDin4BgJZH1": { "n": "Secondstrade TXDICE 91pct UP", "l": "http://secondstrade.com", "v": 0 },
	"13VpVj2rp684F2SaZmPc2hr48xYCwhg2jV": { "n": "Secondstrade TXDICE 12pct UP", "l": "http://secondstrade.com", "v": 0 },
	"1KV55JvJTM5UYasPGTLpH2sCJkNMaXEGRq": { "n": "Secondstrade TXDICE 12pct DOWN", "l": "http://secondstrade.com", "v": 0 },
	"1KRGmXJ5L5TS9rDVFtB4k9sfGf95PMkACX": { "n": "Secondstrade TXDICE 36pct DOWN", "l": "http://secondstrade.com", "v": 0 },
	"1KDrngZpG77XTRyGnnSFWsbVr3qycd9JiT": { "n": "Secondstrade TXDICE 36pct UP", "l": "http://secondstrade.com", "v": 0 },
	"1HnXiS71r2uUci8L5wJuWHjR6sF8hb4wsd": { "n": "Secondstrade TXDICE 24pct UP", "l": "http://secondstrade.com", "v": 0 },
	"1EhzjZ7rVQBNuNiKyYof1dqAxfePd3Pw1Q": { "n": "Secondstrade TXDICE 24pct DOWN", "l": "http://secondstrade.com", "v": 0 },
	"1K3kLzXfNjNTyJHUWff6XGtRfErdJQAg7S": { "n": "Secondstrade TXDICE 73pct DOWN", "l": "http://secondstrade.com", "v": 0 },
	"1NryyQAhzLAypTyt8B6Lcmw9qAuzymSfNH": { "n": "Secondstrade TXDICE 73pct UP", "l": "http://secondstrade.com", "v": 0 },
	"1GMWPYKL92isiZSE7KCHPvKQWejGLEbBng": { "n": "Secondstrade TXDICE 48pct UP", "l": "http://secondstrade.com", "v": 0 },
	"19MYMgG4by5cst5ccffESEKqQCz3Bbhtnf": { "n": "Secondstrade TXDICE 48pct Down", "l": "http://secondstrade.com", "v": 0 },
	"1PaemmvpKsstHnGP6bSqrPoeAoDKzh8Laj": { "n": "Secondstrade TXDICE 50pct Down", "l": "http://secondstrade.com", "v": 0 },
	"1NqCDioR4G6TeoxcVxx5wpghQ7UmESD4uz": { "n": "Secondstrade TX DICE 50pct UP", "l": "http://secondstrade.com", "v": 0 },
	"1A2ZQsmHnMf8Xn59MHJBAwawEnbLR3y4wP": { "n": "chupalo", "l": "https://faucetbox.com/en/check/1A2ZQsmHnMf8Xn59MHJBAwawEnbLR3y4wP", "v": 0 },
	"12R1QtGWkHuVywPUSWFNEjzsdnWDv7pX3C": { "n": "Btc-Multiplier.net", "l": "http://btc-multiplier.net/invest-now.html", "v": 0 },
	"1Pn95WuBbRfCPpP1afkQvBGs9SfyLPyvVG": { "n": "eBitChat", "l": "http://www.ebitchat.com", "v": 0 },
	"1HF7EcMX5u3cMBeo4NBeN7vym36cg7gS6v": { "n": "Mises Institute", "l": "https://mises.org/giving/paypal-and-bitcoin-gifts", "v": 0 },
	"12jnimAfwA77u8r92DNe6GMqxdyVkh6qcf": { "n": "satoshi bones donation", "l": "https://faucetbox.com/en/check/12jnimAfwA77u8r92DNe6GMqxdyVkh6qcf", "v": 0 },
	"1BPqSgk4qgSbfcdWhJTqpf9anVEzkKbesp": { "n": "btc multiplier x2", "l": "http://btc-multiplier.com/invest-now.html", "v": 0 },
	"1PumjGQD6zxVPR7Qwx31SZfjWBdPDQnubF": { "n": "faucetbox.com", "l": "https://faucetbox.com/en/check/1PumjGQD6zxVPR7Qwx31SZfjWBdPDQnubF", "v": 0 },
	"16WKTYdxxd2jp9CLFzQu5HJQpDE485rRUc": { "n": "calibre e-book software", "l": "https://calibre-ebook.com/bitcoin", "v": 0 },
	"1BitmixerEiyyp3eTLaCpgBbhYERs48qza": { "n": "BitMixer", "l": "https://bitmixer.io", "v": 0 },
	"1D9w7K6mEuXDukqBrtfyD2J5UAGgWFSv92": { "n": "Creativechain", "l": "http://creativechain.org/contact/", "v": 0 },
	"16ENDyUPcRF9SSpFxabBYkxictmW7taoJf": { "n": "SureTraderBTC LTD", "l": "http://suretrader-btc.weebly.com/dashboard--statistics.html", "v": 0 },
	"1AxCtDG17nZ9mLarN2pTkyjFUsKaQ1sZt1": { "n": "A-Ads.com Apsolsi", "l": "https://a-ads.com/ad_units/200867", "v": 0 },
	"1NB5LYyh1bT93mMAnLPz53t49BTiynN2Yj": { "n": "faucet.withbitco.in", "l": "http://faucet.withbitco.in", "v": 0 },
	"1Lotto3rE6pETWJmUet5wi2Qf1V1WhDArP": { "n": "FreeBitcoinLottery.xyz", "l": "http://freebitcoinlottery.xyz/", "v": 0 },
	"1BN3s5ikAdMdRaS3mQFx6jSuPRwhWbTH63": { "n": "Krambil Network System", "l": "http://krambil.ddns.net/node/3", "v": 0 },
	"18ABe5rhZgLR6zdH27hDWp8DdTkWKJoKwo": { "n": "PoGoMap donation", "l": "https://jz6.github.io/PoGoMap/", "v": 0 },
	"32SxG2967PaYn2X8UNpvgfeJkuB2kiRe2w": { "n": "Bitcoin Assoc. Switzerland", "l": "http://bitcoinassociation.ch/", "v": 0 },
	"1263abH9YJoHU1FwFu3DeRJ5YtKouNFhBB": { "n": "Humpty Dumpty", "l": "http://plicpad.com/cletus", "v": 0 },
	"1111KiuFyqUXJFji8KQnoHC5Rtqa5d5e": { "n": "76561198312069687", "l": "http://steamcommunity.com/id/ez4hacks/", "v": 0 },
	"1HG8ihzUxYWdsp2f7dVFGe6P3ns2BUJfB7": { "n": "1stmoney", "l": "https://faucetbox.com/en/check/1HG8ihzUxYWdsp2f7dVFGe6P3ns2BUJfB7", "v": 0 },
	"1GD6RnvwUjA8TTdmV7XTCZ3xdcTJQQyJee": { "n": "Facture cafe juin 2016", "l": "https://tasdecailloux.wordpress.com/12-2/", "v": 0 },
	"15xcrJXCCgdxXxi9swMMwUMbm3UuQLiGR5": { "n": "aes256.io", "l": "http://aes256.io", "v": 0 },
	"1AY1uwfVmvrPa2mxdyjZz9ox2Hn3tkZk1u": { "n": "Shulgin Donation", "l": "https://muckrack.com/link/oxK17/donate-shulginresearchorg", "v": 0 },
	"1KenrpiTXjVSgzrmM6B3fvchbKGuTvfdj2": { "n": "Truphena Mama Yao", "l": "http://btruphena.blogspot.co.ke", "v": 0 },
	"16NkMPpw6fVDrhSH6HFbduioGnbctjJ5nE": { "n": "faucet", "l": "https://faucetbox.com/en/check/16NkMPpw6fVDrhSH6HFbduioGnbctjJ5nE", "v": 0 },
	"17sJZCctrh8wiVy18CYRu8o6jKjBiXb28F": { "n": "HaoBTC", "l": "https://www.reddit.com/r/btc/comments/4nmo0c/a_closeup_look_at_the_haobtc_mining_farm_in_china/d48nogw", "v": 0 },
	"1MCqX7qe8gXhqTSkipkAjvrAeN4aQfSXQi": { "n": "Btc-Multiplier.net", "l": "http://btc-multiplier.net/invest-now.html", "v": 0 },
	"1Edokzn9QdrvXS5L64BdZQUsggKf9sFJhG": { "n": "Edox Faucet", "l": "http://www.edoxfaucet.win", "v": 0 },
	"19fUeAKYE9vKt5UZUJhiw2wdihjBGkMZpf": { "n": "Froilan", "l": "https://kristineekdotcom.wordpress.com/", "v": 0 },
	"1D28oumZjt9j2fiN2f4xS6AyLpeXThNVEU": { "n": "Canadian Bitcoin", "l": "https://faucetbox.com/en/check/1D28oumZjt9j2fiN2f4xS6AyLpeXThNVEU", "v": 0 },
	"1EdnoWbAfkn9Lz13vwXyWzoqXVu6GkAmWM": { "n": "faucetbox", "l": "https://faucetbox.com/en/check/1EdnoWbAfkn9Lz13vwXyWzoqXVu6GkAmWM", "v": 0 },
	"1change6feSoBHr957Zh5qmBrebA8oea7": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesmxY3yyK74cjHPKoTQjmHBR4xZ6N": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesG6wgmA8612BAHc8HHJUezQe38V3": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones2iaA7eijMrCUYYrY5xurwZNyYqU": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesVXijA24nHaaisqNSppd39wSSSwj": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesTY2VZPSGEYZEmQjAy8Sgx6RUoVs": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesSZLdEAVELfbDNweZST4YQ5ffbgJ": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesL3Cvs29sQFduReeMmmCtiFyi6Sn": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesFgTZRVcKFJP8KvF7DtknioDsymW": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesaekyqKAEBjCBRqd3A6X2XFNa9tr": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonespdWLMNfLNAvPAies2wuADFbaagL": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones9dRTPh4GnbhLEyfMR16WEq6mT5J": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"3Gdk8rHYXuFYV4YsMcg9vmZ9NxdaUtAGem": { "n": "NanoCore", "l": "http://nanocore.io/", "v": 0 },
	"14LNB3bVk29Dt1Q1GnwbusDx32Vhy4p1br": { "n": "www.mybitcoins.xyz JOIN FREE", "l": "http://www.mybtccoin.com/", "v": 0 },
	"1PhT6sdThjNSB6VUUSKTWw4R1NZyyypajH": { "n": "Secondsatrade.com EURO Up", "l": "http://secondstrade.com", "v": 0 },
	"1Ggbb7ETbG5tG4RAPgSQhNLNzRfqLmjQ4": { "n": "Secondsatrade.com EURO Down", "l": "http://secondstrade.com", "v": 0 },
	"1CvhmgTzhrrnS4AifSFX1BdcAhAzm9tY59": { "n": "rahim101", "l": "https://faucetbox.com/check/1CvhmgTzhrrnS4AifSFX1BdcAhAzm9tY59", "v": 0 },
	"13qH9VZM19ZaPjwRtsX2r6ShT1Qqh9PcNi": { "n": "Sumon996633", "l": "https://faucetbox.com/en/check/13qH9VZM19ZaPjwRtsX2r6ShT1Qqh9PcNi", "v": 0 },
	"1DdHKnwX5qHfrxhGFUSc7osk3FLbE9bvJX": { "n": "Cores", "l": "http://scheisse-bewerten.online", "v": 0 },
	"1AhSvot1gNTHJGMPyBPs8NFBCkMDq33f7w": { "n": "faucetbox", "l": "https://faucetbox.com/en/check/1AhSvot1gNTHJGMPyBPs8NFBCkMDq33f7w", "v": 0 },
	"1HY6LhZ2PzGymY6dWGbdHYSkvtyYrAtUBA": { "n": "Mikocon", "l": "http://bbs.mikocon.com/thread-17434-1-1.html", "v": 0 },
	"1KEkhy2N6rh7GBaTwGyuadrfTYzWAfSWPQ": { "n": "THE RICH ADDRESS COIN", "l": "http://block.okcoin.cn/btc/search/1KEkhy2N6rh7GBaTwGyuadrfTYzWAfSWPQ/", "v": 0 },
	"1AiqNnHDUCbS1tbVxDAyhLoDxT6C6yRRqq": { "n": "MIGHTY", "l": "https://webbtc.com/address/1AiqNnHDUCbS1tbVxDAyhLoDxT6C6yRRqq", "v": 0 },
	"1ePaya2ttvW2pZMPEHtWT22zkyGtRucxD": { "n": "ePay Payout", "l": "http://epay.info/", "v": 0 },
	"1changePPYPYdtt4myHh7Qg9cZ55fFk4b": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesWAgqNwYrHvufEAyTbfFrb9x4K9M": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesqKswgNtzWEh6WmaRKUZh62LgQEJ": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesZ9UkH1DGQKy3t6DVAbYeyu9kzRK": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesFV9bTp6gkPg42CD9fdEttKoLbAJ": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesugNTeUEhAbSfr1bZAmi4kQde3TT": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesCHBRYshFdZdk1ywm2Zu2yxxxenU": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones8QQqFwyQnQTT9G9JAMMSDBqQGdz": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones64KrfnVai8UYAq2rXngjg3BMbTq": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonest2G2JtjpfijTZEmKm6RPWK4yZPd": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesebjCSyujWLSGQieoDzJoc7cTxsY": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones2F3XuJwVySaohNv2wY9THSKAjFx": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1EVrCZ3ahUucq3jvAqTTPTZe1tySniXuWi": { "n": "Fairlay.com", "l": "https://www.fairlay.com/faq/", "v": 1 },
	"1D3BbcNEZEmV3TxMQQKAo6JPdenytRGx7b": { "n": "BtcBlock Pool", "l": "http://btcblock.us", "v": 1 },
	"1KYpNw1QxKp2WXT6GxjMarqjt7dVdcnSTo": { "n": "BaxterWorks Donation", "l": "http://www.baxterworks.de/zwei1_b.htm", "v": 0 },
	"1CgFYiAjchU3RhENHBqnhrpDPKDEJ7VJhx": { "n": "Babu Yao", "l": "http://www.watchmybit.com/Video/Show/b7933447-0fc0-45fc-bf40-860a6b86ac96", "v": 0 },
	"1CnKBYRvrgcBWBL5mP5PfoNZwnAtqCiWBR": { "n": "Saakush", "l": "https://ello.co/saakush", "v": 1 },
	"1BVxNn3T12veSK6DgqwU4Hdn7QHcDDRag7": { "n": "BitSquare.io donations", "l": "https://bitsquare.io/finances/", "v": 1 },
	"1JaajeLtrhEBHryGzvey1JbLrnkyV9apdt": { "n": "DONATE HERE", "l": "http://btcsoap.yolasite.com/Services.php", "v": 0 },
	"1Bwf6Wjno2nMyuBxpqqLMe7dAnwmzS3RxU": { "n": "Free BTC by bitStorm", "l": "http://www.bitstorm.in/", "v": 0 },
	"1LBoxy9ukGSLP3w67rv8yVZBXKYeBfi68j": { "n": "LuckyBox - Try your luck!", "l": "http://luckybox.cc", "v": 0 },
	"17wiZu3asfR5ztG1mRsdWsMRDufS12pqmF": { "n": "minecraft", "l": "http://vnmcpe.esy.es/", "v": 0 },
	"12pKLTcTXiibv99tU9iqPuQqHqu4KNpfWo": { "n": "Exchange Bitcoin instantly", "l": "http://ukash-wallet.com/bitcoin-to-paypal-exchange.html", "v": 1 },
	"1HoTELox2gnCNKRzw4iN8oGLUKSpLy6uaS": { "n": "Hotelgo24.com", "l": "https://www.hotelgo24.com", "v": 1 },
	"1changemHKW3HmgasUL76C4zGJC9PmMcb": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesUPyoHDQ2Y6h2zGnvwdr2XJuBtcY": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesU3p5U8LEYCWwM4urXkBdpGfNVG6": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonessEmw2RP9JYMiQhynFwDRBnepo7j": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneswjZmYHtraeS9H9KJjGKQkS1tXGE": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesLipAha8HJYVJZ1ZJuay3aLb7Wrx": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesXAp5RSh4w9boepiTVwXQQc56oiD": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonescdsaH5JzdvfqdZqAPEehwNS2kpa": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneswMe1wUyNE5MVJ51QkShjqYovm3W": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesLS3Cru1ZX7HFVjG5q17mRJui2KU": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesnSGJ5fWkAtETuKKjWE3M6Me3teC": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones1CtpoNtAgiFiygKTey1P9ZiLqEW": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1LjBQSHrtY5pXaNp4WWJ2MSZHZduc2yF9z": { "n": "Dan Carlin Donation", "l": "http://www.dancarlin.com/dc-donate/", "v": 0 },
	"16YhFXjpQhpbGRzhntJhFJaB36gY3bnm7Q": { "n": "BitRevenues - Free BTC Lottery", "l": "http://bitrevenues.com", "v": 0 },
	"1MPYyfoWK8CkAzhLzLLtZGa9dwEGT5dm2T": { "n": "neocities.org", "l": "https://neocities.org/donate", "v": 0 },
	"15KqWLV4h2t3buSJSQ8rytWF6rWw4KvUj7": { "n": "Exchange Bitcoin instantly", "l": "http://ukash-wallet.com/bitcoin-exchange", "v": 0 },
	"1JyBKjDNci3YwjRQ8iitspqcV2U94938uG": { "n": "BITCOIN BANGLADESH (BD)", "l": "https://faucetbox.com/en/check/1JyBKjDNci3YwjRQ8iitspqcV2U94938uG", "v": 0 },
	"1EPAYGjYkD8tCGN2tr1MvmuP3j2RuNRjKo": { "n": "ePay Daily", "l": "http://epay.info/", "v": 1 },
	"1DZbhosMN1K53TKUqXUrpZTZFhXWBibXEM": { "n": "Liberate RVA Freedom Campaign", "l": "http://www.liberaterva.com/invest/", "v": 1 },
	"1changebjSR741eEQ3Z31Lwy5swDSZme6": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonescFSvNbRfpzWdRB8tFi2iqweeRTo": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesdWTr2oQktafMd1Q3mEyYBDZPcAC": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones6MfmyuYY6kUYtUUQW3K3fjFZhxD": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesLeT7ddQ3RyUDQBxih2FgVuKFN3b": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesgCuJYZ69WSQ4JYQ1d1YjvL6S3an": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesHWYzgDUFWAWTKqiV7BggLXSdJXj": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesU3GjaGw1qqQKrNTDkYy64PpUEnp": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesFUWr8Usxj2MCnmSiewGiKvy9287": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesfn6R9kQirdy27qphdUJnddMUa6N": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesYfeXeyi6smN6fxayaLoeBUxtAL4": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesWf7kiCiecrQstferAZVwT1hy7bq": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"18zZuNR1smHVvLMGeM8jdFQktymwyvQRke": { "n": "Pablo PHG", "l": "http://pablophg.net", "v": 1 },
	"1BitEg9GnC5znKbjwJqW9WWMu61bvgAFKh": { "n": "BitEnlarge Deposits", "l": "https://bitenlarge.com", "v": 1 },
	"1BPAYcMyPUXj1F2fHzGp4apeCts1kiJhg": { "n": "BitEnlarge Storage", "l": "https://bitenlarge.com", "v": 1 },
	"12sJQYsyvKMHnjAjk6m3xyY3rCjw63k7P7": { "n": "Capital7", "l": "https://Capital7.cc/", "v": 1 },
	"14DrfrUPkD33AN8osUn4KB3aHJuF8Qj4b9": { "n": "Capital7", "l": "https://Capital7.cc/", "v": 1 },
	"1LTjASGK9n8XA88mQqmEjmd5xYjH92nUoW": { "n": "Capital7", "l": "https://Capital7.cc/", "v": 1 },
	"1ApZpvAYNzpar4uAKusH9Z4ZbcE4qBpcAt": { "n": "Capital7", "l": "https://Capital7.cc/", "v": 1 },
	"19XdvyWb3CpSt2cX5sZdnrJcjuDz62Ymm5": { "n": "BitcoinBetRed", "l": "http://www.bitcoinbet.cn", "v": 1 },
	"1D63Vb4dWoUCT8yaZtvJz5qXmxLfnCNTV": { "n": "BitcoinBetYellow", "l": "http://www.bitcoinbet.cn", "v": 1 },
	"1PtQCAHApGjZp8EQxH9irwR3boh5VEgXQW": { "n": "BitcoinBetGreen", "l": "http://www.bitcoinbet.cn", "v": 1 },
	"1Jxr7Bsqje1YPHQPcpeZWWimWUtnXQGkgR": { "n": "111111", "l": "http://block.oklink.com/btc/address/1Lp916ooERr6jUSDGwtvezAhJWAqvhYBTw", "v": 0 },
	"166PtEzrXoAHRbvp76F3qEokNCZquVWZ5e": { "n": "Asociacion Trisquel", "l": "https://trisquel.info/es/donate", "v": 1 },
	"13FiQb153nACvBZSxAWtjjU4JbY13nwvui": { "n": "bitcoin 2048", "l": "http://bitcoin2048.com/", "v": 1 },
	"13arDBZxARyKyKTQ5F16L3KimrbNGfoAQX": { "n": "satoshiforfree.com", "l": "http://satoshiforfree.com/", "v": 1 },
	"1PrPTu5thCjdpaN4hNX7iN5uH9cvh296b3": { "n": "satoshiforfree.com", "l": "http://satoshiforfree.com", "v": 1 },
	"1changef8tsUGFmx6989u93P3NBs5XFss": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneswGgP39wP4jqrX8rbdyCDwUZcn1o": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesCvcCA9kaQefbiVfCqUpCRTw8cPH": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesH7mawjfceHDjSYyiHRF3zR3kLa1": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesS9uTnrCCov8C5GdEtL14JtE5ZNB": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesfMTVwmA7ZgYMed2xtBCKz525wqj": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesN2TWqMUtCR6cVU6pS143AJV4noN": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesRuyoUhAAe4a34nRXtzRy6JP3w2P": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesEcQCeRtxUyR4mpAPADjxAstB1FU": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesmQoyyirgNfj2E3RLFxZZ89RKSyM": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesDP4Piyz1j6nxtpfeeZXE9xba7Ga": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneswcm3hB2BxKETXxAgN4E2M5oB1R1": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1A5cAcYW7a4eQqBGffPnvwwxfL7JwHXjUL": { "n": "bitcoinmultiplierx100", "l": "http://bitcoinmultiplierx100.com/", "v": 1 },
	"3Qe6Zfj7Dm3fa96HXp5u8GjDARAt2MHM9V": { "n": "btcde", "l": "http://bitcoinmultiplierx100.com/", "v": 1 },
	"1KFkwt3erAyVX6PAh8DXiGMietAQBNVnsg": { "n": "Bitcoin Address", "l": "https://faucetbox.com/en/check/1KFkwt3erAyVX6PAh8DXiGMietAQBNVnsg", "v": 1 },
	"1HtNUNPJSLVGWKCS5WDdYvFSi5fwAeQcZn": { "n": "faucetbox", "l": "https://faucetbox.com/en/check/1HtNUNPJSLVGWKCS5WDdYvFSi5fwAeQcZn", "v": 1 },
	"1DQFczZf8r6jp6NSny9CFJ4hXuPKCcUJa4": { "n": "satoshiforfree.com", "l": "http://satoshiforfree.com/", "v": 0 },
	"1HVs4xpwPkQwA1ASTkKJMRsazDwdHEnksQ": { "n": "Betandmine", "l": "https://betandmine.com/", "v": 0 },
	"1Ebb8NfVmKMoGuMJCAEbVMv2dX8GnzgxSa": { "n": "Bitknock", "l": "http://bitknock.com/calculator", "v": 0 },
	"14tMLv2wR8xzUrPBEGzrqBh753vMg1uryG": { "n": "Bitcoin Bangladesh (BD)", "l": "https://faucetbox.com/en/check/14tMLv2wR8xzUrPBEGzrqBh753vMg1uryG", "v": 1 },
	"15PXMfnyMaPGFkqgQXzMeQVDQUWisQwxeJ": { "n": "freebitcoin.site", "l": "http://freebitcoin.site/", "v": 1 },
	"1GqorSDs6BWv797C7LhEBTxd3x8qjLy1Mi": { "n": "Jmar Po", "l": "http://www.jmarpo.com/", "v": 1 },
	"1changewoMsVF4Vj7aQfzhNyotWHGKDGT": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesbxcxfhvqQT1iaEymPygNJsFDZPE": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones1xvyj4aMrnAfdqRFuScnFqqQy6P": { "n": "SatoshiBONES 1.5625pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesseK6kdaPBe9M9HpAa2dPzbq5hVw": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesr33j9W3DHVM7fySvo3TKEBLjFp1": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesEkrFSuctgNikZG5mDpTaaG5fhVb": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesHaNpZpsVQBKRT1a9aJA1BxF8T5c": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesqbnA7v8JL1ebGRiUaBuznHbv8P8": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesGMd6EHQXWeSF4QkCQVh3Rofw29y": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones7fJ442ZUGsB6BzZ2o67nv4vB8Kc": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesL998BwrQ3fEY8h7E3cvZY2jXfu3": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesSN7RMfpneFudfZ6rMGWVufp3vtm": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1Mm9Mg7K1M7vEeVBqX9mWmsWGBotnQ2jyk": { "n": "Open Mailbox", "l": "https://www.openmailbox.org", "v": 1 },
	"1Gn3EeEabAF2Djfaz9H4fsMNtATZLxiRJM": { "n": "freemoney.site", "l": "http://freemoney.site/", "v": 1 },
	"1FPSrJ3uf2X6Xa4CyHUPTmHGP3K155LWBm": { "n": "FreeBitcoinSite", "l": "http://freebitcoin.site/", "v": 1 },
	"1changeGhAXKoTEkMntbAe1VHh52jFQhh": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneshshZV8LU6DQ6s194Cv3YDE17SwX": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesWAJjUhSZ2mSbUcoPXkcqyTj8WwV": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesg51Et5vJWvVsPtc6zBAqcSsVLe9": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones5fRH432V9SCt7rYjsSWqoyiAJXh": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesS6Vfr83BM9GcoHY9HQsW1YMuK61": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesqqZUfaoqUGjXJa9GXdTyuRgjBme": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonespQsDHCNym9D7wvzatkB5TWQ4My7": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesBtTQvmQbYbswKL6iQEGmmZFxwdm": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesaRsWUvxsoWnNXEZeTyersdb5XW9": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesT9j1b3SDUBnBqrA9srysv1c7rER": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesrxXocT4Q3ctiQ3Ae83Cbfqj5z5C": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1FoXBiTQgG4zt9UocXwWWcdo5V54fZRrHK": { "n": "FOXBIT", "l": "http://www.foxbit.com.br", "v": 1 },
	"12sCpxuPV5Q6LY7Aw5NWi34msdcYNpcJhf": { "n": "earnbitcoinz.com", "l": "http://earnbitcoinz.com/", "v": 1 },
	"156JxFkqoRS9Jd3ijLNemtuqnGJpHjA3nD": { "n": "KERBTC", "l": "http://kerbtc.com", "v": 1 },
	"19BckCWzU8xLXS1AGuNzmr6eZGBTtoChfk": { "n": "bitcoin-yellow.com", "l": "http://bitcoin-yellow.com/", "v": 1 },
	"1NMjPrib3BL34GvZqk6uX4ELaCx8iK3952": { "n": "bitcoin-red.com", "l": "http://bitcoin-red.com/", "v": 1 },
	"1CNTgannCHSJndBuhNAUPB7ZuipHzJ1YNo": { "n": "bitcoin-purple.com", "l": "http://bitcoin-purple.com/", "v": 1 },
	"1m7vsz521X38JomphUnxka9fEQve8eo9r": { "n": "bitcoin-green.com", "l": "http://bitcoin-green.com/", "v": 1 },
	"1KQQux2j17gwxMVCkycE3TpmHbQv6wamib": { "n": "bitcoin-blue.com", "l": "http://bitcoin-blue.com/", "v": 1 },
	"1L2tjkCczSTaWuYT9obJvKYycCwDV5Pf7U": { "n": "bitcoin-black.com", "l": "http://bitcoin-black.com/", "v": 1 },
	"1Nr3Wp9U2L5XnetiyHVMfpoHT5U8qaMDPc": { "n": "bitcoin-orange.com", "l": "http://bitcoin-orange.com/", "v": 1 },
	"1DTA5u7NkGMoKgXBSxCgqGbns3JiUdR6GB": { "n": "free-dollar.com", "l": "http://free-dollar.com/", "v": 1 },
	"16EW6Rv9P9AxFDBrZV816dD4sj1EAYUX3f": { "n": "Bitknock", "l": "http://bitknock.com/calculator", "v": 1 },
	"1DARAMfSNtwZ8H36NFqopRryQgqTCr6b9V": { "n": "daramghaus", "l": "http://daramghaus.com/bitcoin", "v": 1 },
	"1PoSiGvikjQajfGAwGVZM8BYvczjwBsGiU": { "n": "BTC Slice Ltd..", "l": "http://www.btcslice.com", "v": 1 },
	"1GVbGY9rwx3imtVG29fRUoz81EyJtGXrqq": { "n": "RodoLace", "l": "http://rodolace.arwmontagememanutencao.com.br/rodolace/publ/rodolace0.php", "v": 0 },
	"19Wti2HLWgWsAcmDEX4JfJjcXqJkvdfY9j": { "n": "Free Bitcoin Bazar", "l": "http://bitcoin-bazar.blogspot.com", "v": 0 },
	"1change6Pj4SBSmPYFhr1pv71SYbwdjbr": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesF8PuD1xdy6EjuXnipWZPMZq1Vvr": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesaNu1DbBpVjFBWsVaSeSNjkQJziz": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonescnSsDr5wxbKD3LTCZQFtvSVTyxk": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesmrcLLX4JXuxXYgs2EkeoYMC4bAT": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesBa96LeVhUgy8TnaHXiHTbBXFUBr": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesvB9HhcAV585e8Bdq4TNt7buz2mh": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesZrRWas7hYj9rSs8ZgbEeg46EmvJ": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesG8uC7TjJn8EigXJiGXVZgMF3z3r": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonespW8kaVM1YP6vzrQ5aSTx77nip7L": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesPEFTxhtKLNLABT1XEL8DkXZicJn": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones8mQ4jjsxfbvorY7iz1Ugbago6KH": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1BvA53Hh9vNThq34vXr3Qizttjt6H6bbaU": { "n": "BitcoinFaucet.TK", "l": "http://bitcoinfaucet.tk/", "v": 1 },
	"179d4wsNPFQ24D9ayqpBgj3ny9dps7Qgoe": { "n": "BTClink.NET - BTC Adopt. Init.", "l": "http://btclink.net/", "v": 1 },
	"1JCXSd9L8iznXF71MX7gcQ9V5mfV19pdYt": { "n": "Free Bitcorn Faucet", "l": "http://freebitcorn.com/", "v": 1 },
	"1Q6iu6163a8YyVZnxQqEdgc3asFaWg4hxc": { "n": "AllThingsGO", "l": "http://thelaird.us", "v": 1 },
	"18fyEQXaZQgCbNoE5Qjs6W7Pnqc9Yp4PQD": { "n": "HUMAN RIGHTS FOUNDATION", "l": "https://humanrights.foundation/donate/", "v": 1 },
	"1LoshagintUV9vze3o2kzF7Hyv9kq2ivo2": { "n": "Official Loshagin support page", "l": "https://helploshagin.com/blog/", "v": 1 },
	"1L2Z3iWzHonKB9n9j2oScFwvnhdJPVV99M": { "n": "Carbon7", "l": "https://carbon7.cc/", "v": 1 },
	"19E2tAz8rw243wBdwU3qrYHuvChdzHH1er": { "n": "Carbon7", "l": "https://carbon7.cc/", "v": 1 },
	"1AoPRMXkRaw119xBQ2MkESmRFrg9cFz7x3": { "n": "Carbon7", "l": "https://carbon7.cc/", "v": 1 },
	"1CAwSLt6ooarcNB38h2Pw6Akwo7ew9EzPH": { "n": "Carbon7", "l": "https://carbon7.cc/", "v": 1 },
	"13M4aAbXbZiJQxyDW17NuQbFRhbjE38YUm": { "n": "Carbon7", "l": "https://carbon7.cc/", "v": 1 },
	"1EY8TJoDWqQz6xZpsobKeuVJXVrk1XrjK2": { "n": "free-dollar.com", "l": "http://free-dollar.com/", "v": 1 },
	"1changewyajCWmu836hFkaAaitW1GDSFt": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesTkC76Ddqs2qBEWgewJkK8jRT2Y8": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones4kKQNYWdUoE361xAhMtY5Pj7ivt": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonespukNkkKCcXVNbhSierQc8qBYUDa": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesRLR7UFFd7S8F5YCphi2M9xj148X": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesh9S13YrN8W6TgQufarZQezdKEFH": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesVTpf2tqs4dJupGrwqRXJ44js8G2": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones6XXQPx69Z5vRi659W8JxX5KgC9p": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonescQZLTH1GFZPjsxyFxz5pHTrVtn2": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesRTyFzv6hsKjxmvXFuZWyuiFK9R2": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesefDvys7TkGiswQn5iP4mzK5dzYV": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesiP6Udm8e6A8tYBTtYypVMeRcdAo": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1D2joWawRKySic8p4XJeUCB4YbcUquSbDW": { "n": "Carbon7", "l": "https://carbon7.cc/", "v": 1 },
	"1NhACLde1TcccN4uvhN8ir4RhBqXngCsmR": { "n": "science", "l": "http://scienceisvital.org.uk/get-involved/", "v": 1 },
	"18p9Ftp3m4435tdpZTvoBsm3yjUgkvTF2b": { "n": "Coinimal.com", "l": "https://www.coinimal.com", "v": 1 },
	"146js4Uj9Dq9tuikcSpZFrbfyriMpbWEsg": { "n": "Budyget", "l": "https://www.budyget.com/", "v": 1 },
	"12bL22Pynmp7pDtDqD2w9iP7dRzdM1gNUd": { "n": "supermax", "l": "http://webbtc.com", "v": 1 },
	"1spaceJjF4AvCuhC8ug6UZkuzFgYkXn5M": { "n": "Play our game for free BTC", "l": "http://www.freebitcoin.space", "v": 1 },
	"165B3jVeu3dPRLjDX1tBRTA8wFWmtzLZFC": { "n": "Carbon7", "l": "https://carbon7.cc/", "v": 1 },
	"16ZxAz5GgCb813j8bAzcjvwKU4ctvAbVgT": { "n": "mtfcoin.com", "l": "http://mtfcoin.com", "v": 1 },
	"14Dtxr3uiSxjKtzCBURxiYnMDwTJTfSaCY": { "n": "SeedFinder", "l": "http://seedfinder.net/donations/", "v": 1 },
	"15SFurWonkAj9MxtEWHamZUMfCCmqJJVMR": { "n": "uberpay", "l": "http://uberpay.io", "v": 1 },
	"1FULL9pbiRKGFCdSb8zQjhdv7hvRMGF33n": { "n": "Bit-Advantage.com Full Plan", "l": "https://bit-advantage.com/invest/deposit.php", "v": 1 },
	"1LiTEraoxttrNKJ7M51Tem63o3nC73WhXi": { "n": "Bit-Advantage.com Lite Plan", "l": "https://bit-advantage.com/invest/deposit.php", "v": 1 },
	"1ADPAY2LMt2VWRJE2LhbwP3VRWaSaQCutu": { "n": "Bit-Advantage.com Hot Wallet", "l": "https://bit-advantage.com/invest/payouts.php", "v": 1 },
	"33xYtrmv7aMbkiRVRTV3CQHw8TWo1NjbhD": { "n": "testing", "l": "http://cd476457.ngrok.io/fa.html", "v": 1 },
	"1MFwHEAW7wETV2qiEGJhJxDN1yvYi2dNcK": { "n": "gbay3177", "l": "https://faucetbox.com/en/check/1MFwHEAW7wETV2qiEGJhJxDN1yvYi2dNcK", "v": 1 },
	"1REfPrNNwHQXjD8pgjCM49gFyF1j4BEGp": { "n": "BTC Slice Ltd..", "l": "http://www.btcslice.com", "v": 1 },
	"1changerhBN5XRNQwoT3BYcHai87RemGi": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesr7ELVnEGa5PBXpkncU2gujZMEkf": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesKEqxfQroJU3qTnGDRLVDNhuderZ": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesHGTotgiyywiK6x9RhgfCwz1R3ow": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesjbAK3RwaeKBJeenWnjpCmSvWhw1": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesWvs7fUqpydS91AvXP826x5bWj2v": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesJnQbVmaETrLkEFo2LhbJM9znaNp": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesLcdLnLYFPBrPppkqjvriweBcmms": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesm4iGmCzBFDxomqLmJPJnQXsoYnz": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesQkHZDWXReyPRUcVcdPrLDP8X2hL": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesTBj4u6tFRQPsrqJ5KVD1qu7ZURG": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonescpVQjF6pYu3d2d3B8zJJjmzsiWs": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1HKqKTMpBTZZ8H5zcqYEWYBaaWELrDEXeE": { "n": "Brainwallet - test", "l": "http://www.palkeo.com/code/stealing-bitcoin.html", "v": 0 },
	"1HoSFymoqteYrmmr7s3jDDqmggoxacbk37": { "n": "Brainwallet - hello", "l": "http://www.palkeo.com/code/stealing-bitcoin.html", "v": 0 },
	"1EonsrGHwjiY1XgjBHPW7M5SHxjzfLLeo8": { "n": "EonComplaints", "l": "http://eoncomplaints.org/Donate", "v": 1 },
	"1LazyVt7YB3EvpXsBBQGhsFzDmztypqEZj": { "n": "Nexus Original", "l": "http://lazysoftware.link/", "v": 1 },
	"34Zxh8UYaFisnjcCGCMdeLnpz7E2zU3uKD": { "n": "BX.in.th Cold Storage", "l": "https://bx.in.th/info/transparency/", "v": 1 },
	"1JqMxSMuQxLYe7s3A59NaBj9eLZMoKUaU6": { "n": "Energy Control (Spain)", "l": "http://energycontrol.org/participa/donacion.html", "v": 1 },
	"1changeLmgyRTLBTnvwisSoaPU6k6G5iV": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesbp1xPCV8BoTNDLRQ8teHd3oS9Js": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesRfXFrTRqizqcS3sSonJVQZcGCrX": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneskbBYshvTMTt2d6g74LYTnwRxVG7": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesczmB3tVkacuhevVkFbScQQkWUnU": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesJEdbeQ1BU2H7XUr1vZ1deDRr5G8": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesobQxRmohiNarHtPjzDuzcEL14m6": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesSnRjPrHnvU7kihVPJmPqUMA5jWY": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesX9GjhCJckWhhsrHRnff7tYJEwBd": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesp16oHHJ4xWbG8NEMTTUDVHsSZPL": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesNiAZLjesQmm6Xm1qcxLmE5AjZoa": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesuhPPgzMngmGanjNxHKQN7QCb5qX": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1FTyTfcNKNJYAPqCKa4gbbDKoJh8RwVnrR": { "n": "microbitcoin", "l": "http://www.microbitco.in", "v": 1 },
	"151T7r1MhizzJV6dskzzUkUdr7V8JxV2Dx": { "n": "myBTCcoin Pool", "l": "http://www.mybtccoin.com/", "v": 1 },
	"1FxkyjDb5CBMmYevvvCEfuNAVdHuKSJspi": { "n": "bitknock", "l": "http://bitknock.com/calculator", "v": 1 },
	"1GVSJKcFiN4Cr4dzF7LRGehxoc7g7poyGy": { "n": "ucing", "l": "https://forum.bitcoin.co.id/members/ucing.2702/", "v": 0 },
	"1G4DixxudqaW9LP9wz9Ayd9akn9GZg2qDo": { "n": "PIOVMONEY.BIZ", "l": "http://piovmoney.biz", "v": 0 },
	"1ENX3q8A8qYzTY2gnyt9ZM8FFxFS96hyrA": { "n": "ucing", "l": "https://forum.bitcoin.co.id/members/ucing.2702/", "v": 0 },
	"1KQWwafiHNRy9FNU8XkPq5HKvJMispa8HB": { "n": "Natasha", "l": "http://www.investspot.biz", "v": 1 },
	"1A5jpTB8JtvzDCJxpxyCGwe2yum3eLZZhk": { "n": "HYIP Monitor", "l": "http://www.investspot.biz", "v": 1 },
	"1GNkxJ5n44f6WKPftYmsQZuDduGSCQy3Q3": { "n": "InvestSpot", "l": "http://www.investspot.biz", "v": 1 },
	"14bezsBg2ThhX17TY3drywUpJDPnvd66RZ": { "n": "free-dollar.com", "l": "http://free-dollar.com", "v": 1 },
	"1KTjb2u7PktKM9vfwWiHw25EnauJ2KKRBC": { "n": "www.investspot.biz", "l": "http://www.investspot.biz", "v": 1 },
	"1L6nEyp5eUauuCyGBrvk8ff8HWNaD1zCit": { "n": "HYIP Monitor InvestSpot", "l": "http://www.investspot.biz/bitcoin.html", "v": 1 },
	"1C4Q1RvUb3bzk4aaLVgGccnSnaHYFdESzY": { "n": "Voat.co Donations", "l": "http://voat.co/inactive.min.htm", "v": 0 },
	"1BruAQTEm6Qxzvx8B1gsQumoqsdHcdUeZg": { "n": "Lite Cash Gateway", "l": "http://lite.cash", "v": 0 },
	"1HELPDLTmLqNaiajyLi1guUbPP3Yn94erA": { "n": "Official Loshagin Defense Fund", "l": "https://helploshagin.com/", "v": 0 },
	"1Kc2dMfXhgWaW22wEEVXY7feuXP3uusjnD": { "n": "chokri29", "l": "http://chokri29.esy.es", "v": 0 },
	"1CdUgoFmf95hmnjh74mNxu8uexuXXsvZJj": { "n": "Secondstrade 5Seconds+3 Down", "l": "http://secondstrade.com", "v": 1 },
	"18FFTJysAy4frZNTuBaPVfSCeDgrmiNrnh": { "n": "Secondstrade 5Seconds+3 Up", "l": "http://secondstrade.com", "v": 1 },
	"1G6FDY7Ut31uujxc69issEPkQe9Bue1N1r": { "n": "Secondstrade 5Seconds+1 Down", "l": "http://secondstrade.com", "v": 1 },
	"1FnuR47ELtLaGAZe4kdVrcyLoGZzvFDoJP": { "n": "Secondstrade 5Seconds+1 Up", "l": "http://secondstrade.com", "v": 1 },
	"1MRkLMumN9CVVmEGpbbJUXxuFAUsBBMKgs": { "n": "Secondstrade Odd-Even Down", "l": "http://secondstrade.com", "v": 1 },
	"1K3iJm1A7CwdGxMmmMQVDAsau3mSeEwfCz": { "n": "Secondstrade Odd-Even Up", "l": "http://secondstrade.com", "v": 1 },
	"1bA21Dz1AWMTbZhmZSwsUamy2S6nzVJRJ": { "n": "free-dollar.com", "l": "http://free-dollar.com/", "v": 1 },
	"1AjqZqErxsnwnrgk5HaEV4Cnte1gh9yJeZ": { "n": "Wolfcastle Bitcoin Gambling", "l": "http://www.reddit.com/r/Bitcoin/comments/3atmi0/who_owns_wallet_1ajqzqerxsnwnrgk5haev4cnte1gh9yjez/", "v": 0 },
	"1JPffqr2GgA84XzaJGQG6HWx5M5jPfx2ir": { "n": "girlbtc.com", "l": "http://girlbtc.com", "v": 1 },
	"1KEEQ2MmeBagYmT8uSj9nG3FoVBCr6z4cS": { "n": "girlbtc", "l": "http://girlbtc.com/info", "v": 1 },
	"1Bdfodm6PqKjpsJhH9oGafyyKWNWjoYgyN": { "n": "girlbtc hot wallet", "l": "http://girlbtc.com/info", "v": 1 },
	"1DbGDh8U4CMfsdiJ4Ut3M41Ztho7ZjshWH": { "n": "BPOZIT", "l": "http://bpozit.com", "v": 0 },
	"1changetTft76zSqw2sogS1eBj2GyhvS9": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesk7Se6VcWzCJrC7fA2WwkMh7rf95": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesYQ7XQoqSSbV8NEMhVB3dxZvB6Jh": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesvzmJHGkw7D4XQpLnKeKtviGznNa": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesGT3C9UAocgXXx1SjoHv8GQtHyB7": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonestmSzjmomM2oLTKNDC1SM7xtMWAS": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesPx6k6dF3tdcDYGz2zaXHdPYFJ8Q": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneshNsDuWm4d5fysSMcXAAeJ6McPaF": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones2EPT424zX79c94sTwWBHMmHneF1": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones5fazyqWT8iJLNHMxopLUqDVkovd": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesdwPxp1Uv3xrDjy2yFHefA6TFm11": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesj2Efu4pvJoSnkUJnP5edREvXMPf": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1DNgdwsFkX1dtCnYiAKSd4zxAuwgv2jhie": { "n": "Bitnodes", "l": "https://getaddr.bitnodes.io/", "v": 1 },
	"1ServV3SRdrDLN4bQgbYTotaiQBxETQ7K": { "n": "Servchain Main Wallet", "l": "https://servchain.com", "v": 1 },
	"1CdJi2xRTXJF6CEJqNHYyQDNEcM3X7fUhD": { "n": "21 Inc.", "l": "http://www.reddit.com/r/Bitcoin/comments/391l2e/21_inc_caught_them_finding_another_block_today/", "v": 0 },
	"194kmyNsRxonYYS7e8zBfro4n45YDiN2aj": { "n": "Blinko Blue Game", "l": "http://blinko.io", "v": 1 },
	"1KvYT82JhJLhZTnVsp3MwPnFJLkc73Tn27": { "n": "Corbett Report", "l": "https://www.corbettreport.com/", "v": 1 },
	"1Da2oFBTSjaucJmqC9W5kPFhFa5cjJzwom": { "n": "btc-multiplier.net", "l": "http://btc-multiplier.net/invest-now.html", "v": 1 },
	"1BigWinx3wsfKVGeidmjYhy4qt6W38stkU": { "n": "1BigWin.com", "l": "http://www.1bigwin.com/", "v": 1 },
	"1BET888zfDtMCqaN58XEMGn3YmGhUubUFV": { "n": "1Bet888.com", "l": "http://www.1bet888.com/", "v": 1 },
	"1BetBTCjqAQsjoAX1X5yrqdjXyPdEnj9Lf": { "n": "1BetBtc.com", "l": "http://www.1betbtc.com/", "v": 1 },
	"1DiLcxg8GyV44h3dKYRQ8Xc3ScHFnX6DyQ": { "n": "Streamium Directory", "l": "http://streamium.directory/", "v": 0 },
	"1Ldumk6zZC5mrJojTToUvJPvaacNC5NnAN": { "n": "james", "l": "https://www.youtube.com/user/8z/about", "v": 1 },
	"1BwZeHJo7b7M2op7VDfYnsmcpXsUYEcVHm": { "n": "bitknock", "l": "http://bitknock.com", "v": 1 },
	"1Coin8DJdiQShohNEjxXrh2nBXCbTUPnkn": { "n": "Coin888", "l": "http://coin888.com", "v": 1 },
	"1Coin5CWWJjQzvSqoLUF2nAC1D8acZMmXQ": { "n": "Coin888", "l": "http://coin888.com", "v": 1 },
	"1CoinQPke4qrWDc9ZTP4eHcfrXkepfaBjh": { "n": "Coin888", "l": "http://coin888.com", "v": 1 },
	"1coin8fhBYHch3azmEGARuajmBHgzV4bj": { "n": "Coin888", "l": "http://coin888.com", "v": 1 },
	"17cnkZDmT6aAcY5hV4KthbEtM7sXgLZjr3": { "n": "ePay Receive Bank", "l": "http://epay.info/", "v": 1 },
	"17owg8RWb73qfE5HeQk6gg6RAgEUfxPXks": { "n": "Bitfinex Hack Address?", "l": "http://www.reddit.com/r/Bitcoin/comments/36v29t/bitfinex_hack2252015_1459_bitcoins_lost/", "v": 1 },
	"1ePayGTFThSqYd1z3CiexTpyTKuSc61dK": { "n": "ePay.info Instant Payment", "l": "http://epay.info/", "v": 1 },
	"1ePayqVeHNFFdQsmGwrHzuci4KX2aYSu1": { "n": "ePay.info", "l": "http://epay.info/", "v": 1 },
	"1EPAYzY8r91G1pNZVWHYm5rfB9tuxhBky8": { "n": "ePay.info Instant Payment", "l": "http://epay.info/", "v": 1 },
	"1EPAYji8HW278XeqKnzEESJNKcArMa59A8": { "n": "ePay.info Instant Payment", "l": "http://epay.info/", "v": 1 },
	"1EPAYQyDnDGP6hb3LvSpQBfjwB8ZJP3uE6": { "n": "ePay.info", "l": "http://epay.info/", "v": 1 },
	"1EPAYXU8dVjcESpeW3hCmbVZ7hhiZ6ou6X": { "n": "ePay.info", "l": "http://epay.info/", "v": 1 },
	"1EPAYS8RXWyyNoTu468MA28f4HfSyxhSXP": { "n": "ePay.info Instant Payment", "l": "http://epay.info/", "v": 1 },
	"1EPAYe6TJbnryPL7dLTKwyEsdSnLrbnkcn": { "n": "ePay.info", "l": "http://epay.info/", "v": 1 },
	"1EPAYAUNMXQBoEjfbkoyYFDwQj3WynjW5n": { "n": "ePay.info", "l": "http://epay.info/", "v": 1 },
	"1EPAY1Zr2H1FmXfpChKHKuKPvuvTjrAzk1": { "n": "ePay.info", "l": "http://epay.info/", "v": 1 },
	"1EPAYgChFokR7tQRGiAkmUff5FNeqFsftG": { "n": "ePay.info Weekly Payment", "l": "http://epay.info/", "v": 1 },
	"1EPAY5Pt5sNgDmRfi9Xx9ErsBycUNzhFe2": { "n": "ePay.info", "l": "http://epay.info/", "v": 1 },
	"1EPAYcJY4tdRA26MHEg7mSbLKhy4yLi79G": { "n": "ePay.info", "l": "http://epay.info/", "v": 1 },
	"1HvDBXN4k9KA7yTW5rppJvGM18gEFc3wX1": { "n": "Blinko Blue Game", "l": "http://blinko.io", "v": 1 },
	"1changeAs7XXkzjvHKGiZtePSjZZuwgwe": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesKnx7r1FCnyXyLSTE9eRL9dLGpwW": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesob8WutZwgJV1xEh5DSPtECv9C35": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesp5NNRmq15rVXe4gqSxTMjBSHSev": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneskWEzJwZxyAoHrvKUEhZ8mvZmuL2": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesMTsVECvvA1Ph7F1mb5mAUzuWCXX": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonestqFcsh9YKzvCyFYcPc1J1n3RBuZ": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesTYPmZa6RUTkPA6z7NfFxHmja5BY": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonestAkEHrJ9q8LicHi8B41CfmWXFBM": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesRifnNieWmvfqa7xhP3Cg79xtodi": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesy6ShU3PyTWt8cn8F5ZQnSCcqsva": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesHj7dpwWkxaGEfGssJiSfD35jY4v": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1UPRSRjp7SsbvEcecBdGsMaTApdTqjte9": { "n": "UPRISER donation address", "l": "http://upriser.com/", "v": 0 },
	"1Q1BXygpUjuA13YCqNkPHUX33Vp8r3vDWz": { "n": "CCMINER.CF", "l": "http://ccminer.cf/", "v": 1 },
	"1rwQKTcM9gmPXYT5b1wjz7DAfP2ScoXFd": { "n": "BTCAddress", "l": "http://www.thex20gaming.co/shop/", "v": 1 },
	"13QGkj3heDNd4ojspm8nqNod1RMT5mjMec": { "n": "bitknock com", "l": "http://bitknock.com", "v": 1 },
	"12WZ9JDd6kLh8dCb6acCmUMdCegqYAe9HF": { "n": "bitknock Cloud Mining", "l": "http://bitknock.com", "v": 1 },
	"1TpEBAKU7jzEcdx6zqDxjfTU1EApUyGJW": { "n": "THC RECiPES", "l": "http://www.thc-recipes.com/", "v": 0 },
	"1KWiP91a29CP5w7DD76NozKyCSgdhVDxbE": { "n": "Kwip.xyz", "l": "http://kwip.xyz", "v": 0 },
	"1HiPHoPL9bzLj7Z59jugvETZyv9qJ4EPDL": { "n": "The Hip Hop Realm", "l": "http://www.hiphop-realm.com", "v": 1 },
	"1LapTopvKkbk792wE7wJYUUfY5Yx2uFh7U": { "n": "LapTop", "l": "http://www.pcheaven.eu", "v": 1 },
	"1ShibekBzeEXyGqizbrojFT56YwDLNAXN": { "n": "TheMatrixShibe", "l": "http://thematrixshibe.github.io/BitTicker/", "v": 1 },
	"1snonce4wha57crBgKsR2QdosMbon5bnz": { "n": "SATOSHI NONCE", "l": "http://www.satoshinonce.com", "v": 1 },
	"1K2bCjh1aHtCekXzJGunsjHuXHXqoaYJFz": { "n": "1K2bCjh1aHtCekXzJGun", "l": "http://www.reddit.com/user/1K2bCjh1aHtCekXzJGun/", "v": 0 },
	"1KxEwKcNX5NNsHgvLjwAZcwdNgdJLd6jJr": { "n": "Bitcoin House Taiwan", "l": "https://bitcoinhousetaiwan.wordpress.com/", "v": 1 },
	"13HJCEvSDFbmgTx4c6mR9rpSskm8Bbvb5M": { "n": "Secondstrade 7Seconds Down", "l": "http://secondstrade.com", "v": 1 },
	"1JEcvUbng9BV2CEqLs6apy57NBugimznJM": { "n": "Secondstrade 7Seconds UP", "l": "http://secondstrade.com", "v": 1 },
	"18u3UA6Cshu3tCFPerLpmNp8GyYpkEjUiS": { "n": "BitcoinWhosWho.com", "l": "http://bitcoinwhoswho.com/", "v": 1 },
	"12TEhGcnETepYD9p2xhqUpja3gvdbUUHUJ": { "n": "Secondstrade S&amp;P500 Down", "l": "http://secondstrade.com", "v": 1 },
	"15yWz6Km6PkjKiBxSUdVPyJdoJVXv35sg8": { "n": "Secondstrade S&amp;P500 Up", "l": "http://secondstrade.com", "v": 1 },
	"1HnBPMk3rJ8NyE5HmDGhtceMkfQXVBh41U": { "n": "Secondstrade NASDAQ Down", "l": "http://secondstrade.com", "v": 1 },
	"1KqqzSrhWMs6QZk9b28XoCwKCQJZqNBTH": { "n": "Secondstrade NASDAQ Up", "l": "http://secondstrade.com", "v": 1 },
	"1D4HdjT455fttBANzmi7qF7EvMNXNsxRBN": { "n": "Secondstrade Silver Down", "l": "http://secondstrade.com", "v": 1 },
	"19TemN2tdUa5jzAZEFxA4mZ9k7zyaan8BV": { "n": "Secondstrade Silver Up", "l": "http://secondstrade.com", "v": 1 },
	"16p2NgW4nsGtQtZ1b2R9r3Xa2xHXwpjQVd": { "n": "Secondstrade Gold Down", "l": "http://secondstrade.com", "v": 1 },
	"156BsQ64dWAGGNNuHjMnPtkcTcQDUvGbM7": { "n": "Secondstrade Gold Up", "l": "http://secondstrade.com", "v": 1 },
	"14zgTJRSaJzPxFHzAteLLWEDhH6h4JyY65": { "n": "Secondstrade OIL Down", "l": "http://secondstrade.com", "v": 1 },
	"13KNwabgcpkkYBfyBD15d7WmpZjbeK38Ju": { "n": "Secondstrade OIL Up", "l": "http://secondstrade.com", "v": 1 },
	"1GYsaNMipGM4YcXmpvun4zgMvE9aLuReoY": { "n": "1111111111111", "l": "http://qukuai.com/address/1GYsaNMipGM4YcXmpvun4zgMvE9aLuReoY", "v": 0 },
	"1PDQU21hNBSnsxC7c55q5qtDwhn5s1oLQR": { "n": "PIWO dla ZYCHA", "l": "http://dziobson.net/zbiorka/", "v": 1 },
	"1bonesJf3NR5F8AB7y1iXob7TnkjP8HKU": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneskzpToXkNhbCVwJqLGayFtN6VwAU": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesbLzEc8dYJF8sCPVmYPK4dszpmWn": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesbNxVzG5qCXE9gDfWxCR5Z5bYhjv": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones5C4Q5x2V7bTsU3eEeZKPthCGFgN": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneskT9upmxgFDhEWEW5Z7G6cJ7oGMq": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesv1vFF9ANRLjpAcZayvVupCBC6Vr": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesgMEU4WvrTA8SE1ocYAPK26pCuD9": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonestyHtWhFmofEKrUvna2AcFtmb3tq": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesVanRdKf6rXENh5gogrLUKNbH6Ni": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones3Z2oPZbJPyNV5g6mr4SPw9ZBM4y": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1change86P8LyxVDB44GQsVAqbWtobtH1": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1BmZW65ZoeLa1kbL9MPFLfkS818mqFUSma": { "n": "Open Ponzi", "l": "https://open-ponzi.com", "v": 0 },
	"17VqX3BoK9Yjn96n31ShJpraiBa52VrHUB": { "n": "Coins 4 All", "l": "http://coins4all.ml", "v": 0 },
	"17hxeNzSThGXFpsNWQxgnkYSaxHMWiJXpL": { "n": "Fake Bitcoin Wiki", "l": "http://en.bitcoinwiki.org/Donation", "v": 1 },
	"16MqkhCriwHtGhxWWSnU7oWWDSaHJJzJEX": { "n": "BitcoinField.net Investments", "l": "https://bitcoinfield.net", "v": 1 },
	"1NnPDnGuLjqTSYEZgneErbS1jMGqGhiFZx": { "n": "BitcoinField.Net Invest", "l": "https://bitcoinfield.net", "v": 1 },
	"1NgjTgYpCKbEsYPYoHKRFa2T74DEU6iaYY": { "n": "BitcoinField Invest", "l": "https://bitcoinfield.net", "v": 1 },
	"12fEq81az7p6yvMgpmrWLBAZMJbhgt1UMv": { "n": "Removed", "l": "https://faucetbox.com/en/check/12fEq81az7p6yvMgpmrWLBAZMJbhgt1UMv", "v": 1 },
	"35MvT575mUiiDBxwbncK7gt6zYHQzT23SF": { "n": "GoPonzi.co", "l": "https://goponzi.co", "v": 0 },
	"1KKLYjd7AZfjZXeKHUmJy4TPNBUZbntT3q": { "n": "DiceBits Provably Fair Game", "l": "https://dicebits.com", "v": 1 },
	"16RiiW3wUMiid8eYXCvE8F1uj8WDUvuQUy": { "n": "BTCGAW scam", "l": "http://www.reddit.com/r/Bitcoin/comments/3279zm/btcgaw_is_a_scam_after_saying_i_will_expose_them/", "v": 0 },
	"1N6heMWD34ARyApkRmNv7V7NzQfYvgC4dg": { "n": "privacytools.io", "l": "https://www.privacytools.io/", "v": 0 },
	"1Q8M87yTySES5cS44gjapr2Uw7WCV58oQC": { "n": "Crypto-Miners.Club", "l": "http://www.Crypto-Miners.Club", "v": 0 },
	"1HALviNgyCKeFD3Qcd83GuVMHgiiHvaGBP": { "n": "Halving Faucet", "l": "http://halving.pw/", "v": 0 },
	"1NpQaXqmCBji6gfX8UgaQEmEstvVY7U32C": { "n": "8chan", "l": "http://8ch.net/faq.html", "v": 0 },
	"12MhRP1Ryd1wpqTqNnDL6H3gCT3SGf4Wbo": { "n": "Halving Faucet", "l": "http://halving.pw/", "v": 0 },
	"1nexusLT4Bh7SDgPbxTxZbyqGcphRMvkS": { "n": "nexusosx86", "l": "http://nexusosx86.com", "v": 0 },
	"15NMt35wDgqoiZikEJDCFDySjsaz7X9ynp": { "n": "Secondstrade 5seconds+4 Up", "l": "http://secondstrade.com", "v": 1 },
	"1CcxDkENsFc2gUmii8FDwoprSqCoBMgtFi": { "n": "Secondstrade 5seconds+2 Down", "l": "http://secondstrade.com", "v": 1 },
	"1CabKXvPaJmgXXY3ELSoKj4KCWPWQ71zjw": { "n": "Secondstrade GBPUSD Down", "l": "http://secondstrade.com", "v": 1 },
	"1E9VgosJ5o1VXTRARME91iYtvMytYj7NEN": { "n": "Secondstrade GBPUSD Up", "l": "http://secondstrade.com", "v": 1 },
	"1DUfJYAn4j5qRXE9nDmncn9smQeSJHJcXm": { "n": "Secondstrade USDCAD Up", "l": "http://secondstrade.com", "v": 1 },
	"1ARF7D3a1CTUP2ej3UNuLSY54VnftKNfPm": { "n": "Secondstrade USDCAD Down", "l": "http://secondstrade.com", "v": 1 },
	"1DvbMAdHhDpcEovqnV1KWoSuaeh3wuptPt": { "n": "Secondstrade AUDUSD Down", "l": "http://secondstrade.com", "v": 1 },
	"1ApTyBha6KVUvdjVMCHNzESPEV4k4bU6ZY": { "n": "Secondstrade AUDUSD Up", "l": "http://secondstrade.com", "v": 1 },
	"1JrkmThQJKrFg5qRvZqUkR1f8Dn61cd1V": { "n": "Secondstrade USDCHF Up", "l": "http://secondstrade.com", "v": 1 },
	"12nCTHwoT4ar7gQZ48hnqHgy29VQoS6DRi": { "n": "Secondstrade USDCHF Down", "l": "http://secondstrade.com", "v": 1 },
	"184FKkT4Rzbm1obfh5Jm4uoPY5gEAdXtBv": { "n": "Secondstrade USDJPY Down", "l": "http://secondstrade.com", "v": 1 },
	"1DECQ2F2pL5aa2TpRoNM8AwfkRPdK4bEZ6": { "n": "Secondstrade USDJPY Up", "l": "http://secondstrade.com", "v": 1 },
	"1AbqpCSYzummeuMSrVsXVNjqf9kxkitt1Q": { "n": "Secondstrade EURUSD Down", "l": "http://secondstrade.com", "v": 1 },
	"1AoBKtttDf9PKLzqnkVLS34g9qWdLZFtyP": { "n": "Secondstrade EURUSD Up", "l": "http://secondstrade.com", "v": 1 },
	"3DcsunzNr8NEH15xzKZNvHobTrTArGZasG": { "n": "BlockDozer - Mining Pool", "l": "http://www.blockdozer.com", "v": 1 },
	"1bones3r9KggXrYb2HmvkjezFcrYiuKBr": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesXBCGsiHLgMbUB3kgk6w1bgcf2vM": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesYbGQJjzMds2fYNXyad1eMoeNAaT": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonestfpRPg18aBwxMiqkB8ZDWzsRcNr": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesZ4zP9RAtPGfi5JwnAcMjyt1r6DC": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesLdJqMy73agCV6zKAYPHaPCyQYtz": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesgPge6gAqmMijxCTeebaYm6Qj12N": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesvxegnxD29dECWcZMxigXrndoD64": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonespDFBXMFUm7nLBbpSoWLM4372q9n": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesukCVwNxVPmguvp6tcvJC7tKZ9Q2": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesvic7Vy5n5bm9venYHGoz8UNwDbv": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1changePZFvbZivGRy31NNJ21Xf5tPGuV": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1MswQSh6RobY7sCcFhZEmoMuHbRV8zovAu": { "n": "Secondstrade BTCUSD 720M Up", "l": "http://secondstrade.com", "v": 1 },
	"1fbBG84MCnGDMrMk5obp72NJnk1tt1n38": { "n": "Secondstrade BTCUSD 720M Down", "l": "http://secondstrade.com", "v": 1 },
	"1JJHP7ug9mD9KCuDRWHYau1TdqxFtLtNur": { "n": "Secondstrade BTCUSD 30min Down", "l": "http://secondstrade.com", "v": 1 },
	"1GZFqVE9MPVwWcy1KffVuDAaZFqEFSzy1n": { "n": "Secondstrade BTCUSD 30min Up", "l": "http://secondstrade.com", "v": 1 },
	"1EVEW5yB5VtqUJBvCQTDB8AE6wCfBchFSi": { "n": "Secondstrade BTCUSD 15min Down", "l": "http://secondstrade.com", "v": 1 },
	"12pF8r3stKkJUGJcMhN6AmJa51dkv93dEc": { "n": "Secondstrade BTCUSD 15min Up", "l": "http://secondstrade.com", "v": 1 },
	"1UUjwnKWyqKw9Svj2D4f5cvgMYagUqTBg": { "n": "Secondstrade BTCUSD 5min Down", "l": "http://secondstrade.com", "v": 1 },
	"14ZHHxxpDpKAqH646A68RTmjo5Ez6na19E": { "n": "Secondstrade BTCUSD 5min Up", "l": "http://secondstrade.com", "v": 1 },
	"18i1SRBUPbwfze7AQpHGcJ8abwCUd3dwkf": { "n": "Secondstrade 5seconds+4 UP", "l": "http://secondstrade.com", "v": 1 },
	"1BZrye25RXxQ1EUEvZ2unZnXr94wSYqq9A": { "n": "Secondstrade 5seconds+2 DOWN", "l": "http://secondstrade.com", "v": 1 },
	"1HTjJ7Ri6LNvbu8GEAeArkFcmTWrb8zqVA": { "n": "Secondstrade 5seconds DOWN", "l": "http://secondstrade.com", "v": 1 },
	"19P5Xur6HrDboK2QFYTzz7mk9fCaz89x17": { "n": "Secondstrade 5seconds UP", "l": "http://secondstrade.com", "v": 1 },
	"1LLPKMX7TkEEqYHjGMnGbP3hhhkQEoDVRg": { "n": "sighmess", "l": "http://pkuphy.science/", "v": 0 },
	"1PoVHFFCkCwZ8RDnbG5UYgbwVKz2ZsFhDJ": { "n": "The Pirate Bay", "l": "https://thepiratebay.se/", "v": 1 },
	"1JTF1QpJ6yNhtF6fRUEM14x6AxBL8F9TyE": { "n": "secondstrade.com BTCUSD DOWN", "l": "http://secondstrade.com", "v": 1 },
	"18bsT6FEXbfgT18Ask3gV2BTEq6k8GeUdx": { "n": "secondstrade.com BTCUSD UP", "l": "http://secondstrade.com", "v": 1 },
	"1MHbp4zRLLasqUBSYfJgDAMTdMAdXZbwFq": { "n": "Tengu Windwaker", "l": "http://tenguwindwaker.tk", "v": 1 },
	"1P2HTAzmeeks4BbGEvsXywtGtCpadLMq1S": { "n": "SocialBitcoinPortfolio", "l": "http://socialbtcportfolio.com/", "v": 1 },
	"1GfB4YCqUivZxHxw7dU6woWhRfX4g1WiMq": { "n": "CECG Book Club", "l": "http://cecg.biz/projects", "v": 1 },
	"1LBgebZBPmFaWwn9NW4tMUv2Cw93X5ctf1": { "n": "luckybit 93.75pct", "l": "http://luckybit.net", "v": 1 },
	"1LBxBXirKuuR8ihLpAM64NFhVntLETXg4": { "n": "luckybit 87.5pct", "l": "http://luckybit.net", "v": 1 },
	"1LBrifuFgPcE91a2PcHuj4711Fo4H21tD5": { "n": "luckybit 75pct", "l": "http://luckybit.net", "v": 1 },
	"1LBduemopA8XDzNDxtW7qGrJDAm4A1LskB": { "n": "luckybit 62.5pct", "l": "http://luckybit.net", "v": 1 },
	"1LBifJz6xRqReTcBAAJYpKdA9siAr2zi9s": { "n": "luckybit 50pct", "l": "http://luckybit.net", "v": 1 },
	"1LBsbesYCfjvBcBimowrfJBGgQyjUA8rwr": { "n": "luckybit 37.5pct", "l": "http://luckybit.net", "v": 1 },
	"1LBduwe1CMq9Yu2QnwudnYrbXCW4toy9Zs": { "n": "luckybit 25pct", "l": "http://luckybit.net", "v": 1 },
	"1LBdcTgSatT2dYS7uvYRG1TNwJYt8ZmcLM": { "n": "luckybit 12.5pct", "l": "http://luckybit.net", "v": 1 },
	"1LBg1Ncpg6gYkg4ceSfkSHdPbgcT7zc2Zu": { "n": "luckybit 6.25pct", "l": "http://luckybit.net", "v": 1 },
	"1CCwA3A5ueMCRQXoxbZnC4acoFNsq7dShs": { "n": "luckybit 1.56pct", "l": "http://luckybit.net", "v": 1 },
	"1AAuoeMTXbeQ4f25VGU7Hst4X7S2rcKVqb": { "n": "luckybit 0.1pct", "l": "http://luckybit.net", "v": 1 },
	"196WJjYgReAHi2cyYJ6xa4EeskehXegHf2": { "n": "cryptonews", "l": "http://www.cryptonews.biz", "v": 0 },
	"1MsaF1ZKE6NusPtHjkB9ivvVmmWz3gm8oK": { "n": "AdanPlays", "l": "http://www.adan-khajiit.tumblr.com", "v": 0 },
	"1MwR1BRwshBxUWsAUVuAYREH3E7pZQmexP": { "n": "Electrum Server Status Monitor", "l": "http://electrum.qc.to", "v": 0 },
	"1N98rwJjwh9uyRdraYMkdgTYrSn83Hp82R": { "n": "dnstats", "l": "https://dnstats.net", "v": 1 },
	"31jK7nvyA8mhceF59wfUhWTWMcC9j3Js9m": { "n": "Bitmia Booster Fund", "l": "https://bitmia.com", "v": 1 },
	"1GMXQwbk1CMqa3rYcReyK4okZ8iCDJcue8": { "n": "Liberate RVA", "l": "http://www.liberaterva.com/invest/", "v": 1 },
	"12gqitVyAhqdpro5FnG2QysFyyMR63VsQH": { "n": "DanceFaucet", "l": "http://dancefaucet.com/", "v": 1 },
	"1bonesha4GAQav4UuTTf6TJ78FB7XpNmr": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesYU9XfBSsF2NcPaEHpnbjwuTtzni": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesKj4b8UUGibo68KhugX4wrtMjr7i": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesQaDUX24a84AqbhJ74SHMubcLXCQ": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesKagg4CQUw4vtfmgLANqmFNbSdj1": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesEJ5sUb4SF3BSo7yVaSoKfb7PWYp": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesExeTwfmmGEdMWtYX81k4DsfboZm": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonestT4xfUdy1PEa2eEEWDhX4niGYvw": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones6QEZDg9fgoVZfjc7SDJLiNAekcC": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones9LSJH3UspPfq5jLmj4g5RPJt2yq": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesYjQ7cr3PLSJqEpbFod24UC55XZx": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1change8ttQ36HKsV9FH8DF7smVYGFYfp": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1Pf1jjVJxvsskT9kxeHN7e9AJMyquUtXeZ": { "n": "Decentral Host Bit Bomb", "l": "https://www.decentralhost.in/modules/portal/donate.php", "v": 0 },
	"1NekitoHwp3vRkPHHWvG9qHDSx57m3BStM": { "n": "NekitoBlack", "l": "https://nekitoblack.net", "v": 0 },
	"3C1aRBtzFrevtt3fEqoEm1cX2nmPsVUp5L": { "n": "Bitmia Jackpot", "l": "https://bitmia.com", "v": 1 },
	"1BrTt8NVHWDMaMkYT1apskj378TWXvv996": { "n": "aBitPonzi", "l": "http://www.abitponzi.com", "v": 0 },
	"1Hi44CryQxpjFqLWioMiiEw6w1Vz9AYqCe": { "n": "Libertarians Against Humanity", "l": "http://libertariansagainsthumanity.com/", "v": 0 },
	"3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy": { "n": "Example address", "l": "https://en.bitcoin.it/wiki/Address", "v": 0 },
	"31oSGBBNrpCiENH3XMZpiP6GTC4tad4bMy": { "n": "Darkwallet", "l": "https://www.darkwallet.is", "v": 0 },
	"34CRZpt8j81rgh9QhzuBepqPi4cBQSjhjr": { "n": "Dyne.org", "l": "https://sx.dyne.org/multisig.html", "v": 1 },
	"1KennyhB45TVghLNPDmbPsgABbLC5qsQiz": { "n": "Kenny Rowe", "l": "http://kennyrowe.org/", "v": 0 },
	"1Sato11LCGGxTtY3ifVK8RQbjinz4E6rt": { "n": "SatoDice Wallet", "l": "http://satodice.com/", "v": 1 },
	"1B4E8xGjsgBeTVWgRAs9gRZ5oxiNGUH4i3": { "n": "Carbon7", "l": "https://carbon7.cc/", "v": 1 },
	"1LUokuA6PhHQvKveuJ5GDkQmAQvs98zX13": { "n": "donation,campaign,funding", "l": "http://aworldapart.us", "v": 1 },
	"1LBrpQvKkvjLudGVCYjLcL8W7FM4yNq5zm": { "n": "luckybit_0.606pct", "l": "http://luckybit.net/", "v": 1 },
	"1LBuqT6geozrH2fGKhrw4uGm4NGyRdE4py": { "n": "luckybit_3.03pct", "l": "http://luckybit.net/", "v": 1 },
	"1LBwsVUYAHyQS4QMwJ1XjbP3JDz37tzBqF": { "n": "luckybit_6.06pct", "l": "http://luckybit.net/", "v": 1 },
	"1LBtssy4uN7sqcBrDGrgPnk7sKN182R3xn": { "n": "luckybit_12.12pct", "l": "http://luckybit.net/", "v": 1 },
	"1LBmhrGRNgxzgY1442iNQSPgpY3oFhb1UW": { "n": "luckybit_24.25pct", "l": "http://luckybit.net/", "v": 1 },
	"1LBxsm4ACaVyYCEZkwnhazs3THVW3o24YG": { "n": "luckybit_32.33pct", "l": "http://luckybit.net/", "v": 1 },
	"1LBnfL9D7UZvuM9fWuBBoFKQH9coRxDJew": { "n": "luckybit_44.09pct", "l": "http://luckybit.net/satoshi.jsp", "v": 1 },
	"1LBxmk2PxFWAE2CmAcW17Y4ZW91QvP7AW5": { "n": "luckybit_53.89pct", "l": "http://luckybit.net/satoshi.jsp", "v": 1 },
	"1LBrdqDdUeVMrTMGmtmoDxeq8vSkYymJXk": { "n": "luckybit_74.6pct", "l": "http://luckybit.net/satoshi.jsp", "v": 1 },
	"1LBxmKt5W8cguDbdfQEpgaQsfmSsvXrXUc": { "n": "luckybit_88.18pct", "l": "http://luckybit.net/satoshi.jsp", "v": 1 },
	"1LBaenNyPeGCtDrseo9C6JTamMtSHoFybS": { "n": "luckybit_92.38pct", "l": "http://luckybit.net/satoshi.jsp", "v": 1 },
	"1BestZsie6f8cVSTmL9Pqt5Cc3HbDVYrBW": { "n": "BestPonzi", "l": "http://bestponzi.org", "v": 0 },
	"14snGAn4Q6CBtdq2mY1nwJHzGm9pDkAZxT": { "n": "bitcoinx.io", "l": "http://bitcoinx.io/about/", "v": 1 },
	"19vcdWcV4J8bhH7j3igHZ5q4WGT2UX5V2S": { "n": "Extortion", "l": "https://www.cryptocoinsnews.com/extortion-plot-connecticut-murder-bitcoin/", "v": 0 },
	"1KCkSVai3w9ocSSQATg6Pq1nP7XHckodLz": { "n": "Bitcoin2048.com", "l": "http://bitcoin2048.com/", "v": 1 },
	"38DPYmsa7RXwLrhpTP6udrfSiGn5dzdGAC": { "n": "Moon Bitcoin", "l": "http://moonbit.co.in", "v": 1 },
	"3L6ucV5cpXmGgnoik5P7wwczvES9ezuLsL": { "n": "Bitcoin Zebra", "l": "http://bitcoinzebra.com", "v": 1 },
	"1ChainB6x7xqRv9d6ioeGxKmdwN8niLSff": { "n": "Chainroll 1000x", "l": "http://chainroll.com", "v": 1 },
	"1ChainZpw9q7GnqGFuJaB8VSBSGfZRpKdk": { "n": "Chainroll 900x", "l": "http://chainroll.com", "v": 1 },
	"1ChainQ2UARA2TvTvscvKmS7syufaiRCo8": { "n": "Chainroll 800x", "l": "http://chainroll.com", "v": 1 },
	"1Chain5f7xjTZScvYzwpyRNgsfxoPLrNnT": { "n": "Chainroll 700x", "l": "http://chainroll.com", "v": 1 },
	"1ChainsieUYCd5cPTmkrZdCbBg9KNqkNBX": { "n": "Chainroll 600x", "l": "http://chainroll.com", "v": 1 },
	"1ChaintEyH9KmRRtZzWqvPbGUzDt574CuX": { "n": "Chainroll 500x", "l": "http://chainroll.com", "v": 1 },
	"1ChainbsVHN6bgDAZbj2SyF4rMNc95v2Ep": { "n": "Chainroll 400x", "l": "http://chainroll.com", "v": 1 },
	"1ChainLTT1jciqQES5xS17yHKtmqVy4fja": { "n": "Chainroll 300x", "l": "http://chainroll.com", "v": 1 },
	"1Chain55V3Pr4g2E9dRKEpBRN2F3DzyEtN": { "n": "Chainroll 200x", "l": "http://chainroll.com", "v": 1 },
	"1ChaingY2Sm51qAY2FjuJ5Zkvwuauq4Jno": { "n": "Chainroll 100x", "l": "http://chainroll.com", "v": 1 },
	"1ChainQgeSsyDPWkh2dCxYr5Zb4xu2mZDQ": { "n": "Chainroll 99x", "l": "http://chainroll.com", "v": 1 },
	"1Chaine3rwgmnXKtmbcrogHwpcndJS8Wzz": { "n": "Chainroll 98x", "l": "http://chainroll.com", "v": 1 },
	"1ChainpchB1RUuDjYVjsYug23Ce6jwgbRq": { "n": "Chainroll 97x", "l": "http://chainroll.com", "v": 1 },
	"1Chain3oWkV2qyvo6AncfZfWjdrWYAgKg5": { "n": "Chainroll 96x", "l": "http://chainroll.com", "v": 1 },
	"1Chain625jv1JFXUzbjfpw6cJZaaCB1gEA": { "n": "Chainroll 95x", "l": "http://chainroll.com", "v": 1 },
	"1Chain9Jf2PNEtFa7rUMdrDgn3LuWYS7Ug": { "n": "Chainroll 94x", "l": "http://chainroll.com", "v": 1 },
	"1Chainw2jemxxDxDXozjUBbJ2RqTayBnHb": { "n": "Chainroll 93x", "l": "http://chainroll.com", "v": 1 },
	"1ChainG7wM5o86NgXCgk2U7kF6BCVDMJha": { "n": "Chainroll 92x", "l": "http://chainroll.com", "v": 1 },
	"1ChainTyD9JNYfNeqH3y7XA7bv9Me6jkjk": { "n": "Chainroll 91x", "l": "http://chainroll.com", "v": 1 },
	"1Chain7sD7cZhyLsd4ycfA19dFGr6hBgYq": { "n": "Chainroll 90x", "l": "http://chainroll.com", "v": 1 },
	"1Chain26rLUDUh92urvTG2WqpzkGuCBQX4": { "n": "Chainroll 89x", "l": "http://chainroll.com", "v": 1 },
	"1Chain27DGUMs6PHctN9oeCh5KP8ExfHEu": { "n": "Chainroll 88x", "l": "http://chainroll.com", "v": 1 },
	"1ChainXEFLw5nfj2FRxEeLLjYrFXBWEwSy": { "n": "Chainroll 87x", "l": "http://chainroll.com", "v": 1 },
	"1ChainEwDQkjKuXZw4XUXNZiopLid2GjfM": { "n": "Chainroll 86x", "l": "http://chainroll.com", "v": 1 },
	"1Chain3eU9h68dBB5sxDjzrzomRkqJf8Ts": { "n": "Chainroll 85x", "l": "http://chainroll.com", "v": 1 },
	"1ChainkALHgquzxuDaKbyk4Jn8q2oCrcB1": { "n": "Chainroll 84x", "l": "http://chainroll.com", "v": 1 },
	"1ChainhAACnzDpvdRzM4rXJsoMocwxFonr": { "n": "Chainroll 83x", "l": "http://chainroll.com", "v": 1 },
	"1Chainq2zAfg5ugvvZyumdUek1YtvXUW4z": { "n": "Chainroll 82x", "l": "http://chainroll.com", "v": 1 },
	"1ChainTRtFbiSeUdUZvtHX9fy6TZU7oV6f": { "n": "Chainroll 81x", "l": "http://chainroll.com", "v": 1 },
	"1Chain2dsPxCTZ8cRoCT96Yqzb7FcEpdC3": { "n": "Chainroll 80x", "l": "http://chainroll.com", "v": 1 },
	"1Chainns2tBfWCy6XJRwPgxhhM4NcLREvo": { "n": "Chainroll 79x", "l": "http://chainroll.com", "v": 1 },
	"1Chain4j5bAk758TapYkYtdPe3qxbwmmdU": { "n": "Chainroll 78x", "l": "http://chainroll.com", "v": 1 },
	"1Chain1av4azXpEqgN3SbA1k8doZnRHjT": { "n": "Chainroll 77x", "l": "http://chainroll.com", "v": 1 },
	"1ChainvVMd7Bs3Xhgex4qjoFXJqEALRXSE": { "n": "Chainroll 76x", "l": "http://chainroll.com", "v": 1 },
	"1Chainhu4g4DV9bPhjwWtZr1YE5ePW6NVn": { "n": "Chainroll 75x", "l": "http://chainroll.com", "v": 1 },
	"1ChainFJtGmoY8ed9WxDsxEwp9pyE9EnR": { "n": "Chainroll 74x", "l": "http://chainroll.com", "v": 1 },
	"1ChainBMwa1essVQEwzo5jDV1aeoGxwWPS": { "n": "Chainroll 73x", "l": "http://chainroll.com", "v": 1 },
	"1Chain5ST7aVdjx6dDyzo7gmEJ16y6xvFN": { "n": "Chainroll 72x", "l": "http://chainroll.com", "v": 1 },
	"1Chain7FjKjQb1uYLRK1Zo5uoA63hotMsM": { "n": "Chainroll 71x", "l": "http://chainroll.com", "v": 1 },
	"1Chain6VDEs8S7xF2rk4MiiJcBjvgiYjwc": { "n": "Chainroll 70x", "l": "http://chainroll.com", "v": 1 },
	"1ChaineK4hsiafj1moF92ZowCV8WnUJVST": { "n": "Chainroll 69x", "l": "http://chainroll.com", "v": 1 },
	"1ChainYUdCpdzsmzRUj7ejugeTpvi8aKar": { "n": "Chainroll 68x", "l": "http://chainroll.com", "v": 1 },
	"1ChainwiPFNZ1eF5b44hqJw363ovZZcNzt": { "n": "Chainroll 67x", "l": "http://chainroll.com", "v": 1 },
	"1ChainkeWgeKa9UTbueFgpgiWYSx6zxiCY": { "n": "Chainroll 66x", "l": "http://chainroll.com", "v": 1 },
	"1ChainjUUHidM75vTN6GUL2E35F5Ci6PD5": { "n": "Chainroll 65x", "l": "http://chainroll.com", "v": 1 },
	"1ChainZiouvkNAPYWfx2KnjnPyUGNcgPBS": { "n": "Chainroll 64x", "l": "http://chainroll.com", "v": 1 },
	"1ChainFoUg4L8LTbRGU2jwPDhokKspdDFf": { "n": "Chainroll 63x", "l": "http://chainroll.com", "v": 1 },
	"1Chain6veB7ZADakTPeyUguPPoLzR7V9p8": { "n": "Chainroll 62x", "l": "http://chainroll.com", "v": 1 },
	"1ChainPu9oZbX82iTomNo2qQTNdk98GCde": { "n": "Chainroll 61x", "l": "http://chainroll.com", "v": 1 },
	"1ChainCnFjtAvaraYXBh5ce318c4h7e37N": { "n": "Chainroll 60x", "l": "http://chainroll.com", "v": 1 },
	"1ChainpWZakEoj25qXRkBKm4SGXkueYqhT": { "n": "Chainroll 59x", "l": "http://chainroll.com", "v": 1 },
	"1Chain3JDx944RuJVrs3HhVFVP69KTLkv": { "n": "Chainroll 58x", "l": "http://chainroll.com", "v": 1 },
	"1Chainy2XPRK5sC8KXqt1mDgHXwTmydHy6": { "n": "Chainroll 57x", "l": "http://chainroll.com", "v": 1 },
	"1ChainTbkVMXGP2Z3nz2QUkjdt1UmHNE2g": { "n": "Chainroll 56x", "l": "http://chainroll.com", "v": 1 },
	"1ChainnpsfZCFawNvjxuUJe4Kmg9my9K8C": { "n": "Chainroll 55x", "l": "http://chainroll.com", "v": 1 },
	"1ChainuFHyF5VZjS6cy1aEr6LUXp9pX3Nv": { "n": "Chainroll 54x", "l": "http://chainroll.com", "v": 1 },
	"1ChainX3UM5JEo2jrT62qe1Z8KRs1qtMfq": { "n": "Chainroll 53x", "l": "http://chainroll.com", "v": 1 },
	"1Chainzw8VFvxAFVomSM3KxsFwXLMC6S1T": { "n": "Chainroll 52x", "l": "http://chainroll.com", "v": 1 },
	"1ChainMuJ114egH2qAgnJTxjz97u4fvwW1": { "n": "Chainroll 51x", "l": "http://chainroll.com", "v": 1 },
	"1Chainv2bUMTZMADmeeQtdNwYH1TAD3B8R": { "n": "Chainroll 50x", "l": "http://chainroll.com", "v": 1 },
	"1ChainvXjMFeo5VV4sitdUpqQc6cfgnxM2": { "n": "Chainroll 49x", "l": "http://chainroll.com", "v": 1 },
	"1ChainvPRHHoYv18kkD3gp8wV3cMY7GKvc": { "n": "Chainroll 48x", "l": "http://chainroll.com", "v": 1 },
	"1Chainefm78fkeQohdz123Ab1LeZbCrJ4r": { "n": "Chainroll 47x", "l": "http://chainroll.com", "v": 1 },
	"1ChainPx942ZJKGJ97aufCb5QrBc2rhAGx": { "n": "Chainroll 46x", "l": "http://chainroll.com", "v": 1 },
	"1ChainDR13Vp3Ny7u729qAFgjFh2s3YHzJ": { "n": "Chainroll 45x", "l": "http://chainroll.com", "v": 1 },
	"1ChainSkkyhg3CTq3FhpYGienqwCKkjNaB": { "n": "Chainroll 44x", "l": "http://chainroll.com", "v": 1 },
	"1ChainkTQF3XByiExi4a8YhDyG7q2t37k8": { "n": "Chainroll 43x", "l": "http://chainroll.com", "v": 1 },
	"1ChainN1SGSsWSpkEfBDCVaFPmTfGtB52j": { "n": "Chainroll 42x", "l": "http://chainroll.com", "v": 1 },
	"1ChainTqH9VJtVMjwEoqQBDe49cjCMiWzH": { "n": "Chainroll 41x", "l": "http://chainroll.com", "v": 1 },
	"1ChainrdDexxujbWGd6RbhmpHEexCdGWGw": { "n": "Chainroll 40x", "l": "http://chainroll.com", "v": 1 },
	"1ChainjEs3PXQUgsXhWoECUNPZYpcD7cLR": { "n": "Chainroll 39x", "l": "http://chainroll.com", "v": 1 },
	"1ChaindSbTmY7DxL4pBd1W79rE1ot8XPwe": { "n": "Chainroll 38x", "l": "http://chainroll.com", "v": 1 },
	"1ChainrTsaSDBBL8yrz2pYYta2w7RxtqHx": { "n": "Chainroll 37x", "l": "http://chainroll.com", "v": 1 },
	"1ChainBSyd2BgqYNWgXcAL7A48X42QzWfa": { "n": "Chainroll 36x", "l": "http://chainroll.com", "v": 1 },
	"1ChainivYzuzZVMPUZtpVkGKajSJd6HJxQ": { "n": "Chainroll 35x", "l": "http://chainroll.com", "v": 1 },
	"1ChaindN9mYc2mMYyADkLLZmLaEe1At1vd": { "n": "Chainroll 34x", "l": "http://chainroll.com", "v": 1 },
	"1ChainHws6TsMyTUvQzDo33hGFFU9rLJPV": { "n": "Chainroll 33x", "l": "http://chainroll.com", "v": 1 },
	"1Chaink3K9cT2k79KjQPNgLxTqptuD2MPP": { "n": "Chainroll 32x", "l": "http://chainroll.com", "v": 1 },
	"1Chain7HhpeTKfHiozmcwxKxnQqbKJTLMs": { "n": "Chainroll 31x", "l": "http://chainroll.com", "v": 1 },
	"1ChainAvQ7Ew5kyatsEU1bpky8Znae7Ehc": { "n": "Chainroll 30x", "l": "http://chainroll.com", "v": 1 },
	"1ChaingCqrqtTDQ52hDzjF6fsFughqi38s": { "n": "Chainroll 29x", "l": "http://chainroll.com", "v": 1 },
	"1ChainGXxHjMtf8jWaRpsJq1oxwYmSWYA5": { "n": "Chainroll 28x", "l": "http://chainroll.com", "v": 1 },
	"1Chaink3mvazeTMs5UbgphNgYoa1sM8WWi": { "n": "Chainroll 27x", "l": "http://chainroll.com", "v": 1 },
	"1ChainFazjsLzum3UwieyuCexXH99u5ZWh": { "n": "Chainroll 26x", "l": "http://chainroll.com", "v": 1 },
	"1ChainWTXyoHfbiY4S7f7txcnq1wqyZwJD": { "n": "Chainroll 25x", "l": "http://chainroll.com", "v": 1 },
	"1ChainjEJUH7E2EerWwLrrQCYdmabdt3aT": { "n": "Chainroll 24x", "l": "http://chainroll.com", "v": 1 },
	"1Chain4hRZY7HE1zZ8vhjQsS6oZFgToQwD": { "n": "Chainroll 23x", "l": "http://chainroll.com", "v": 1 },
	"1Chainm7ZP9H6uKfDp19ZiYFj3FZctEP2p": { "n": "Chainroll 22x", "l": "http://chainroll.com", "v": 1 },
	"1ChainU5TbVZuSR3igdF1ndZeDfxW6pJbu": { "n": "Chainroll 21x", "l": "http://chainroll.com", "v": 1 },
	"1ChainJXJEEkVDPYscSSayPHnx8wZnX56f": { "n": "Chainroll 20x", "l": "http://chainroll.com", "v": 1 },
	"1ChainsWjJpYvBbgafqgFNGAQAQZ1ciBgu": { "n": "Chainroll 19x", "l": "http://chainroll.com", "v": 1 },
	"1ChainfsQJTUZ5fcWhW5uR9vrfMS1KppBf": { "n": "Chainroll 18x", "l": "http://chainroll.com", "v": 1 },
	"1Chaink9rsKtUZpzKBfqSFERJ5K9TA2hR5": { "n": "Chainroll 17x", "l": "http://chainroll.com", "v": 1 },
	"1ChainJ8U9AKKQvdkgMXdBS1tLeeXpot73": { "n": "Chainroll 16x", "l": "http://chainroll.com", "v": 1 },
	"1ChainvhxLwKNFWUbErShvNNQNyTgzgh1": { "n": "Chainroll 15x", "l": "http://chainroll.com", "v": 1 },
	"1ChainswEZJ9FxXCFzTcEDHX9kh5SfLhXi": { "n": "Chainroll 14x", "l": "http://chainroll.com", "v": 1 },
	"1ChainEvAH6tYh9cSZCjLFoETgr711oSsr": { "n": "Chainroll 13x", "l": "http://chainroll.com", "v": 1 },
	"1ChainBSF9oFPQka3Gja1twd7x2b5UEHf5": { "n": "Chainroll 12x", "l": "http://chainroll.com", "v": 1 },
	"1ChainMFhenNfMDmD4pjMTth4CeNPji3bQ": { "n": "Chainroll 11x", "l": "http://chainroll.com", "v": 1 },
	"1ChainHvZhNeySdFhB2YrAkdTR4gWc48vW": { "n": "Chainroll 10x", "l": "http://chainroll.com", "v": 1 },
	"1ChainCS5KT7z3BAF9Co4vWx5ND4q5tH8z": { "n": "Chainroll 9x", "l": "http://chainroll.com", "v": 1 },
	"1ChaingiWJVmrr4eUFfpRUeZBCyqun7rUb": { "n": "Chainroll 8x", "l": "http://chainroll.com", "v": 1 },
	"1ChainLhpoC1zchFWRSiwGubQm96ZTCQCz": { "n": "Chainroll 7x", "l": "http://chainroll.com", "v": 1 },
	"1ChaintNbUSSyVg6asL6jbdrDj9m741UdX": { "n": "Chainroll 6x", "l": "http://chainroll.com", "v": 1 },
	"113BtSE2eaGxEYt2sR4maME3CEeBXZzjA1": { "n": "Chainroll 5x", "l": "http://chainroll.com", "v": 1 },
	"1ChainzrRiuSLgUMdHquRR59pUJx9sMXj1": { "n": "Chainroll 4x", "l": "http://chainroll.com", "v": 1 },
	"1ChainbLzmtppFxeLDdwqC6UedT2TgA34w": { "n": "Chainroll 3x", "l": "http://chainroll.com", "v": 1 },
	"1ChainLPWeoaXpH4XDnKFZVwpmL4pZ5Rmx": { "n": "Chainroll 2x", "l": "http://chainroll.com", "v": 1 },
	"1ChainSYjnLEHMaY1StetcsF2u6wxB63yE": { "n": "Chainroll 1.9x", "l": "http://chainroll.com", "v": 1 },
	"1Chainwtsq5s9K63nnLz1uBNViM7fCB6kg": { "n": "Chainroll 1.8x", "l": "http://chainroll.com", "v": 1 },
	"1ChainjbBGHBwKaaJW2PkDfcisj9JU3g32": { "n": "Chainroll 1.7x", "l": "http://chainroll.com", "v": 1 },
	"1ChainxwZyfvLXirpmT3ARhpq3KvQiBFXS": { "n": "Chainroll 1.6x", "l": "http://chainroll.com", "v": 1 },
	"1ChainbjLfwtaVFFXcT4NjRBRMXSyHa2Jx": { "n": "Chainroll 1.5x", "l": "http://chainroll.com", "v": 1 },
	"1ChainmtK1YqCDhdgsZXKL4coECeBnefDc": { "n": "Chainroll 1.4x", "l": "http://chainroll.com", "v": 1 },
	"1Chain57XuYT2EqkCtayYiVsQs6doJ6ytz": { "n": "Chainroll 1.3x", "l": "http://chainroll.com", "v": 1 },
	"1ChainS6vgu5Tpzwmdvhthm4eqWTQaMt1h": { "n": "Chainroll 1.2x", "l": "http://chainroll.com", "v": 1 },
	"1Chain1ru5EGG22sNh6t2JmhgvUL2Z8jZH": { "n": "Chainroll 1.1x", "l": "http://chainroll.com", "v": 1 },
	"1GxVo5dsvHhdYKxNmyAgi8ekEoM9fYeEve": { "n": "Donations to KisakiJRO", "l": "https://kisakijro.wordpress.com/donations/", "v": 1 },
	"1KifpBCL6pKRjSVhkUj1cPrB3tMiBdhaKV": { "n": "Bitcoin USD", "l": "http://bitcoinusd.info/", "v": 1 },
	"1AwgqD7A2KuQ4WT4273JXZPUf29BAbdp2": { "n": "iCreateOFX", "l": "http://icreateofx.co.uk/", "v": 1 },
	"1A4NfSJDzxzKgRrgfjxSAQ8hCPJJWKcmzX": { "n": "my ass", "l": "http://bitcoin.stackexchange.com/questions/34300/how-to-get-the-list-of-transactions-that-has-gone-into-an-address-with-the-amoun", "v": 0 },
	"1FhCLQK2ZXtCUQDtG98p6fVH7S6mxAsEey": { "n": "XKCD Donation Address", "l": "http://xkcd.com/", "v": 0 },
	"1FRE3H4TWnN16FmvqCiMQ1TJ6SaxG1WQRa": { "n": "HOPE Gold Coin", "l": "https://hopegoldcoin.wordpress.com/", "v": 1 },
	"322ZmM89ZAsWhCUmHJapaQajXrqz79C5kw": { "n": "BitcoinXD.com", "l": "http://bitcoinxd.com", "v": 1 },
	"1NGnCrXfazu9SgxCPw7uhUHiJafEj52yDy": { "n": "18th_wallet_salman", "l": "http://avanpay.net/wallet/", "v": 1 },
	"1AZYKstEvRLhYnQCheYutqyZ5oNS4SwoJw": { "n": "monatr.jp", "l": "https://monatr.jp", "v": 0 },
	"1bonescooSdRacj4wiLScKuGAAo1rmNLZ": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones4B2M3k9wZWZhRxG3GayqFJrrXKm": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesgHKW6L3jmcQEr6iQQeDpJWitbF1": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesxGg5HdBZXansCwPCsCySQKk9pHR": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesNzPDcqyti3hpGV3S76mmxnQaedL": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesDKx6CqFsM1Q1PaQZM546JVfP6t3": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneseih5uaD4uYQMMGYFpptYNjzWbaK": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones7fs2RFKFdvaeaftfusvWaZZcnZ4": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesTiNYhnPb4zX6hK8DSJ7h8a65xu7": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones39FdhLGSKJ1kGVqGPMPr7MGnz1a": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesnWqFxU9ssQWcQEuPyuF1fYMNF1v": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1changeFu9bT4Bzbo8qQTcHS7pRfLcX1D": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1D6KWcrDdPGknh6CLczLVPvd9Y8skxPnUu": { "n": "raoulbtc Eobot", "l": "https://www.eobot.com/user/11103", "v": 1 },
	"1BTyRFatTrSjFk8nE1cxcWeppf73k4SVTL": { "n": "royalmacro", "l": "http://royalmacro.com", "v": 1 },
	"18VWNziobACaiwy88EicifYK5AgFckneU5": { "n": "crypto-hunting", "l": "http://crypto-hunting.blogspot.in", "v": 1 },
	"1KKP797jJ2rYxg5UxK841mdx5BDTJsUCYC": { "n": "luckybit_0.1pct", "l": "http://luckybit.net/", "v": 1 },
	"1LL2cKcCmcj4MKGCFZfwx6zB4ZRD2RXtZS": { "n": "luckybit_1.56pct", "l": "http://luckybit.net/", "v": 1 },
	"19PkMypvCNHG4HvbM3eWV4rpNy4VsfgyS6": { "n": "luckybit_6.25pct", "l": "http://luckybit.net/", "v": 1 },
	"18Gg3Uy5zv5sFNPX3SuoDVL4gcv1rD1dcS": { "n": "luckybit_12.5pct", "l": "http://luckybit.net/", "v": 1 },
	"17gjBCsbot6qPWHSegomjgntwCJvUrbynw": { "n": "luckybit_25pct", "l": "http://luckybit.net/", "v": 1 },
	"16TMPFjnNXCPTMRhbzHeEAgPC1AyxfCAB9": { "n": "luckybit_37.5pct", "l": "http://luckybit.net/", "v": 1 },
	"15wd28DpYJW2HLuJhZY5tnDVeDMxp6NVy4": { "n": "luckybit_50pct", "l": "http://luckybit.net/", "v": 1 },
	"14LFhThp6drV926cNF7PxmzNnfLDBxxx4Z": { "n": "luckybit_62.5pct", "l": "http://luckybit.net/", "v": 1 },
	"13rmjcgVnSQCQzhnq1E5Q1qHEjsw8oyUhx": { "n": "luckybit_75pct", "l": "http://luckybit.net/", "v": 1 },
	"1DDvAMNkiJkzezxT9S6nn6HMBNWffbJzaf": { "n": "bigponzi", "l": "http://disposablewebpage.com/turn/f16WsC3RHV", "v": 0 },
	"16FEx2PYFwo9i38vyXktwYEfPiyQN6JpMW": { "n": "Bitstamp Hack Mixer 5", "l": "http://litmocracy.com/docs/hackertracker.htm", "v": 0 },
	"1K4wcA9fB9e3f68kuWFLm4uPq1VqBYxTpg": { "n": "Bitstamp Hack Mixer 4", "l": "http://litmocracy.com/docs/hackertracker.htm", "v": 0 },
	"1Fze2Qx6Covm7jnC4ffCD9Lsst2sD7CaqE": { "n": "Bitstamp Hack Mixer 3", "l": "http://litmocracy.com/docs/hackertracker.htm", "v": 0 },
	"1EtH88P5feywPJE1nyrjggd41JeCuEeKNi": { "n": "Bitstamp Hack Mixer 2", "l": "http://litmocracy.com/docs/hackertracker.htm", "v": 0 },
	"1PhbKjG9gYeYVXfvi4AjW9pJ1s9MrqMuH4": { "n": "Bitstamp Hack Mixer 1", "l": "http://litmocracy.com/docs/hackertracker.htm", "v": 0 },
	"1CLsUNU7BBJYeZG83vgsQjFP91pkCtX7s6": { "n": "List of Bitcoin faucets", "l": "http://100bitcoin.com/bitcoin-faucets-list.html", "v": 1 },
	"1HTN24Y1Ug3GZexgUkVkcQEguprViBToVc": { "n": "Bitcoin Faucet 100bitcoin.com", "l": "http://100bitcoin.com/", "v": 1 },
	"1Jy6mXq3Vn3qxj7y4J6KP1ydzUKKEBAPpt": { "n": "100btc.ru", "l": "http://100btc.ru/", "v": 1 },
	"1PNabKGjkXMNqsAmZgg9nDf9izoMwBM6mh": { "n": "BlockchainUniversity", "l": "https://onename.io/blockchainuniversity.json", "v": 1 },
	"1E8YWo1v5EMWC4VF8G1KRgTjHjxEh2qyTM": { "n": "btcaddr.es sharethelove", "l": "https://bit.co.in/btcaddr.es_sharethelove", "v": 1 },
	"19Ymm66k1KTasGgBwSK2WQKLkeCQfjCmRg": { "n": "btcaddr.es sharethelove", "l": "https://bit.co.in/sharesomebtc", "v": 1 },
	"18eSVrt2jb1qXGArdYxu1UWFqM1eydmJph": { "n": "btcaddr.es sharethelove", "l": "https://bit.co.in/sharethelove", "v": 1 },
	"1KbG7ajM66v5JhqFwdtWZgcmho3KCMNLJc": { "n": "Bitcoin2048.com", "l": "http://bitcoin2048.com/", "v": 0 },
	"17ZgzoQUAiCrCgSieYfGhAvToW9kn6uaLt": { "n": "Sarutobi Game", "l": "http://www.coindesk.com/apple-approves-ios-game-tips-players-bitcoin/", "v": 1 },
	"1C2YhfLw6mRf6iDrZyjtXrFwVNBSAbNYk1": { "n": "Ge0rges15", "l": "http://ge0rges.com/donate/", "v": 1 },
	"1KP72fBmh3XBRfuJDMn53APaqM6iMRspCh": { "n": "Cryptolocker virus", "l": "http://www.bleepingcomputer.com/virus-removal/cryptolocker-ransomware-information", "v": 1 },
	"18iEz617DoDp8CNQUyyrjCcC7XCGDf5SVb": { "n": "Cryptolocker virus", "l": "http://www.bleepingcomputer.com/virus-removal/cryptolocker-ransomware-information", "v": 1 },
	"1GFC4XWYd8SKBKGZdYq3LGi7YJVUivXUfr": { "n": "GetFree.co.in", "l": "http://getfree.co.in", "v": 1 },
	"1NS4uDiZciVWoogSJmovmsk34SYiP2kcAR": { "n": "Apps for Android", "l": "http://www.apptyze.com", "v": 1 },
	"12qUgXSban36UyNLbQ1Sv86Ua1PWg17PMj": { "n": "luckybit_87.5pct", "l": "http://luckybit.net/satoshi.jsp", "v": 1 },
	"17kJLrQssm9HhgwUyR3ycyXzmeUnahvuz5": { "n": "Remitano", "l": "http://blog.remitano.com/not-blood-sucking-remittance-zero-free-exchange/", "v": 1 },
	"1L2JsXHPMYuAa9ugvHGLwkdstCPUDemNCf": { "n": "Bitstamp Hack", "l": "http://www.coindesk.com/bitstamp-claims-roughly-19000-btc-lost-hot-wallet-hack/", "v": 1 },
	"114bGhvtC7EG6a8L4geVv6tBuRSiP93ojZ": { "n": "luckbit_93pct", "l": "http://luckybit.net/satoshi.jsp", "v": 1 },
	"1FQeibRwWNsWWi2aEWy9oVJoAUQwJcrnuj": { "n": "BitcoinOk.Net", "l": "http://bitcoinok.net/", "v": 1 },
	"1B112nosaWSsEtKrNBY8NrewtkroMJ57Nb": { "n": "Bitcoin-Stocks 112pc Plan", "l": "https://bitcoin-stocks.com/invest/112plan/details.php", "v": 1 },
	"1B14oYeycqGyFGXsY64qqmchmB9Txe71AU": { "n": "Bitcoin-Stocks 140pc Plan", "l": "https://bitcoin-stocks.com/invest/140plan/details.php", "v": 1 },
	"1Bmain7rrswU8tpJZ2qN6VqDbgaPve7vCf": { "n": "Bitcoin-Stocks Main Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1CQaRkskVWuWC8R57TdSY9t5bjBrQbca6c": { "n": "btc45.net", "l": "http://www.btc45.net", "v": 1 },
	"12Ud9kQhJUZub2bp1UAcvqJLcuZQUsH8Zk": { "n": "rmarkdev", "l": "http://portfolio.rmarkdev.de", "v": 1 },
	"12askygVMyFWd9KUw7uUKshebKVHC1o9FZ": { "n": "Advocates of Bitcoin Adoption", "l": "http://www.TheFutureWasYesterday.org", "v": 1 },
	"1B39oUuMRPWr7JVnFeddVHZ4PdrUYokjCh": { "n": "Invalid 2014 Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1B2ooBN1nznetFnb8ZoNfhhnzp445QfuzA": { "n": "Invalid 2014 Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1B18o36scLWne3dbYSsYbDGDvnvfcAmnd1": { "n": "Invalid 2014 Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1B14ohLZcLrFfMzFHL6uCMWFQqCm1aDVEn": { "n": "Invalid 2014 Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1B126hUbhZK6niYFcCpPZm3447kWGF4yFP": { "n": "Invalid 2014 Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1B1151EDLQAuz1qf8f7khRnwFjiTbfFiLa": { "n": "Invalid 2014 Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1B1o33pcTCLHnkMGyCDNzjcMx2oRRgDAeK": { "n": "Invalid 2014 Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1B112hK1AGP3aF7dnW8uVWDHTLU6AXjnbf": { "n": "Invalid 2014 Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1Bmain1SWHZtauy94J7dBGKGdLxTeLbzmY": { "n": "Invalid 2014 Address", "l": "https://bitcoin-stocks.com", "v": 1 },
	"1RepayLCGmGM4nGqMXhYb31qzTkjiaYoz": { "n": "Bitcoin-Stocks Repayments", "l": "https://bitcoin-stocks.com", "v": 1 },
	"14ePxXhYrNwrhzb3ANRHQvughMZ9WB9SMY": { "n": "Datafaucet.info", "l": "https://datafaucet.info", "v": 1 },
	"1bonesyL71GxRmGA815wkLBHvDZwirvzu": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesnwqJmAMA96F7vTY6FFtyDRr6UJX": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesyMVDpLkwgzbav39DKGgUD8bWgsB": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones3Rh2ud1tXtseYf2Fr4it2AnXEL1": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesU8XznVHnMCs5oDsPVRcQAqo1Hth": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesMybEn68gUcXDKDBXwBWKqzCtkCz": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesyw5998F8JuMtUeRfyR5j2en5MxN": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneshFBAKDFS4swPgNMiJJPvpCpi9AP": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesDS9i7bwoLMWKk7ejiCsvzpC1k9n": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesUzxUKPc5QW5isfJB54F4yQVjJeb": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesWxjCN3fm2Fjfj8Ttj2ZjoU3Hbw9": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1changeUYYhBe35JcG5LhKDBvzur6UykC": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1noncerQ2k6WtiLVA86SvQ6HzGvSB6PDD": { "n": "SATOSHI NONCE", "l": "http://www.satoshinonce.com", "v": 1 },
	"13bxBhF3dFe27xDbdrJa3Je27Djnfjqr2F": { "n": "Funky Faucet Donate", "l": "http://funkyfaucet.tk", "v": 0 },
	"1PLn3ru1n7wERPP1BLVV9oAEGGuXUP1eoC": { "n": "Contact Blockchain Support", "l": "https://blog.blockchain.com/2014/12/08/blockchain-info-security-disclosure", "v": 1 },
	"1F5MgFxWxqhEsdQJCUfkRzWWH9fCantrA8": { "n": "HWzone.co.il", "l": "http://hwzone.co.il/community/members/26810-mishax1", "v": 0 },
	"3HyULbPVM739jPVk4i3PKZ4LibhYP1HsLc": { "n": "BearFarts", "l": "http://www.neocogent.tk", "v": 0 },
	"38ccq12hPFoiSksxUdr6SQ5VosyjY7s9AU": { "n": "Seans Outpost", "l": "http://www.seansoutpost.com/", "v": 1 },
	"13hamVwVN3oEt1Azttvn3yw4awxzDDmf4V": { "n": "CEDC Donations", "l": "http://communityeducationdevelopmentcenter.org/donate.html", "v": 0 },
	"1AfkcswQmzroZnmCwK7Crd7mxiBTFV9GhT": { "n": "TDarkAngel", "l": "http://tdarkangel.com", "v": 0 },
	"1AsqB94XKAGTw1m1it1wdC2ucbkjPpT4oo": { "n": "MattHF", "l": "http://matthf.net", "v": 0 },
	"1DgM5PrDAAXUEVUtd7tXruAymht3z7cBvK": { "n": "Win 312 Bitcoins Now!", "l": "https://www.btcinvite.com", "v": 0 },
	"15oGxujts4g5XZy7HZrCq4u3zm9A3483uk": { "n": "Bitcoin Fortune", "l": "http://bitcoin-fortune.com/", "v": 0 },
	"1JDP9m9ECeA9YYzjVkVZkBLRgKvEpb3gxU": { "n": "BTC Slice Ltd..", "l": "http://www.btcslice.com", "v": 1 },
	"1KbDkLsPtbdrBCutcCUSjGzDK3Y9Bz8uju": { "n": "Bitcoin2048.com", "l": "http://bitcoin2048.com/", "v": 0 },
	"13vNLp1zggRhw7RDqetdiLAqaiTQxsQzie": { "n": "zvedavec.org", "l": "http://zvedavec.org/dary.php", "v": 0 },
	"1QFbx3bKA8LABAGEaSe7EiP9JCxe2j4fN7": { "n": "devuan_donations", "l": "https://devuan.org/donate.html", "v": 0 },
	"1taxinvBLwDAb1tjyTYzhcyb1fNKfivAB": { "n": "Vegas Taxi", "l": "http://scclv.tumblr.com/", "v": 0 },
	"1FTgzPJCbpCWYfF6VxPdmCMPUDBfygut2h": { "n": "BitNovosti Donation", "l": "http://bitnovosti.com/about/", "v": 0 },
	"1DffZcvcQue3gn15G9tTshu2Y9YkzEZE2f": { "n": "New Coins", "l": "http://tcoins.in", "v": 0 },
	"1HCFDzKx94uwtnvjJEXBZP12dseiNDK6if": { "n": "Bikini Dice", "l": "https://www.bikinidice.com", "v": 0 },
	"1DqCqiSWw7u5VGH16DQy5MNDDC9G7dVwLf": { "n": "ePay.info Payment System", "l": "http://epay.info/", "v": 1 },
	"171LRDqWayrLgSXf81LTrGUvcx4CTrvZdA": { "n": "bitcoin_news_donations", "l": "http://bitcoin.gw.gd/", "v": 0 },
	"1MjdEdmZbwVPS4tXEHjRRciEuRNGwogYuZ": { "n": "ramonsilverioferr_hotmail.com", "l": "http://memberdoorway.com/alternate/lbs/", "v": 0 },
	"115eBUr1XCAJCyN5Eq9ornJU3vr8V4nNtG": { "n": "Bitcoinstrader.eu", "l": "http://www.bitcoinstrader.eu", "v": 0 },
	"14mbtdeWom6ytkacPgo5yaPa3YoRwbcgWK": { "n": "Red Leaf Chicago", "l": "http://www.redleafchicago.com/", "v": 0 },
	"19vnYwAn4VfWxn6RNZok4mqRZjHKNT9vUW": { "n": "btc45.net", "l": "http://btc45.net/", "v": 0 },
	"1NXJSw9BxjG3DEPRUsWcxYpWx6xWdieKp6": { "n": "BTC Slice Ltd..", "l": "http://www.btcslice.com", "v": 1 },
	"1C4ERzSxnRmEbXQC1vZGPHs1GDJ21Xvv9F": { "n": "BTC SliceLtd..", "l": "http://www.btcslice.com", "v": 1 },
	"14xEPWuHC3ybPMfv8iTZZ29UCLTUSoJ8HL": { "n": "The Water Project", "l": "http://thewaterproject.org/donate-bitcoin", "v": 0 },
	"1EMBASSYyhoYZiv1cHFpPRM5fnSXk6C7Gp": { "n": "Bitcoin Embassy", "l": "http://bitcoinembassy.ca/", "v": 0 },
	"1Kirany7i9P4ax39xdnde6swjEXsM3jHGk": { "n": "Kirangtas.com", "l": "http://www.kirangtas.com", "v": 0 },
	"14PSy1uhA1zqANoyJVpic6RC4dPRXc9aYE": { "n": "Kirangtas.com", "l": "http://www.kirangtas.com", "v": 0 },
	"1bonesbTK2GjYasv5yzGPFCMAaQHup4vk": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesTvyiaXXfCchw3S13mX7YrJYzPKm": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesHvnS2WMZnqxLikjvSXCMm5NufD5": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesrnVHLNMW8aXB7hVrTUcLDgS9aZv": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesdTzAKG2ni2apAnmV9SuzL9m1bUP": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesbyLRvN3Dkfx49y9bphEeDRnDLtz": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesHiXzX86DCsbSYXQdrxkEZLkn8m6": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneswgbNSR8z4q6vFhdDfnixTfUXAT6": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesvLbJchpDfUhGMBfag2ZXdL8CjZN": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesSkUQPGdfN1bnjhvPGddsabMAATD": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones6QfYrXwN9Jfm59fFWNpaseYkqxn": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1changecvXk4DnJ8r9ZKsTpyMBx6Fv8eG": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1MiPefQvWcLDzUN8SPseKj91cLsc9WyCd": { "n": "CoinMintersClub deposit", "l": "http://www.coinminters.club/p/deposit-now.html", "v": 0 },
	"1EgrpFYkJeVSvJHH8DLTXbvfAD7KZsYdAa": { "n": "FarhadExchange.net", "l": "https://farhadexchange.net", "v": 0 },
	"126udVzTY7dYDajG5YbQzGESoFnkrJt645": { "n": "LukasMyers", "l": "http://lukasmyers.com/site/", "v": 0 },
	"13zkvhfCcbxTm1v6ni4tkssVPso9jHhtfX": { "n": "danycanada", "l": "https://sites.google.com/site/bitcoinsatochien/", "v": 0 },
	"1MbzvYQsFiCfdxJuxwq61orn8QLivD6m19": { "n": "SETGIS", "l": "http://www.setgis.net/", "v": 0 },
	"15of4vp7DNjE4bJpFe9ztmuY7RBPezH2bu": { "n": "Swat Marketing Ltd", "l": "http://www.swatmarketing.co.uk", "v": 0 },
	"12RCRsHws3PtLJegXJPFdTRWkwKKmfCUov": { "n": "Franci Zupanec", "l": "https://onename.io/franci.json", "v": 0 },
	"188es2KWznUgfE7submHwRaZGgwYCHweVa": { "n": "Econobit", "l": "https://onename.io/econobit.json", "v": 0 },
	"1BBSb2s5sbPLLfY6KzVWHUbCy2scJSHP7U": { "n": "dlerario", "l": "https://onename.io/dlerario.json", "v": 0 },
	"1ECMPLmAyBjm1FJExDvgfVr22NSxtvS5r1": { "n": "Page Not Found", "l": "https://paste.ee/p/w011R", "v": 0 },
	"15zbUuL891m4gCSUJN1H5zmjKxzmqLeGU3": { "n": "keepan eye", "l": "http://paste.ubuntu.com/9066931/", "v": 0 },
	"15vEyLiLKzzoQhCTqoPEQ2icDWy6HLFWg8": { "n": "DC Web Support P2Pool", "l": "http://p2pool.dcwebsupport.com:9332/static/index.html", "v": 0 },
	"14jwPizcAHQ52zFcEjL7qarQFmMxe8wafs": { "n": "Zencoin private presale", "l": "http://zennet.sc/329781y698932f6g9m.txt", "v": 0 },
	"14ZXbe1wFrXDHXbkhnu23ohqn8U6p2wXfu": { "n": "Ivo Smits", "l": "http://www.ufo-net.nl", "v": 0 },
	"1P1rtXRt3sVhQimGFcmhLqPDn58rC4GJEs": { "n": "BitcoFree.com", "l": "http://bitcofree.com", "v": 0 },
	"1HFcF4aJXde7yZ1j9DhsZ6To2F5NKoXvKB": { "n": "FarhadExchange.com", "l": "https://farhadexchange.com", "v": 0 },
	"1BitVPNqCdyG4LEbP7EQE1mvyMvBNWuEtE": { "n": "BitVPN", "l": "https://bitvpn.org/", "v": 1 },
	"18tVQptjvcUYE2S6xVcEvVZqVDbYiLmZB8": { "n": "Datacointalk forum", "l": "https://datacointalk.org/forum/index.php", "v": 0 },
	"1Hypron8gvAqKRJnWW56EfGKw9FQ9oPJv7": { "n": "Hypron", "l": "https://hypron.net/", "v": 0 },
	"16bN1HieFYdkZ5t4svvr57B6BGoKih9pA": { "n": "imagejs", "l": "http://jklmnn.de/imagejs/contact.html", "v": 0 },
	"1GetFCWZVgW5ZQhPGr3AgrbkXHh8FFtx1d": { "n": "GetFree.Co.in", "l": "http://getfree.co.in", "v": 0 },
	"14eVqvfEiDr2zn9fMa5e9iqCFe2Fab2ttV": { "n": "BitcoFree.com", "l": "http://bitcofree.com/", "v": 0 },
	"16PRKHG4Qm26XrYmHbbHLwQnoDRTzbu5xo": { "n": "BitcoFree.Com", "l": "http://bitcofree.com", "v": 0 },
	"1KuNXHQCeCXbTrVacgvQHPSBiVjAWjqxXw": { "n": "Mining Pool", "l": "http://www.miningpool.co.uk", "v": 1 },
	"16u1UDdnmFYDnjYqtKarm5TtzYkwtTQxMX": { "n": "btc2mysql", "l": "http://www.btc2mysql.com/index.php", "v": 0 },
	"1LuckyP83urTUEJE9YEaVG2ov3EDz3TgQw": { "n": "LuckyBit promo", "l": "http://luckyb.it/", "v": 1 },
	"1LuckyB5VGzdZLZSBZvw8DR17iiFCpST7L": { "n": "LuckyBit blue", "l": "http://luckyb.it/", "v": 1 },
	"114UDeGfbHMXyACMWhd75cDv51V5XaS8HB": { "n": "CexStar.IO Hot Wallet", "l": "https://cexstar.io", "v": 1 },
	"1MNbv3Xf5343RhxbhQh3J8946fazEuREEE": { "n": "Avaxiers Cryptsy Address", "l": "https://btcjam.com/listings/23322-3-months-arbitrage-trading-loan-v2-0", "v": 1 },
	"1Hf5EPKMQm9ju2wbJbjD6knvJ3FaP5fNf1": { "n": "BitcoinSatoshi", "l": "https://sites.google.com/site/bitcoinsatochien/", "v": 1 },
	"1HQ2KDTUtSDFAK6GBcEbJknnUe3ToSbTob": { "n": "Antiquitaeten Ghinolfi", "l": "http://www.ghinolfi.ch/main.html", "v": 1 },
	"1C6CR5eRKMy8NnP5TniQ9N3WxMP6Upo54t": { "n": "PlayBitwise.com", "l": "https://playbitwise.com", "v": 1 },
	"1H1RMzujpGC9wZPSjZ6hWqz4BxQ5dzhHti": { "n": "Trinity Desktop", "l": "https://www.trinitydesktop.org/donate.php", "v": 1 },
	"19juqmttHLW3PiVuziUiPeP75xCi7uP2FH": { "n": "Kupuj a prodavej btc", "l": "http://www.SimpleCoin.cz", "v": 1 },
	"13Df4x5nQo7boLWHxQCbJzobN5gUNT65Hh": { "n": "RipDice", "l": "http://www.bitcointaboo.com", "v": 1 },
	"1Ewk9iKm5Hu8Lxq21CMamnaWG6d3NcUc3p": { "n": "RipDice", "l": "http://www.bitcointaboo.com/ripdice/index.php", "v": 1 },
	"1EEQMYaUNg9amcqKMVany7RUsMdPw9o9Bm": { "n": "RipDice", "l": "http://www.bitcointaboo.com/ripdice/index.php", "v": 1 },
	"1BEUFbzbPyK53gWPFEC3vvnWi8nPrqQ69P": { "n": "Faucetfm.com", "l": "http://faucetfm.com/", "v": 1 },
	"17CSWPWUK8yuB25Mgi8sWM5qJ9685CJeej": { "n": "o-namae.com", "l": "http://o-namae.com", "v": 1 },
	"1BLKRWD7g9fegoYmcGSKgZmFdszdBY6cLD": { "n": "BlockReward.IO 24H Draw 3", "l": "http://www.blockreward.io", "v": 1 },
	"1BLKRWDC5M4Y1pTtw8jLMwtperrfWz9qAw": { "n": "BlockReward.IO Weekly 5", "l": "http://www.blockreward.io", "v": 1 },
	"1BLKRWDKZ7cyBoHL8rC7rbjsxbbBYNy2Kb": { "n": "BlockReward.IO Monthy Raffle", "l": "http://www.blockreward.io", "v": 1 },
	"16MWsuCw1agWmnShGJSyMMaTkEtTYAGN54": { "n": "Curt Loyd Hot Wallet", "l": "http://loyd.ca/who-is-curtis-loyd/goal/", "v": 1 },
	"1LqJ3CSsmngJhEVoYX2Txud6VnStnYycxU": { "n": "New SMS", "l": "http://newsmstemplates.eu/", "v": 0 },
	"1changeG66UxuWyBfpyPx5RBDfkByKcWy": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesPZtq8r6ja9dDYUSZo7SAx9v2gz4": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesvtyQDoKWWGh2DNRF6g3jZBRgE7t": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones9uYQ5vDhbuYS9wfCVQm4rSDMYEr": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesfW9g5cWHgx7YUuDCt5FKFX42pmL": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesB1waJtUi5huouUcTSQDS6NR3GYQ": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneseYh42WJQH4m2Nwczq9todUM9FmW": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesNcbrNbHJZr33LV2gBmDS9m91TWz": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesRDcJsuJ4EcKdYf7pPew7vZ7aoD5": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones5trmkZXMtyVrtYY3Y9qhVxB3otm": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesUmpGft7BhBWsW4k6Uo1UfRCquQ2": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones7KGaDCLsnt4f8xwnKUptkLkVC2p": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"13YxyBLgjARKyg35e9fBwMfZpVtDrnG6TH": { "n": "Girls in Ankle Socks", "l": "http://as.ez.lv", "v": 1 },
	"1NCiZjzHpsXFBPXFTLbbBCwogJezdWpoAB": { "n": "The Seasteading Institute", "l": "http://www.seasteading.org/donate/", "v": 1 },
	"1DtZpWPMaZwBjcwGtT9fvFmaZB9xcaE4B5": { "n": "Ryan Davies", "l": "http://www.ChristianFlatshare.org", "v": 1 },
	"14hZEbjPgtM9und2xK987UnZsEdHkssPeV": { "n": "FUNDABIT Crowdfunding", "l": "http://fundabit.co", "v": 1 },
	"13fuXa9NEPzU31o7DqpruHDH18eH9VhE8b": { "n": "CharterAce.com", "l": "http://www.charterace.com/letthebitdrop.html", "v": 1 },
	"1GPCsaSYwH6jcUf3BmgqXD6G5q1ZxJ3gUK": { "n": "Where To Spend Bitcoins UK", "l": "http://www.wheretospendbitcoins.co.uk/donate", "v": 1 },
	"12tNvHpG95B4nEmt4swmVHWrDZpqPZf6Fa": { "n": "Best Bitcoin Casino", "l": "http://www.bestbitcoincasino.com/", "v": 1 },
	"1LDTtftZg2Winp8vnkZReFJcJ1d2BYBT2u": { "n": "Bitcoin Gambling Guide", "l": "http://www.bitcoingg.com/", "v": 1 },
	"1MVpQJA7FtcDrwKC6zATkZvZcxqma4JixS": { "n": "CryptoGraffiti.info", "l": "http://cryptograffiti.info", "v": 1 },
	"16unMUyU3fQGifYJEeoWugYK8AyS1TPe25": { "n": "eXch.cc instant exchange", "l": "https://exch.cc/", "v": 1 },
	"1a8LDh3qtCdMFAgRXzMrdvB8w1EG4h1Xi": { "n": "Tim Draper Auction", "l": "http://cointelegraph.com/news/111979/feds-sell-29656-bitcoins-to-single-bidder-in-silk-road-auction", "v": 1 },
	"1D3PknG4Lw1gFuJ9SYenA7pboF9gtXtdcD": { "n": "Straight opensource gateway", "l": "http://straight.romansnitko.com/", "v": 1 },
	"1K6e6cxut3i3cnMAznm2G8husTNFPAppBV": { "n": "HashPrime - Invest or Trade", "l": "https://www.hashprime.com", "v": 1 },
	"1PonziSPomZskfn9mR59v45SdpBG3MgEob": { "n": "BitcoinPonzi.com", "l": "http://bitcoinponzi.com/", "v": 1 },
	"1EXQ8E6xMwp5wBsYPndsRjhhoTtBA2NPYB": { "n": "Instawallet Hacker Bounty", "l": "http://bitcoinbountyhunter.com/instawallet.html", "v": 1 },
	"1MmoevQactzxkTLvsgrKccZcHUiXLHqLXR": { "n": "Bitalo.com DDOS Attack Bounty", "l": "http://bitcoinbountyhunter.com/bitalo.html", "v": 1 },
	"13DvkQTf6GvKsG1bXWZ6MLnCC7Hk5kenny": { "n": "Pablo777 Arrest Bounty", "l": "http://bitcoinbountyhunter.com/mybitcoin.html", "v": 1 },
	"1changeh8BsHPA23f1rgtJWYnpAozp9dB": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesk1zETygC8BSeqm7nQEf6MJ12ucs": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneskFThZQW7yMiAZYPPa5X7hr6C1j3": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boness9kPxgmRiKFZH9h9SZmuDJqjrQ9": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesQydbB7vpBoNRwmrDigkeKmtwXpB": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesfxNk4yDVMz8XZUyYgSrBdsRJKhj": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesknhepHu2WiGqfJq8FFdcURDAiZp": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesyuMYEZQBQmy4Z6N9gpoNHqx8Dev": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesdkSaBCpqSd2prFYfBojWtdtNMq4": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesa6Hjc7Ge5xgFedgHkcK9y8X29i9": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneshwG5e5MhNyrhKfPQnURqhpm4Nnr": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones7Pf37sj5eEMRXwNVAYoBgUtq4SR": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1LfqiTWYURdJFUFwgnrtPGU48ikgNUJqBf": { "n": "bitcoindice.io Dice Safe", "l": "https://bitcoindice.io/", "v": 1 },
	"1E9BhxT1sjXPbSXM5Kx3aY29fBRbZKNb8k": { "n": "Hack420.com", "l": "http://www.hack420.com", "v": 1 },
	"187Udd14Eqmfm4oAtEhSvau7kmasXn2e4j": { "n": "Satoshi Email Hacker Bounty", "l": "http://bitcoinbountyhunter.com/satoshi.html", "v": 1 },
	"1BxnWAp8WocujeLszRDAs5cWAy9QVR4Vau": { "n": "MTGOX Hacker Bounty", "l": "http://bitcoinbountyhunter.com/mtgox.html", "v": 1 },
	"1CDjCwSjU5UCHBCK8v9zvVzVLJxcy5EDyH": { "n": "Bitcoinica Hacker Bounty", "l": "http://bitcoinbountyhunter.com/bitcoinica.html", "v": 1 },
	"1NdZpP8tb6pwLuZMXsJN4JZqUFk2wkAhTs": { "n": "bitcoindice.io Dice Safe", "l": "http://bitcoindice.io/deposit_withdraw.php", "v": 1 },
	"1Bh7RWUW2Ri7Nnx4A5bi7evTHZy6hoByYD": { "n": "bitcoindice.io Dice Safe", "l": "http://bitcoindice.io/deposit_withdraw.php", "v": 1 },
	"1By3iYdHavcjXR7LyhWnhcd6prj4G8pRv6": { "n": "bitcoindice.io Dice Safe", "l": "http://bitcoindice.io/deposit_withdraw.php", "v": 1 },
	"1CU1JBUCqMKgrhLG2KYdwjQZjopHKbKNmL": { "n": "Assured Assets LTD", "l": "https://www.a-assets.com", "v": 1 },
	"1KfQWDDNwiAseBJPF5xhcFPvcE6bJfGn2K": { "n": "BitToClick", "l": "http://bittoclick.com", "v": 1 },
	"1CFptdZU8HfqLKE1TzF86iUkJGeEYMBUzA": { "n": "MS Investment", "l": "https://msinv.biz", "v": 1 },
	"1LSpthh6v5zFkFe3f6hMEqC2sgCYDmuh48": { "n": "pagerankbacklinks.blogspot.com", "l": "http://pagerankbacklinks.blogspot.com/", "v": 1 },
	"1PKN98VN2z5gwSGZvGKS2bj8aADZBkyhkZ": { "n": "solo.ckpool.org", "l": "http://solo.ckpool.org/", "v": 1 },
	"19pta6x1hXzV9F5hHnhMARYbRjuxF6xbbV": { "n": "Satoshi Blackmail Address", "l": "https://mineforeman.com/2014/09/09/warning-do-not-download-bitcoin-from-sourceforge/", "v": 1 },
	"12bRFd4EbLXXiEvt3JHMRHy2LYEacxNjQD": { "n": "dicenow", "l": "https://dicenow.com", "v": 1 },
	"172DGVWTVorL4bBrwqXcf2s4XEKMxS5noV": { "n": "dicenow", "l": "https://dicenow.com", "v": 1 },
	"1Ng5ay5JGnAexiNwGM7fEmq7ZMLMXirUFr": { "n": "dicenow", "l": "https://dicenow.com", "v": 1 },
	"1MuZQjXXJzUFEei7c5F9s3tpPmQ2nsg4u9": { "n": "dicenow", "l": "https://dicenow.com", "v": 1 },
	"1G4suH25rpxiMxwScJJty4jLRZo83B2L9Q": { "n": "dicenow", "l": "https://dicenow.com", "v": 1 },
	"15ferLnmLuWcegDUcbCuh2xGboPNaQrAxD": { "n": "dicenow", "l": "https://dicenow.com", "v": 1 },
	"1EgH7EUfgjr8gAK9t1BeHLDC1ijrVvdec3": { "n": "Bitcoin Lottery Tickets", "l": "http://gamblingwithbitcoins.com/bitcoin-lottery/", "v": 1 },
	"1PauK5AnMSUZUUaAqX7MXsKn4iGYjKVQjE": { "n": "Coin Academy", "l": "http://coinacademy.co/support-coin-academy/", "v": 1 },
	"1CoinBuxfL8JvwCVh98sn2kPt558EJph44": { "n": "CoinBucks.IO", "l": "https://www.coinbucks.io/", "v": 1 },
	"1NGhV1z5FuKCgKSqB3KJzNjkNBYQSgZBqC": { "n": "Libertarian Nuts", "l": "http://libertariannuts.com/tip-encourage-us/", "v": 1 },
	"12CGNzfokA4K6Bmr2VFyH9t6BeJekT7uB7": { "n": "Bitcoin Services", "l": "http://ethereum.today", "v": 1 },
	"16J8UAn5wNiCRLYkfkSZsAtWN3SG1VD7tp": { "n": "LetTheBitDrop donations", "l": "http://www.letthebitdrop.com/", "v": 1 },
	"1JsnZLEGgLJY7rbDdaKTzC2JyvfaKUpF5p": { "n": "Hal Finney Fund 4 ALS Research", "l": "https://bitcoinfoundation.org/2014/08/join-teamhal-give100-wbitcoin-to-the-hal-finney-bitcoin-fund-for-als-research/", "v": 1 },
	"1LaxoTrQy51LnB289VmoSAgN6J6UrJbfL9": { "n": "Laxo Trade", "l": "https://www.laxotrade.com", "v": 1 },
	"15mrXfBXFDoyEr54upsnsF5tMvfo1N5WUA": { "n": "Social Fixer donations", "l": "http://socialfixer.com/donate.html", "v": 1 },
	"1L1nRXZTXsLTPuKoH4RqDGKocYz7Wmr87q": { "n": "www.Win88.me", "l": "https://win88.me/wallets", "v": 1 },
	"1GKteHLzGD1PWFJkGm5k7anj568WCasftg": { "n": "www.Win88.me", "l": "https://win88.me/wallets", "v": 1 },
	"17bh7RnTxV67FtuegS3Ufj5mC1WU5UxNNw": { "n": "www.Win88.me", "l": "https://win88.me/wallets", "v": 1 },
	"138c6hUhay1rCqqPHaWdhyb4GWWGTLXoqH": { "n": "www.Win88.me", "l": "https://win88.me/wallets", "v": 1 },
	"1SHunt6uG7HDzGhP3WokKwhYTa5rtZZZp": { "n": "Satoshi Hunt", "l": "http://satoshihunt.com", "v": 1 },
	"13FT8vjbaDEEr17HAaHjPrsXUUn2bxz8J6": { "n": "Gambling with Bitcoins", "l": "http://gamblingwithbitcoins.com", "v": 1 },
	"1CatnMd3jsEKhwhSLUf8V862im8gBp3NDF": { "n": "Cannabis Road Stolen Coins", "l": "http://www.deepdotweb.com/2014/08/25/cannabis-road-hacked-100000-in-btc-gone/", "v": 1 },
	"1P29GBFUUDwfZFd8mhx3jXsaSZUMp4t96v": { "n": "ChainRadio", "l": "http://ChainRadio.com/", "v": 1 },
	"17nUCBwLFEbDPQ1EFNE4576c5k3uQ3S1NM": { "n": "Bitcoin Betting Review", "l": "http://www.bitcoinbettingreview.com", "v": 1 },
	"1bonesyy7aCNtx4Dnbm3zPGmPkA46aGaT": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonestCxHYNU1WS7iJbUcwNATxkHiKfF": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesCnkcLV27oiLK5cBU3eDNmxPJ9WX": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneshgco8UaaQCmB92dVg5ugxiHxTTs": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesuGU6EUAF9ghkwTBoFBZxKhtXaFi": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesG3JKbfw33SQKRAXfvjTM5VMacNC": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesgdNQG9NgNjW7XWL4Pfk1KRcDbpU": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesaaKg8t5oD6ira65yLijP2hRXida": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesdKFDAS4RGvciaGmf3xyEVtg2rkD": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesxRFyPySDjQ2sD2LjqLMujcUSFBn": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesMJonxQDvSPXnjegM1ToyxCKrBW5": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1changewqhJdMgXVspf3pNcBaRNyKQcqt": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1FiHwhYH53uhJQYUnTxQ9AVgXDmqxSnr5a": { "n": "Mane Salon Wellington, NZ", "l": "http://www.manesalon.co.nz/our-services-hours-prices/", "v": 1 },
	"1H4VYwd7NhWcU4cdoUc799P5PE1PQMBm5y": { "n": "Charitycoin - Donate to us", "l": "http://charitycoin.co.uk/about.php", "v": 1 },
	"16tmA9UJG8pACPWHYYRJKCWRt3pwDBmksn": { "n": "Sea Shepherd Australia", "l": "http://www.seashepherd.org.au/support-us/support-us.html", "v": 1 },
	"1Hi6vyQr9w2QR78K7kujbyEmb6hykfqRed": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/", "v": 1 },
	"1DvQHVpNT3LwE36ngC6sUjeeKcB5a1rhE5": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/", "v": 1 },
	"16KWhiJY1zSKAHQ9GDB9s93QonoPZbxu74": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/", "v": 1 },
	"17JEwv6r4HXetNtpNHdf3cJhjDGBbiRjy6": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/", "v": 1 },
	"1Ay9mka7oCdaNeAm3aZp8a74sniJ6MFh36": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/", "v": 1 },
	"17Gxj1ddoLAPa3P5FfyW3RXPopXRRjeqTw": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/", "v": 1 },
	"33naxH1UuKjN3zTFmprZmXRXLfAHUM6Lef": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/", "v": 1 },
	"39zLfD91XdDjAC6WE5XYwuBbkcaPxr6WfA": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/", "v": 1 },
	"3LZMwqpt26grFUPagBM3QbPeBrzVZbtbG3": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/", "v": 1 },
	"3Juiry7kG4ZNYWsnadf3KApwsU3tMVti4G": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/seo.html", "v": 1 },
	"3E81LMCxiS1FyrLcr2RxC1bq3Wn6nqrCiz": { "n": "FrozenBit Offical Address", "l": "http://frozenb.it/seo.html", "v": 1 },
	"16uniUFpbhrAxAWMZ9qEkcT9Wf34ETB4Tt": { "n": "OpenBazaar", "l": "https://openbazaar.org/", "v": 1 },
	"1HpCB49gXbRdVQLrnLi2TFMnq4KXgA8ALe": { "n": "Francis Pouliot", "l": "https://onename.io/francispouliot.json", "v": 1 },
	"1AQjWTtRvpqr7AWYZgFxqYtX5WZHnMYCmi": { "n": "charitycoin.co.uk", "l": "http://charitycoin.co.uk/donate.php", "v": 1 },
	"1AiBmj91iiiQ5PfwhEQbH9GwJVrFJuFwAH": { "n": "BitcoinSpout Alternate", "l": "http://www.bitcoinspout.com", "v": 1 },
	"18dQFj1sDVXekLNQjpejDXybETT2JzUwXb": { "n": "BitcoinSpout Primary", "l": "http://www.bitcoinspout.com", "v": 1 },
	"1EWVU69nRrrN6FCoV6hBUWAqu9Wa1bKXNS": { "n": "BitcoinSpout Donations", "l": "http://www.bitcoinspout.com/faucet", "v": 1 },
	"16GCyEnQ5gZd1GkZviQxGtwAj5QB7cnr6V": { "n": "BitcoinSpout Faucet", "l": "http://www.bitcoinspout.com/faucet", "v": 1 },
	"15TAYSLzerpmZZmdve6z7spcG5EAHytH6W": { "n": "NoctumDesign BTC Pool", "l": "https://mining.noctumdesign.com", "v": 1 },
	"17avikAGcJzQMQTHwuAPVudX62JavEBhM9": { "n": "Randin17avik", "l": "http://Randin.Org:8080", "v": 1 },
	"1DaiDy8FS6PeKywWpRtmjCkH5nx3gfeBfJ": { "n": "Ewallit.org", "l": "http://www.ewallit.org/", "v": 1 },
	"1PZ5ebvdt43dvRRgRNgBhsq2PwAKN4X6W": { "n": "RNLI donations", "l": "https://rnli.org/howtosupportus/donatenow/Pages/bitcoin.aspx", "v": 1 },
	"19tpssiSi1TkEomeZrtnVEBVQJwcjjS3RH": { "n": "Visa Master Credit Card", "l": "http://www.prepaidvcard.com", "v": 1 },
	"16jFovZho4ZyLy7WqQ8hsEoUrScPFWELNH": { "n": "Il sera...", "l": "http://ilsera.com/", "v": 1 },
	"1changebAVCEq9yWxVSEK6Rq2upf4hV7R": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneszACr8r7nGb6Xw7MRpFnC4pkeczL": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesfHG9D5e7WhRvaVtXPdw7LsgKFXP": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesrf3a4PyBokgMpMqVVd6zpF2eDdU": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones2YvBxvKxCE9HVcVgekwU2KR6Ngo": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesz84zomMcFF3i4HsNTDPiUS3VyQf": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesEAKv6Ci1Cug1sY3wtL5q8rV3RHz": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesQ8JwZLvFahW5c9GH9ivrKesqF62": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1boneskt6TM464X7tGpv6bekXAzbRVP7J": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesKMPpCDViQVGjdxn9ZjLiSFScGKb": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesHa6Dt1xW1YQD5p6nF1bnmeDpW6c": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones4hKdFXvXUPUuzwbe84nBwXBPBri": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"18qQ6ix5xn1m1ZiZ5QUojS9yEB67e6CScT": { "n": "Schildower Kreis Spenden", "l": "http://www.schildower-kreis.de/spenden/", "v": 1 },
	"1CNDM2Nej4nKfhN5L5yc1jx7jvTKKedvd7": { "n": "CoinNotify Dice 91", "l": "http://dice.coinnotify.org/", "v": 1 },
	"12N7bNjVyZSSXws8y4fJNCpG5oHKc8Ljoi": { "n": "Try the Fastest Mining Pool", "l": "http://p2pool.co:9332/static/index.html", "v": 1 },
	"1Bonus1rCVr98RVQC3a8aT2dHGJYK2xnf8": { "n": "BitcoinCloudServicesReferral", "l": "https://www.bitcoincloudservices.com", "v": 1 },
	"1Ba6EL6FBrdkjeR1NXxKYUdq6ALB41EYrb": { "n": "Come get your free Bitcoins", "l": "http://www.gratisbitcoins.tk", "v": 1 },
	"1Psxi6EZ3gderhkQnzdKeZArEm8AnhyDiP": { "n": "s-BTCdonation", "l": "http://s-btc.co/", "v": 1 },
	"16Ys4su4d6Dc2MHw1BLXPssojqTkWvB81G": { "n": "btc.sui.li", "l": "http://btc.sui.li", "v": 1 },
	"1PCkVX19uGm2QK1vhcXy9uM4y2jwR4dgbF": { "n": "Orisi - Distributed Oracles", "l": "http://orisi.org/", "v": 1 },
	"1G54xRMHBQusXXdTShcR6eeesStvjJV2vo": { "n": "Badbitcoin.org", "l": "http://www.badbitcoin.org", "v": 1 },
	"1Ross5Np5doy4ajF9iGXzgKaC2Q3Pwwxv": { "n": "Free Ross Ulbricht", "l": "http://www.freeross.org", "v": 1 },
	"1changeiYR9W6azZSoL9go79b9bN1aGED": { "n": "SatoshiBONES Hot Wallet", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa": { "n": "Genesis of Bitcoin", "l": "https://en.bitcoin.it/wiki/Genesis_block", "v": 1 },
	"16fuoinLFjBmiCYmCYDXPNfERJtdPB5ASe": { "n": "ASICMINER shareholder payout", "l": "http://bitcoin.stackexchange.com/questions/11670/how-to-verify-asicminer-share-ownership-through-bitcoin-address-blockchain-inf", "v": 1 },
	"196A7czbZum2nKNNwhHDeFcaGdacxPwfPB": { "n": "substack gittip", "l": "https://www.gittip.com/substack/", "v": 1 },
	"115tTroRo3B9ZDQ6ATJGDCHcNEVbjJoZnF": { "n": "ASICMINER shareholder payout", "l": "http://www.bitecoin.com/online/2013/06/586.html", "v": 1 },
	"12gDb8j14yT5LTCGEB9eyiv5xqyphhvQhU": { "n": "BitcoinPoster.com", "l": "http://bitcoinposter.com", "v": 1 },
	"1PLANETdSJsAAhEmJ6y4iPEiPsPvDSWcTw": { "n": "Lets make BTC carbon neutral!", "l": "http://www.1planet.org", "v": 1 },
	"1EPtdN9TtZp93uNHYxCA4FEWBY1seRthS1": { "n": "SPAM SEND", "l": "https://google.com", "v": 1 },
	"1DkRWKXpfQwm5b1pGL2QdpPdrUdKSdzbnG": { "n": "SPAM SEND", "l": "https://google.com", "v": 1 },
	"12TSXLa5Tu6ag4PNYCwKKSiZsaSCpAjzpu": { "n": "CVM (VPS panel)", "l": "http://cvm.cryto.net/", "v": 1 },
	"1Ez69SnzzmePmZX3WpEzMKTrcBF2gpNQ55": { "n": "US Marshal Auction coins", "l": "http://blog.cryptocrumb.com/2014/06/us-marshals-bitcoin-auction-not-clean.html", "v": 1 },
	"1JKEm9kPoQq9KQqakLrs2jkYszuGu99y6y": { "n": "exchanging.ir", "l": "http://exchanging.ir/", "v": 1 },
	"1Ks5aLkREyVUba3QiS64ZL5PPdcgXDXhBp": { "n": "old address", "l": "http://exchanging.ir/", "v": 1 },
	"132SuGpqsP8oSFmGXt6TPb1Q3sNgXZhWAy": { "n": "Japanese Bitcoin Information", "l": "http://bitcoin-with.com", "v": 1 },
	"1PWSRwXrscHnHajM6hESzAosdpmaRuBL8Z": { "n": "btc.sui.li", "l": "http://btc.sui.li", "v": 1 },
	"1LyLJAzxCfieivap1yK3iCpGoUmzAnjdyK": { "n": "Pixel Dungeon", "l": "http://pixeldungeon.watabou.ru/", "v": 1 },
	"3CNky61wvc8Do5Mmv73t1XJXgriXJVB6Qy": { "n": "BX.in.th Cold Storage", "l": "https://bx.in.th/info/transparency/", "v": 1 },
	"1579eDPqbFUQsAqm7LgkQvsKKGMPRSTK2a": { "n": "Loja B", "l": "http://www.lojab.net", "v": 1 },
	"125ZumCPPxokALadXZZTiVWmVia1KizSFv": { "n": "feminist-phone", "l": "https://github.com/konsumer/feminist-phone", "v": 1 },
	"1BTCPayb5AdF8fSsR7oews2PpuVpRtamk6": { "n": "BitcoinCloudServices", "l": "https://www.bitcoincloudservices.com/", "v": 1 },
	"34rpRuMijYdABDGsxuGmGwE6uVDQ2ACYEW": { "n": "FrozenBit.io Offical Address", "l": "http://frozenbit.io", "v": 1 },
	"1ALA5v7h49QT7WYLcRsxcXqXUqEqaWmkvw": { "n": "CloudHashing", "l": "https://cloudhashing.com/", "v": 1 },
	"1JaBY6Yqf8vU9KQptLGHTf7HE8wiLhSi2a": { "n": "[Ebook] Economics of Bitcoin", "l": "http://jpja.net", "v": 1 },
	"17U5JyJfHAMKoyGe6xfWDCkhb8hyQbECCm": { "n": "test001", "l": "http://www.douban.com/group/topic/34190856/", "v": 1 },
	"1CQUH3rYPYLdn8Sg5TRjzaCn4zrvjNE8RU": { "n": "open-nodes.org donation", "l": "http://blog.open-nodes.org/2014/06/14/open-nodes-plan/", "v": 1 },
	"1BerLinfq15hQJom5eAS72BKwxXq2Z3F3E": { "n": "Be Bitcoin", "l": "http://www.bebitcoin.com", "v": 1 },
	"1NEWBfeEiyM5HC2ERf7ZWHN6DEdjbVXvEW": { "n": "NewbiecoinFund", "l": "http://newbiecoin.org/technical.html", "v": 1 },
	"1i7cZdoE9NcHSdAL5eGjmTJbBVqeQDwgw": { "n": "DPR Seized Coins 2", "l": "https://bitcoin.org/en/", "v": 1 },
	"19fDsgnsQrTDxCksUH16DXzbhCU34ng4PN": { "n": "Bitcoin exchange Bitmarket.lt", "l": "http://bitmarket.lt/", "v": 1 },
	"1Kx4wVYBvbL6khNhA3SmJKnT8ZLeJHPBxA": { "n": "AirChat project", "l": "https://github.com/lulzlabs/AirChat", "v": 1 },
	"1Fm8G9wwZLn2zxPodrjN2ZQ81923S9VHj3": { "n": "SinteDon", "l": "http://www.sintesun.com/eventos/", "v": 1 },
	"1EJDzF7S9v3enrQPAaaLAUEKTn3i9XRXjZ": { "n": "btcX2.com", "l": "http://www.btcX2.com", "v": 1 },
	"1bankDouR6HyfX2ea7k6a45BEUX5DhhUD": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank2Pfd1jLxTKoNLmXMCjTgP89TbRew": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankRDgpcMYVhKmbHmh8zan1m3Sg6LhB": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank39HnavwxzMxCwnkYPZ8rdQthDjsf": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankQmiUpVQeAq95i5MSbRmEV4LcP7C3": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankYaUSeZHxhx34HiCZK4QDRj5cnWV2": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankFmjvJDfnR3rFSzeS4Mszoz7Np6gQ": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankHX7RNnkoudbFVW7CMZJgL4x3o2RQ": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankAGuwefrNfYW29s6frY8msAe13eyz": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank1Jnq6gB1dP59aCeuJYb5nZgdmxeZ": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankWDB7kB9RnxFezVGvfDjps14VTPcK": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank3B9eCztukVihspadc4aa85oVgANP": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankY64rSbMkc1F7T4zZ4L9LW5ojefCk": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank3Uzo8MCfhhRLSZwQnyX1Q8bkAiXg": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankXJQABJC8cT8icfLLvk7AvTVd1NC9": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankUU82veGBfzZ89EfMMXhEGS3Nu6TA": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankTBkvmBo95tpjHcQasTd3deLNAFnr": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank8YJx2qB7ykJLmTac4TPL6kJ5cb7q": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankz3vyucGoN2fzPs4bhZk2Q2rzXTRy": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankFW57de5USQUcDEMLVM1JombMa22U": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank8m8vBU35PNmpNKDmWmjLRwiSsmRE": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank4CRgGjJZ8zp2D46oJi21m3J1htqZ": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bankQR16PGpQpxkSmxYwjqpo8712Zagc": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank6UYiqUGjPp1TfnpQAmkgeURdcfMg": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bank8qHvpZSNbLmAYjr1cy3FDrZsZ5eC": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"18uvwkMJsg9cxFEd1QDFgQpoeXWmmSnqSs": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1HjDauL2kth6KJUz5vX198Nvp1xN1hgYRb": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"14719bzrTyMvEPcr7ouv9R8utncL9fKJyf": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1GoK6fv4tZKXFiWL9NuHiwcwsi8JAFiwGK": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1JmcV7G3r8k7ev2EkS84MmsvxGyhiRGP84": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1L4EThM6x3Rd2PjNbs1U136FpMq4Gmo3fJ": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1AdN2my8NxvGcisPGYeQTAKdWJuUzNkQxG": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1NDpZ2wyFekVezssSXv2tmQgmxcoHMUJ7u": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"13HFqPr9Ceh2aBvcjxNdUycHuFG7PReGH4": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1Bqm5MDo82m1FTxV3qYNUUEKnESPRhk9jd": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"18czPiA9PcCs7rFTBZnhvNAWuh1pEZRpGJ": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1PeohaRGaTF8cSzDqP1yYfzDah66xiriEQ": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1MSzmVTBaaSpKDARK3VGvP8v7aCtwZ9zbw": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"17NKcZNXqAbxWsTwB1UJHjc9mQG3yjGALA": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"12Cf6nCcRtKERh9cQm3Z29c9MWvQuFSxvT": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"14ChPPM8rPYJeHnw6kMVUDnNNKx1KnjYW4": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1DpsR91YmHUDTtiuH1pPCuG3RqAkmg6YKB": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1J4yuJFqozxLWTvnExR4Xxe9W4B89kaukY": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"15fXdTyFL1p53qQ8NkrjBqPUbPWvWmZ3G9": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"13h1DP2Boo9TAsenphroACxhNy7pGxDYXd": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1HVpyjYEPwQhvRQ3dL8tGe9kiydti616sX": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1HZHBnH2FbHNWieMxAh4xBPfgfuxW15UPt": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"18XSLnBZ8ydMUkaifU6sQBMJzmm7JvDeUp": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1Bd5wrFxHYRkk4UCFttcPNMYzqJnQKfXUE": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bonesNKdmRcukU4pkZ6ptZMRVsq9fAoR": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones4zpoJ7Q1CDW5ttbFDNzsiiXJWm1": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesELhEQ9F9qpTzTcdBp9Ud8haNjGN": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesEtEkQTQuUSDWLHebLCGtaKo2XEG": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones1K7nsLF8aUJD3rtWUb9gTrxzuRq": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"16LkqztAL2HVyRmYZ5TrcSJX6LtcBRSXsZ": { "n": "AppAddict Donations", "l": "https://www.appaddict.org/donate.php", "v": 1 },
	"12ZL4QXcbYac7rJPXbqyaC71xscCSAe4WA": { "n": "DKMS Polska", "l": "https://www.bitmarket.pl/charity/", "v": 1 },
	"1Agora9CTt54xUtJRU8yDJB5LP4JjRQfr3": { "n": "Agora Vanity Demo", "l": "http://freetexthost.com/6k31grfadg", "v": 1 },
	"1J855zconGe9h1NSWrynRgwTPf6zq7aiXC": { "n": "Best Bitcoin Gambling Sites", "l": "http://bitcoingamblingsites.wordpress.com/", "v": 1 },
	"1Lg5asn8s2Cya6fN7ByyYiSAHECt7STP1v": { "n": "KunaBTC", "l": "http://kuna.com.ua", "v": 1 },
	"1JVtKo9NMtTwFehtycWrmYZjSL1UMkkdMQ": { "n": "TradeOpus.com", "l": "http://www.tradeopus.com/bitcoin/what-is-bitcoin/", "v": 1 },
	"15Mb3E3kcTqThNZitaYwWZ7PwZGQwXcUpU": { "n": "BetChain Bitcoin Casino", "l": "http://www.betchain.com/faq", "v": 1 },
	"1PaK9jnP7uZFFJvg2N83UB3kaHEFPD6wNb": { "n": "BitcoinChaser Poker Reviews", "l": "http://bitcoinchaser.com/poker", "v": 1 },
	"18UsFJZWrv6tvBhjNuxtdGKpLkNM3k6zp5": { "n": "BitcoinChaser Casino Reviews", "l": "http://bitcoinchaser.com/casino", "v": 1 },
	"13ULoNrYTavFPovDkR1DL3iAZksShbQP7g": { "n": "BitcoinChaser blog", "l": "http://bitcoinchaser.com/bitcoin-blog/", "v": 1 },
	"19VAtJ9mDyG63vh4M8KpTfSWRsrpgtbGj1": { "n": "El_Happy", "l": "http://faucet.elhappy.net/index.php", "v": 1 },
	"1HevPAAYgU239ufPeiZxbY96KyeAbD1Bh1": { "n": "charlycoste", "l": "https://www.gittip.com/charlycoste/", "v": 1 },
	"1MFhwQahS8bnb3Dt8xTPst61kWQqhopQxH": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1Lqfvq7NNDkJAyPR3HGB9QTVtNn1toF5yH": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1LD9DWeuJdFF3zzLQf6AtcdXWEJB55vknx": { "n": "UpDown.BT", "l": "https://updown.bt/t/goldc", "v": 1 },
	"19kc4ckSqPnDeUSzvWS7qXgGZWSYJpdgpk": { "n": "crobitcoin", "l": "http://crobitcoin.com/help-central-balkan/", "v": 1 },
	"13kc9xzXEAfbQcBp3gGi4orsCXrriko6zY": { "n": "Earn Bitcoins Online!", "l": "http://www.coinwork.cf", "v": 1 },
	"1Donate69zAwJJCiot5RUw3eRxgq3e6cPe": { "n": "BTC casino list donation", "l": "http://www.btcgambling.co.uk/", "v": 1 },
	"1bones8KbQge9euDn523z5wVhwkTP3uc1": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones3WHcdVJKshaifmp9AhRcsJ6QRbu": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones7g3iWw3FRNNHQu2p65FUvnpbi6u": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesBC3m6TkNZaCEskzxwMTux7ebNAS": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesYHFG1DWxiZR5vdQkKuDMHbfgz8R": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"175KrSt33GWPyEuRc3Zf4XjBSfAumbM2s7": { "n": "DuckDuckGo", "l": "https://duck.co/help/settings/adblockers", "v": 1 },
	"15DwRPNhNUVq8kbMb7LNHZzH5AwTbpK2g3": { "n": "CryptoCondo.com", "l": "http://www.cryptocondo.com", "v": 1 },
	"1Bp5Qf8UKtMzMboaPGa8qpVESZnAPkvYxc": { "n": "BTC reminder", "l": "https://code.google.com/p/btc-reminder/", "v": 1 },
	"1MPerpQzTABa1K2eXQxsQTDSZtDQHWf6vk": { "n": "SatoshiDICE Hot Wallet", "l": "https://satoshidice.com/proof-of-reserves.php", "v": 1 },
	"1bones6kTC3EgXLSpcnkRXvERHbYyWpFk": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"19vXrwKGUhK4cCU8tA4kWZgbChcmh9a6qj": { "n": "Mine with us - Fast P2Pool", "l": "http://mining.coincadence.com/", "v": 1 },
	"1FDgnXtiAjVH1cKTM4pqWqgS1XdGhdhW4h": { "n": "G-ROM TASSUAC", "l": "http://webbtc.com/address/1FDgnXtiAjVH1cKTM4pqWqgS1XdGhdhW4h", "v": 1 },
	"1EKbJxmNmE3bARMin9NuCDTenJLFh6pE9r": { "n": "abbeytims Debt Relief Fund", "l": "http://SupaForgotHis.pw/abbeytimsDebtReliefFund.html", "v": 0 },
	"1AiiE1cojmrapi5oqnNeuJp48BsW8GzEgP": { "n": "abbeytims Debt Relief Fund", "l": "http://SupaForgotHis.pw/abbeytimsDebtRepaymentFund.html", "v": 0 },
	"1RUnFb2zoqMpLbqPU6Yv9KbWvLMeqxtNx": { "n": "Earn Bitcoins Online!", "l": "http://www.coinwork.cf/", "v": 1 },
	"17KURPHdCa7vVMUJEDvehhwWCYDs6LGngB": { "n": "KURPH", "l": "http://Groofy.Comuf.Com/Free-BTC/", "v": 1 },
	"13CChHmYHDMCfFpVDjnpEPfsijUUjjcccc": { "n": "Bitcoin scammer themad2403", "l": "http://bitcoinscammer.wordpress.com", "v": 0 },
	"1Gnh1TWmyoNipmGC2u4ofyNcVZPudEjuVn": { "n": "Martin_Schulze_Berlin", "l": "http://martinsmine.blogspot.de", "v": 1 },
	"1MooseXJNFugR6r26aGk2AM8v7Crrk3iVE": { "n": "BetMoose", "l": "https://www.betmoose.com", "v": 0 },
	"1MrGoatfJLf2X4USFYCdx48wdo2Xj1szfn": { "n": "Mountaingoat", "l": "http://www.btcgambling.co.uk/", "v": 1 },
	"1BNwtEPanWJ9VLdiJebtykQJgk3eEZFh52": { "n": "pcfli", "l": "http://www.easy2mine.com/buy/", "v": 1 },
	"1Dk5EBtpH1iGpkszeujtNHnRP3gLxBmXhz": { "n": "BitcoinPriceGuru", "l": "https://bitcoinpriceguru.com", "v": 1 },
	"1P8dunLAxKiesAsmXube95pBYPEBSrgu4c": { "n": "TZBTCPOOL", "l": "http://tzlhbtc.ccc889.com/", "v": 1 },
	"1KVpfeiBFb3Mvnfdscot8peRYerr6RP55A": { "n": "BTC Pile", "l": "http://btcpile.com", "v": 1 },
	"1benikGLrwFYQUJjG2UaDTZhdNKFcS29M": { "n": "benik", "l": "https://www.websitebeheerjd.nl/bitcoin.html", "v": 1 },
	"1CdBn4DtvtwvJrb5LaSQJu6LhARDR81JhP": { "n": "BTC Pile", "l": "http://btcpile.com", "v": 1 },
	"1WBJDfb5nBX6AFnbZnVEnNv7p4xxkKRLA": { "n": "Websitebeheer JD", "l": "https://www.websitebeheerjd.nl", "v": 1 },
	"1Fj3iqvDoFc74QyKpReW5m2eKdP2iauiNd": { "n": "Laminated Paper Wallets", "l": "http://cryptofrog.blogspot.com/2014/05/laminated-paper-wallets.html", "v": 1 },
	"1Biro2i9M2dcshmxhPRmUtyKredWpE4dAf": { "n": "good20140504", "l": "https://sites.google.com/site/dirwilli2012/home", "v": 1 },
	"1F6YCUVFER1YPixY9pun56npJb9fTrXsGQ": { "n": "Supas Loans Repayment", "l": "http://supaforgothis.pw/SupasLoansRepaymentAddress.html", "v": 1 },
	"1GUNCfM6yVgBgg1BdZwcKDyF8R9utnqfB6": { "n": "Guncoin IPO Escrow by Dabs", "l": "http://www.guncoin.info/guncoin-ipco-btc", "v": 1 },
	"1Bzrnw6NRjbuMuFLMm3AerMS7f86QxbSyZ": { "n": "Stolen Bitcoin registry", "l": "http://www.stolenbitcoinregistry.com/stolencoin/1bzrnw6nrjbumuflmm3aerms7f86qxbsyz/", "v": 0 },
	"15eKKHMaRb7oc1AtMk6eBiHvgwCdLU2UXR": { "n": "BitcoinBakersfield", "l": "http://bitcoinbakersfield.com/", "v": 1 },
	"1F6h9TSXLgge5MsKz72WXXgqxhPF7o9wwt": { "n": "BitCoinCollector", "l": "http://bitcoinbloggerlinks.blogspot.com/", "v": 1 },
	"16DtLiRzkJ24DRaf3KHRf6PQyFJeqyC3gY": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"19yTtY45Xku65UZZihRF61C32HtY7PDcUA": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1G12wjFYGpeCFj1Uep2bkzzpwG7dCT1B9L": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1Ms44T9PWUsSfrBibN9jLJqcJUbfpM689p": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1CyYaitjDnf579n7w7UMtEBWhMHnygtYAa": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1JKLVnhhqdfXpDCChzttxgi1jHA7az3iXZ": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"14VhXCjNiW1tfXkuZBDK7fGhzsQn7VAbbu": { "n": "blurE.com", "l": "http://blure.com/login/", "v": 1 },
	"1Q3CDbzPVdsKEDXHZ2Z8ZuTzXy7c7EJG3X": { "n": "Bitcoin Spenden", "l": "http://vernunft.co/spenden/", "v": 1 },
	"1MarjoTmkR8N6ckfZbqQBULTbGpat3okjf": { "n": "Marjolein Kramer 3", "l": "http://webbtc.com/address/1MarjoTmkR8N6ckfZbqQBULTbGpat3okjf", "v": 1 },
	"1MarjoLhkrgA4DyzHHYMMW9aq5fryGnkxD": { "n": "Marjolein Kramer 2", "l": "http://webbtc.com/address/1MarjoLhkrgA4DyzHHYMMW9aq5fryGnkxD", "v": 1 },
	"1MarjoRii8aNr1xWRSnyEaG37zFMZuVdxe": { "n": "Marjolein Kramer 1", "l": "http://webbtc.com/address/1MarjoRii8aNr1xWRSnyEaG37zFMZuVdxe", "v": 1 },
	"1KeFiQ7B1L1fjDbYBy919gUYHa7azoNe3t": { "n": "Kefi247", "l": "http://kevingrahl.de/bitcoin", "v": 1 },
	"1KpPekcPZKfeQBENqzRHt1q1U9kNknkZXR": { "n": "DJ Blue", "l": "http://www.djblue.de", "v": 1 },
	"1MQsesqUMTRkcbCABEwzddH3PaXy6QXroo": { "n": "DJ Blue", "l": "http://www.djblue.de", "v": 1 },
	"1DLL8jdjQKYKNUvAxFBPREFbmnqEuBCNWe": { "n": "DJ Blue", "l": "http://www.djblue.de/faqs/wie-bezahle-ich-meine-rechnung/", "v": 1 },
	"1AUQd8eyCR7KqoQKQAq6o7c4VmQyofqheb": { "n": "dziobsonNET", "l": "http://dziobson.net/donate/", "v": 1 },
	"18teLEkg9VsQCwHeF3vmNsbZ5eyczuzSCo": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"141wbWGsMeQzqejVRVyEpQdqEJWUNVL24x": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1K1wgou7FHp8w6DfjR7zRyBQsgDDKpVGUW": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1ArQWpfuRbEKZaXSZhNgdbhcEt3mmEscqa": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"19f97gYbLed6X4GUYwFttToEFZ9Rq9xKXf": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1M6WomNYaDCbbTGfh1wQyJ5esd9YbeF6CW": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1D7et4TQiyaypP9hASpESj6BMZZtc9KMcN": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"19hsHAsjNdjk9mUaE2rP4Ru9taPs4LRYBR": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"13MrswNgoZ2hJzudWssJhWknU29t1Wt8kR": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"138oJEnZ392QwRQgVcTmSDEsgq6sNxdh6k": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1FcXUcmk6qtKvcXYu3Bj26h64HG1wYM8iD": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1CBoNdHoifShEuyMuV2ZLz3kmrobJhqg18": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1FLSvSShiYHS8wypz1qGXkyHX4kVtmtsnf": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"18PepZwPDBEs7hgYFSXbukjyY9F8wa5Qq1": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1693HN1oMHt71eA9xqbMYNVdBD4xbLLJDa": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"16ayrwkKnxr547fswjZdhadCpJvApRQNcu": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1GtZQjG9XZNkrRLCCDYxy2kcHStRoaAUKQ": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1E5W9GTM42kunVNTzA5CZgRvBDg7eihSjw": { "n": "UpDown.BT", "l": "https://updown.bt/", "v": 1 },
	"1JohanYetfqRdsdEdp9MCe1AGWHUrne2i8": { "n": "Johan Fiti\xc3\xa9 5", "l": "http://webbtc.com/address/1JohanYetfqRdsdEdp9MCe1AGWHUrne2i8", "v": 1 },
	"1Johanui5pEXKyHpYtYRjLtmi9APYyQuFz": { "n": "Johan Fiti\xc3\xa9 4", "l": "http://webbtc.com/address/1Johanui5pEXKyHpYtYRjLtmi9APYyQuFz", "v": 1 },
	"1Johan24Nq5HFv1k9uiFuhrG9baUvsputP": { "n": "Johan Fiti\xc3\xa9 3", "l": "http://webbtc.com/address/1Johan24Nq5HFv1k9uiFuhrG9baUvsputP", "v": 1 },
	"1Johanso4QLHimRE9JkfqV8y9F1qr1Fwe9": { "n": "Johan Fiti\xc3\xa9 2", "l": "http://webbtc.com/address/1Johanso4QLHimRE9JkfqV8y9F1qr1Fwe9", "v": 1 },
	"1JohanuSdZXVGZ7JPtugk9AtszcRpEwfga": { "n": "Johan Fiti\xc3\xa9 1", "l": "http://webbtc.com/address/1JohanuSdZXVGZ7JPtugk9AtszcRpEwfga", "v": 1 },
	"1Mines4MuVpJtw1j4SF4sPwyHPxN37atKq": { "n": "The Bit Mines", "l": "https://thebitmines.com/", "v": 1 },
	"1Do3Po7hKmv9dAWpaG9ALHNkz2Mci6oQ12": { "n": "LordCoder", "l": "http://thecryptocurrencyworld.blogspot.com/", "v": 1 },
	"1HPyNdyTxjNL8DXUezbsojQQUMN72sANG7": { "n": "yabtcl 16 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1Cpqtg5xvvX2MQsF1xRdsR1NGHW4tZhu5K": { "n": "yabtcl 15 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"12LQ8SYxvhLyycTWrRzJLaz3ynXTHHEF6w": { "n": "yabtcl 14 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1Bhc5eizPt41bzJhrqh16BT2kJc63J67Kp": { "n": "yabtcl 13 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1JRsp4r4YSBT6jpHzTwGdAzzs9p27jTrnb": { "n": "yabtcl 12 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1CytPDfxydx356YvQk5JW1zBbCt2ThrK1": { "n": "yabtcl 11 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1KMAWshsM1rh2ryPvAav8BtZjGj9i2HPp6": { "n": "yabtcl 10 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1Gp27P5aXzuezGPmdeqhJpaufRJAWrEWLY": { "n": "yabtcl 9 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1FAVeXkMGkWrqaLbbY2wTTryegWGDeQkX2": { "n": "yabtcl 8 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1N1eDvqQSQZD45x2UXx2FhrCSz9j8mYe7m": { "n": "yabtcl 7 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1QHw2pnQeoHy5ApyvgPAiF9bJjs5Y3np5x": { "n": "yabtcl 6 Numbers Tickets", "l": "https://yabtcl.com", "v": 1 },
	"1PSXsRq4gXWKsxWSbmvmjCWsmD49MdNgJN": { "n": "DaveSpace", "l": "http://www.davespace.co.uk/", "v": 1 },
	"1BKHighG9fbiH11bm2pXa2qhxzE7iedjze": { "n": "Bitcoin King Dice High", "l": "http://www.bitcoinking.net/dice", "v": 1 },
	"1BKLow18Tp66aH9Spz9XRUJ5osKohAHHNC": { "n": "Bitcoin King Dice Low", "l": "http://www.bitcoinking.net/dice", "v": 1 },
	"1BKing8qCEL224nBx2knMcrGczsxcSGoQk": { "n": "Bitcoin King Faucet", "l": "http://www.bitcoinking.net", "v": 1 },
	"1WoodQ7Rcg2CoDRpUYyNUYcMBiJr2dBRW": { "n": "Woodwallets", "l": "http://woodwallets.io/", "v": 1 },
	"14UfRMUjZTdH6xBssqLTB8XUJiuCtRLtka": { "n": "Give-Me-Bitcoins", "l": "https://www.louis.ms/Give-Me-Bitcoins/", "v": 1 },
	"1687v9NexfUC6U6G1xBrEkLWYi3WSDn4qL": { "n": "BTC Stolen From BTCJam", "l": "http://www.cryptocoinsnews.com/uncategorized/btc-stolen-btcjam-ongoing-heist/2014/04/08", "v": 1 },
	"1m1wvvxFAbTKgxcfyvQpbF9tWMGSVEt6t": { "n": "Digital Poland", "l": "http://www.digitalpoland.pl", "v": 1 },
	"1LZdWvi66XvTMaCG52pF8DY5xYuMhbgTw9": { "n": "SatoshiRoulette Coinflip Tails", "l": "http://satoshiroulette.com/coinflip.php", "v": 1 },
	"137n1qDtoTSHcoEtNqqh7goEUTajjyUx3D": { "n": "SatoshiRoulette Coinflip Heads", "l": "http://satoshiroulette.com/coinflip.php", "v": 1 },
	"1K8aQ9s5ZDHxMSyH2HEn4Dy2baPAvwiq9M": { "n": "PIWO dla ZYCHA", "l": "http://dziobson.net/zbiorka/", "v": 1 },
	"1HeadgunwEjYJ9dmw9DNZVGbDVQC2iz2wj": { "n": "Headgun", "l": "http://www.headgun.com", "v": 1 },
	"1MogdA1cphcRPMo3N475wf4vnETuoQQDm5": { "n": "Bitcoin For Children", "l": "http://www.bitcoinforchildren.com/faq.html", "v": 1 },
	"1F6gQmGFiNaF3h4aVY2mwRKQ2EXbsd9K9c": { "n": "Bitcoin For Children", "l": "http://www.bitcoinforchildren.com/make-a-difference.html", "v": 1 },
	"1RCXrcxDCUaqhfdsJMdmqRaTCnHbFpWA6": { "n": "www.r.cx Realtime Coin Xchange", "l": "http://www.r.cx/", "v": 1 },
	"1PrwvN1JSsdtQSi1fsaBRnS8mHSPg1vHGB": { "n": "pizza", "l": "http://visualproduct.com/wallet.html", "v": 1 },
	"1FDEjjKN4qFyDFyYVqNaUbavE7Rti4chYs": { "n": "bitcoin", "l": "http://visualproduct.com/wallet.html", "v": 1 },
	"1QAybGKeUcJedvBHBgrLzMCcmYYNG83eTe": { "n": "wallet", "l": "http://visualproduct.com/wallet.html", "v": 1 },
	"1Dozen1f2GtjnHfp7JXhFdAVeibkpqdhV1": { "n": "Bitcoin-Roulette.com [1st 12]", "l": "http://Bitcoin-Roulette.com", "v": 1 },
	"1oddbMCaZcGkQmwq5MhSi4Q4K5TuyL9Jk": { "n": "Bitcoin Roulette ? Odd", "l": "http://Bitcoin-Roulette.com", "v": 1 },
	"1EvenqSnC1aTEWFsFxPh1CsnJyfZF9Wn56": { "n": "Bitcoin Roulette ? Even", "l": "http://Bitcoin-Roulette.com", "v": 1 },
	"1BLack82MjEp3A3PDYisnRoDExm2yx81ZD": { "n": "Bitcoin Roulette ? Black", "l": "http://Bitcoin-Roulette.com", "v": 1 },
	"1RedzZR6wRwczYjhv2s6PCn6Qq2gEroJt": { "n": "Bitcoin Roulette ? Red", "l": "http://Bitcoin-Roulette.com", "v": 1 },
	"1CoinWFG8uAG3qEa5zLjHM8ugua63jGGUR": { "n": "coin.wf", "l": "https://coin.wf", "v": 1 },
	"1JABL93BGgCrjtVn1NsuR2f1K3SEvXq294": { "n": "Mudslide Relief Darrington, WA", "l": "http://www.reddit.com/r/Bitcoin/comments/21pp2n/thank_you_rbitcoin_from_the_mayor_of_darrington/", "v": 1 },
	"18E26eWGgSHUoKY83oiisfjea2CgeCLUW4": { "n": "freebitcoinnow.com", "l": "http://freebitcoinnow.com/", "v": 1 },
	"1Bet1vD2P2eCEnKwGqDi5Q4UFwTfeg9mTR": { "n": "BetCoin Dice 0.001 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet2yV8rPt7kE14AAbhYnxqw53uhCQd7T": { "n": "BetCoin Dice 0.003 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet4FNnZsv1N3XCbW6wTTyVAS9RVUePpq": { "n": "BetCoin Dice 0.006 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet8sJN9rmeaZRBwnjPbCLV77TWY3PR3X": { "n": "BetCoin Dice 0.01 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet16b1xrSmqfyZA8rxbdR2iBXUtn3ai9": { "n": "BetCoin Dice 0.02 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet32qgNHQGtxPCFMzn8kvuuaPiTB14AL": { "n": "BetCoin Dice 0.05 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet64eDxYufs2Y9rnB6ugx2EYCPyLEFkF": { "n": "BetCoin Dice 0.1 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet128rfauserH5qyUKzgkJNoa5DvMNQf": { "n": "BetCoin Dice 0.2 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet256HNReW1QqC3LTWgYMmpaVGFsZPTZ": { "n": "BetCoin Dice 0.4 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet512sXJgHtugNSDWDK4YtzqxCkHnXuL": { "n": "BetCoin Dice 0.7 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet1kBfaSrEdmrpXEDqhxYhrUpyZCK35g": { "n": "BetCoin Dice 1 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet15Zqh923xeoTBctVo7MPR6bLHP2MA3": { "n": "BetCoin Dice 2 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet2kA75VWi9goKoM58BcHfeLydewp2hU": { "n": "BetCoin Dice 3 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet3kPEgUDDzxL67rS8NtUrmFPW1GNcEQ": { "n": "BetCoin Dice 4 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet4kUEfCdJeAM7KJJfJTYa2a3Ydm8aAv": { "n": "BetCoin Dice 6 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet6kDFAjYzJN4tFUmVHhXcWxFRg8bNKb": { "n": "BetCoin Dice 9 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet8kSeHDWHByQzGVoWW2ZwDVkgtWYJxZ": { "n": "BetCoin Dice 12 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet12kCPomyc35y5Lt99ZNnAr2pC66dqw": { "n": "BetCoin Dice 18 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet16kGTPwHKEbvNK4uQKtYC61Q4MHBst": { "n": "BetCoin Dice 24 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet24kC9BqJeCbc27hkahoAsSVHLaYfLr": { "n": "BetCoin Dice 36 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet32kBtZzXViMs1PQHninHs4LADhCwtB": { "n": "BetCoin Dice 48 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet5o5o23jaRB9kKNxqZ5KeBqoSm5Fh56": { "n": "BetCoin Dice 50 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet48k9LzVSdJTWjabFbTr4x8foPzgDRw": { "n": "BetCoin Dice 73 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet52kCyiritFn6rvmZKRrUSSpnY7HNWo": { "n": "BetCoin Dice 79 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet56kWEpCq8ugG9tqAkLNXqaAQ4eUALp": { "n": "BetCoin Dice 85 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet6okTDPYGHZ9ukKf2FFSc5EjRoFipTD": { "n": "BetCoin Dice 91 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1Bet64kV7WuCNrmytagBEoixE8Kd5vMmnP": { "n": "BetCoin Dice 97 percent", "l": "https://www.betcoin.tm/dice/", "v": 1 },
	"1CDFtAS92A4AwaCe6nNpwUugxJWw571xp7": { "n": "Cobalt Dog Books", "l": "https://www.cobaltdogbooks.com/about.html", "v": 1 },
	"1CHJArco4Qv6cmTZNF7Km7cuATCD1Z1NSu": { "n": "WeeklyPonzi", "l": "http://weeklyponzi.com/", "v": 1 },
	"1BTCAMzFnFybv7q7ySTdqiweEJizTQg1Y": { "n": "Bitcoin Indonesia", "l": "http://www.bitcoin-indonesia.biz/", "v": 1 },
	"1BTCEGKcQXHrnW6BFnaYDshDLKAkzdGbPM": { "n": "bitcoin-indonesia.biz", "l": "http://www.bitcoin-indonesia.biz/", "v": 1 },
	"1BTC11ifbnvoWY8RJ28nDhZ1SDtj8ooE6a": { "n": "Bitcoin Indonesia", "l": "http://www.bitcoin-indonesia.biz/", "v": 1 },
	"1KeBs4HBQzkdHC2ou3gpyGHqcL7aKzwTve": { "n": "The Pirate Bay", "l": "https://thepiratebay.se/", "v": 1 },
	"1MinesNgpYeEbb5GLaAHVXT3fXCTAuAYAa": { "n": "The Bit Mines", "l": "https://thebitmines.com/", "v": 1 },
	"14eGodNbabrYr5mDVhWhPRttY1PK6fPy1g": { "n": "Bitcoin Symbol", "l": "http://bitcoinsymbol.org/", "v": 1 },
	"141Navrk5uYMbAvYfcfmNn7cwyECgfkWsQ": { "n": "Fr33aid.com Stolen Bitcoins", "l": "http://www.fr33aid.com/1511/fr33-aid-bitcoins-stolen/", "v": 1 },
	"15eUgApBpCDbbqKHtYJz8vrpqCpkoCKoDU": { "n": "zhaojunjie.com", "l": "http://zhaojunjie.com/", "v": 1 },
	"1F9mUgxFN4JPCmqmJBj7o8tbWmzb4ck5CY": { "n": "Win Free Bitcoins !", "l": "http://freebitcoinwin.com/", "v": 1 },
	"1JYu7qSDh3yzGNeP6p2TVn2nmKh1RWcc8k": { "n": "Elvida Automatisering", "l": "http://www.elvida.nl", "v": 1 },
	"163Ky9GqH13EoCET5T7N9L5FBAQJm9aocj": { "n": "ThisIsActuallyGoodNews.com", "l": "http://ThisIsActuallyGoodNews.com", "v": 1 },
	"132CV8He1FyaWuzpCvYEMwgBRi3TEe2PDK": { "n": "Topcoin", "l": "http://www.topcoin.cn/about.html", "v": 1 },
	"1PXaQagfXHGBL7nP3uQt95uk1KtEo5yFBL": { "n": "Vladimir Putin", "l": "http://bitcoin-list.5cz.de", "v": 1 },
	"19TcuuudaoRKFPGErJY1ZFsVXYcWtzDQJm": { "n": "KCSWUG", "l": "https://sites.google.com/site/kcswug/home/donations", "v": 1 },
	"1NxaBCFQwejSZbQfWcYNwgqML5wWoE3rK4": { "n": "LuckyBit hot wallet", "l": "http://luckyb.it", "v": 1 },
	"12sENwECeRSmTeDwyLNqwh47JistZqFmW8": { "n": "Bitstamp Audit", "l": "http://www.reddit.com/r/Bitcoin/comments/201r5m/statement_from_bitstamp_regarding_the_huge/cfz0kqx", "v": 1 },
	"1McNsCTN26zkBSHs9fsgUHHy8u5S1PY5q3": { "n": "Jimmy Wales", "l": "http://www.reddit.com/r/Bitcoin/comments/200bx9/jimmy_wales_is_playing_with_bitcoin/", "v": 1 },
	"1Q4G4ZJ1AN1aHkC9YnPQGWYEAxJrW62rJL": { "n": "Wikileaks", "l": "http://wikileaks-donation.weebly.com/", "v": 1 },
	"1Dorian4RoXcnBv9hnQ4Y2C1an6NJ4UrjX": { "n": "Dorian Nakamoto fundraiser", "l": "http://www.reddit.com/r/Bitcoin/comments/1ztjmg/andreas_im_fundraising_for_dorian_nakamoto/", "v": 1 },
	"1DzBEBqzrNsRg8oeRbGWNUr4V2VSjdS7iQ": { "n": "Wheelchair Fund", "l": "http://www.reddit.com/user/IamAlso_u_grahvity/submitted", "v": 1 },
	"1436j9Kw2veuQbY1FzPd4VFGZzejLEBjhb": { "n": "FileZilla Donations", "l": "https://filezilla-project.org/", "v": 1 },
	"1E28hm3RP3FYtigc1FHYRxR1LSvvayFQV1": { "n": "Metro Ponzi", "l": "http://metroponzi.co.vu", "v": 1 },
	"1HeLPH7N9BrfhCDNEdgRs3Wfypbkh39DVf": { "n": "help, donate", "l": "http://savedylan.yolasite.com/", "v": 1 },
	"1CJQxMQzLdmQ9RBvwGBwSvYyjGpTiiKEVA": { "n": "Cryptobounty Bet", "l": "http://cryptobounty.com", "v": 1 },
	"1NDkevapt4SWYFEmquCDBSf7DLMTNVggdu": { "n": "Flexcoin stolen coins", "l": "http://yro.slashdot.org/story/14/03/04/1547232/bitcoin-exchange-flexcoin-wiped-out-by-theft", "v": 1 },
	"1QFcC5JitGwpFKqRDd9QNH3eGN56dCNgy6": { "n": "Flexcoin stolen coins", "l": "http://yro.slashdot.org/story/14/03/04/1547232/bitcoin-exchange-flexcoin-wiped-out-by-theft", "v": 1 },
	"1Coffee9ev4XQ5krwdGtkdUzvzXN3EpFna": { "n": "Dr Coffees Minecraft", "l": "http://www.reddit.com/r/drcoffee", "v": 1 },
	"1AMaPhM2crKkMfgFMr13vstjrTbzAKGatG": { "n": "freebitcoinwin.com", "l": "http://freebitcoinwin.com/", "v": 1 },
	"1EGZLwe7k1sDdRzoSJjL9jdsL9uYCxVS2b": { "n": "420WeedLikeToTalk", "l": "http://www.indiegogo.com/projects/weed-like-to-talk", "v": 1 },
	"1EALSdzpevPQ6A3LTpUTNrRKHo3Z4dT6nC": { "n": "ealfskillz", "l": "http://bitcointurk.blogspot.com.tr/", "v": 1 },
	"14qySmcZWWH2Pf2y1sSGXvBWfrqjUCFsub": { "n": "Compare Australian Bitcoins", "l": "http://comparebitcoins.net/index.php", "v": 1 },
	"1A5Zhxc3yNJScNAGv8Pn3mZ7KqdaJnKZLU": { "n": "Payment", "l": "https://ltc-24.com", "v": 1 },
	"1DirGRxWx4hzLaRwcN5TWNXhCWqepHcxQJ": { "n": "divvy up your bitcoins", "l": "http://divvy.info/", "v": 1 },
	"1A6mg8xpwFu2L6poVbqzqHyqPeYDaVG815": { "n": "JonathanCasey", "l": "http://www.reddit.com/r/Bitcoin/comments/1z14j0/needed_any_bitcoin_addresses_you_have_used_to/", "v": 1 },
	"1ExBxpGoAvu2asLTyWB84yzvJNK9WQWi6p": { "n": "coinforcash", "l": "http://coinforcash.com", "v": 1 },
	"1LAqvijBjpdKiXvVEvGnesFvhUHx8yQHfh": { "n": "coinforcash", "l": "http://coinforcash.com", "v": 1 },
	"1NMpciRW9zMHjdizTZ5i8zC3uVtCGPaAku": { "n": "freebitcoinwin.com", "l": "http://freebitcoinwin.com/", "v": 1 },
	"1BbKNjvuN3xNpQVBAc4dWmmRFssp3V7cPa": { "n": "Win bitcoins", "l": "http://freebitcoinnow.com", "v": 1 },
	"19xUQVwyc5DDo1uoN8dXA8tCEfXCrkRyir": { "n": "gotofail.com", "l": "https://gotofail.com/", "v": 1 },
	"1DrvGJtYPQrp6up3am9H7JweqYXUQMD3qF": { "n": "Satoshi Nakamoto", "l": "http://nakomoto.com/", "v": 1 },
	"1DYRPDFmieHPPvXYbpGfW4yEwHXoMH2WFa": { "n": "Satoshi Nakamoto", "l": "http://satoshinakomoto.com", "v": 1 },
	"1EWZmycFnkdnx7hpvQo14fnEFPkxJhpFrG": { "n": "NightSpace - Photo, Moda", "l": "http://nightspace.ru", "v": 1 },
	"16zwcNmgSgoeo2CvXP5D8PT4iTQTLzn2y5": { "n": "blitzwahl", "l": "http://blitzwahl.de/donation.html", "v": 1 },
	"1G3FDxiuZGcqLT2h6ozVN9QFjLBiegGtsQ": { "n": "Tickstory Financial Tick Data", "l": "http://www.tickstory.com", "v": 1 },
	"13x9weHkPTFL2TogQJz7LbpEsvpQJ1dxfa": { "n": "Reddit Bitcoin Faucet", "l": "http://www.reddit.com/r/Bitcoin/comments/zqocl/exchange_your_karma_for_bitcoin_reddit_bitcoin", "v": 1 },
	"1BitChVRvn3ER7ezZRyeqtnxHwHwgWKj7K": { "n": "BitChest.me", "l": "http://www.bitchest.me", "v": 1 },
	"1AhcdF4jvwTRaHWRms2jXwqFV4L2RfU26v": { "n": "Want a Ferrari rly bad pls hlp", "l": "http://wantferrari.do.am", "v": 1 },
	"1HHSzBXXS9YvpV7gtcM9M3YubPBiodpR8U": { "n": "1234565", "l": "http://bitcoin.minerpool.de:9332/static/index.html", "v": 1 },
	"1MoneySKsyZewy9c7wPyWdX7j6Lxgfazdc": { "n": "Bitcoin Investments 120percent", "l": "http://ponzi.pw", "v": 1 },
	"16qrHYPCrtgqJzeWjAMEiKTiZzfHzKWpEe": { "n": "NEED PAY BILLS! HELP!!!!", "l": "http://kaylu.cl/donate2.htm", "v": 1 },
	"1PgFJQZAmbuV1T4253odkmsd89YMhAvcsg": { "n": "NEED PAY BILLS! HELP!!!!", "l": "http://kaylu.cl/donate.htm", "v": 1 },
	"1C13FaZ7W8CorMEV3ffTsjqHTtSGA3JaND": { "n": "istole.it", "l": "http://istole.it", "v": 1 },
	"1CgNbwiQKA348dchXeeyqUXBVoYBLAVPGd": { "n": "Cloud-Dice.com", "l": "http://btc.cloud-dice.com/", "v": 1 },
	"1HSvi2rhGrQSvH6rHjDC9xhzKvuW3iBDti": { "n": "SaltRockMine", "l": "http://farrst.blogspot.com", "v": 1 },
	"1H2CtRxngKMrRKBFHgPGBDiDt2G3cgYgCA": { "n": "A L F Wallet", "l": "http://www.alphafilm.at/bitcoinbaby.html", "v": 1 },
	"13YJecQJCM2zaj9FAHx3ZY5j66TqMMiGi1": { "n": "insdice.us", "l": "http://insdice.us/", "v": 1 },
	"1HZ7QS8Tfi7jC9Dy3gmr3d48ZwcxJjH263": { "n": "AGENDA", "l": "http://adne.ga/", "v": 1 },
	"17Fnmua2H2ct91b4QzogCsjv4tj48tjKXP": { "n": "e-al.narod.ru", "l": "http://e-al.narod.ru/", "v": 1 },
	"1K8MktQjetgSSsNLiYAfz4zJvec2Pudh61": { "n": "batterysaver", "l": "http://youngbullindustries.wordpress.com/about-battery-lifesaver/", "v": 1 },
	"1ponziUjuCVdB167ZmTWH48AURW1vE64q": { "n": "Ponzi.io", "l": "http://ponzi.io", "v": 1 },
	"12wzewNuJ2ERQrvYkAL7GoBydof9Eh4Usw": { "n": "Bernd lutscht gerne Schwenze", "l": "http://krautchan.net/b/thread-7142874.html", "v": 1 },
	"19CQfYYpwnGZiDBgqzfgPYQ119wAJMectK": { "n": "OP ist eine Schuchtel", "l": "http://krautchan.net/b/thread-7142874.html", "v": 1 },
	"13L4kpoYzfzkEHmN7rmJPQyruNyTzzoH7Q": { "n": "preev.com", "l": "http://preev.com/donate", "v": 1 },
	"14YhQXrtjSnkJUTdnqkqDLuWaYE43z5ZYt": { "n": "Bitcoin Euro Exchange", "l": "http://www.btceur.eu/", "v": 1 },
	"1Johan1CWrWVnEQDRFUp5kQrgJgz545Cup": { "n": "Johan Fiti\xc3\xa9", "l": "http://webbtc.com/address/1Johan1CWrWVnEQDRFUp5kQrgJgz545Cup", "v": 1 },
	"1Marjo1uMEypdmX3CBm8q84P8xFQgrk2oM": { "n": "Marjolein Kramer", "l": "http://webbtc.com/address/1Marjo1uMEypdmX3CBm8q84P8xFQgrk2oM", "v": 1 },
	"1JXz6c3z3zyKuZVJrA4yD5ZLx3f6pYc93p": { "n": "FinMutual.com Program", "l": "https://finmutual.com", "v": 1 },
	"1USAG1n4CYGZSXTKuF1D4CtfpL8xBbfPX": { "n": "World Cup - USA to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1URUqhe4NkenftknabQ2ZcMiQVDT7SEMD": { "n": "World Cup - Uruguay to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1SUiepYqG93CFVv7Kitfti6AdDKNdRgt9": { "n": "World Cup - Switzerland to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1RUS4BxnSFJBcdJ3mbmAVM97w3JKxWkRu": { "n": "World Cup - Russia to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1PoR9pg64FfFhmKunD2sPWe5sN47ZQQzjm": { "n": "World Cup - Portugal to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1NGAfXj8hinx97Tfik4dtKmUgUFW59hX9Q": { "n": "World Cup - Nigeria to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1NEDPvcWPxpMZshEnRfU1889hHYSjD4uKu": { "n": "World Cup - Netherlands to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1MEX3QMBrr4QUFqX1PPM49Q75w9qtLxaz5": { "n": "World Cup - Mexico to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1KoR5CYSgRF3uTVSbmumuNE8W45DmsKMei": { "n": "World Cup - South Korea to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1JPNCuxet7F7DAEghu4T4PKG5F25MPSjJP": { "n": "World Cup - Japan to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1iRNZyt4h65JELp6Td1CqU5AFk9WWXfJc": { "n": "World Cup - Iran to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1iTAMkMfF4EhWSMNsK9BppWSeANizRuBy": { "n": "World Cup - Italy to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1HoN61H8cBATiBMtu2ueLkegdWb51BYerh": { "n": "World Cup - Honduras to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1GRECiyLSz5Q6VThWX7hLqaTZpQU4UqYie": { "n": "World Cup - Greece to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1GHAZnThKeCE97raTSY6ckvm9ANSLayGRq": { "n": "World Cup - Ghana to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1GERSLqHqpGBGpSFf1UTcH7LfVxWxA4mgC": { "n": "World Cup - Germany to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1FRAPnpyuJQfLWnbWuNXxQiHFA2stECUiY": { "n": "World Cup - France to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1ESPUqZwdm7Z7RWuPp7DC7KRsWhjnd5wH2": { "n": "World Cup - Spain to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1ENGwuYPtreNVGagMue8KSji9Bmee8FLMJ": { "n": "World Cup - England to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1ECUdqnG7TZvZ5ayrGA2Cx8C2RzhaZWXts": { "n": "World Cup - Ecuador to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1CRo3WDJUHc4XK1SjsLYnRF6chjMjqhHpk": { "n": "World Cup - Croatia to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1CRCBP6T4h3WHqGJZK9Pisv5dQoYHLyh58": { "n": "World Cup - Costa Rica to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1CoLjFTTW13eSVzzwUkS1jaDnxGdFk9Nt7": { "n": "World Cup - Colombia to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1CMRxWjQToq59FufGsQrQopZymNANYjEfS": { "n": "World Cup - Cameroon to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1CiVa1fHXErTpM3oMFcfuzgGBBxFoBaDqn": { "n": "World Cup - Ivory coast to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1CHiFyib2V9N7CTdrkCNJ8FDzjNMFreiTR": { "n": "World Cup - Chile to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1BiHUyX88WSMzeTKrdi8JcwFL6m8PSmCHR": { "n": "World Cup - Bosnia &amp; H. to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1BELp57gJkTZn1VEPzVpdyZETz3fpNE6rS": { "n": "World Cup - Belgium to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1AUSo2ds5cLhNLBRMSnbh8ERs9Hvng24L6": { "n": "World Cup - Australia to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1ARGgU1qCUqT5qZuEfzGhXjQnDN5mmeDRU": { "n": "World Cup - Argentina to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1ALGmL2MadxGEoA5pyi3t5mD8nmqE3xFWo": { "n": "World Cup - Algeria to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1BRAKAcbJLUvF52RnojSZyaEH9zDoB9mxG": { "n": "World Cup - Brazil to win", "l": "http://www.wcbtcpool.com", "v": 1 },
	"1EYkyNjVETVzvGxy5ZE54Kwjgx6WvG5H3Y": { "n": "BitcoinChef", "l": "http://www.bitcoinchef.info", "v": 1 },
	"1QLEHKdwYNJPsSZAzMjfkn8TKQWNez9a8n": { "n": "Bitcoin-Play.com - (1-61440)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1LJ4y5eA273wiwBox9mPisSrvhvmnwRQyG": { "n": "Bitcoin-Play.com - (1-57344)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1HLw1jQBBGMWrQ3sBbamPLMtQ7WFDo8t8p": { "n": "Bitcoin-Play.com - (1-49152)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1G7Z9fS4FDQmh3j7k1RcG3WcuhLZ3zDKxQ": { "n": "Bitcoin-Play.com - (1-40960)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1Np1sBcYivcGDSbB2QPFJmaHRBYNZpNzPp": { "n": "Bitcoin-Play.com - (1-32768)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1BYz5FNddQ9DGL3GMVgVqTys4vzEku7ie6": { "n": "Bitcoin-Play.com - (1-16384)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1CLmbq2qYmR3NxzD8GnJUJ38RMto6XtHCC": { "n": "Bitcoin-Play.com - (1-8192)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1EDJdJv4SoLerd1pBg399GKdoEFZvJfYDR": { "n": "Bitcoin-Play.com - (1-8192)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1KosxX8ycJnzfbYJAPFmABLvQvCHy7WUpk": { "n": "Bitcoin-Play.com - (1-4096)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1JE33TvyuYNa4dDwb7oTna4fw1FBhuqSfF": { "n": "Bitcoin-Play.com - (1-1024)", "l": "http://bitcoin-play.com/", "v": 1 },
	"15maszit1h2ck9ed9rWPE2VGiKpd5MBsGZ": { "n": "Bitcoin-Play.com - (1-64)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1JFitie9AFZXswuWSccpvnkuBwzTfGvqq": { "n": "Johan Fiti\xc3\xa9", "l": "http://webbtc.com/address/1JFitie9AFZXswuWSccpvnkuBwzTfGvqq", "v": 1 },
	"1Mv5uY3kZ7dPuw4VVtP4QiPhU9mQPMc6qY": { "n": "Block Chain Lottery 3 Change", "l": "http://www.blockchainlottery.com/", "v": 1 },
	"1KyVEHDjx3xc2c5U8WnHrMuBt7yH9a8wsk": { "n": "Block Chain Lottery 2 Change", "l": "http://www.blockchainlottery.com/", "v": 1 },
	"1CheRu4Zk9MDSQqnGftopsFTmDfxDB6gQb": { "n": "Block Chain Lottery 1 Change", "l": "http://www.blockchainlottery.com/", "v": 1 },
	"1JHAECJBamL5RcAhUGzce1b6X2ZaMyizg8": { "n": "Bitcoin Casino Pro", "l": "http://www.bitcoincasinopro.com/reviews/", "v": 1 },
	"1EVL5GxAi7dxfeBw31KHCiopFKmzJF6PBh": { "n": "blocks.wizb.it", "l": "http://blocks.wizb.it", "v": 1 },
	"1andreas3batLhQa2FawWjeyjCqyBzypd": { "n": "Andreas M. Antonopoulos", "l": "http://antonopoulos.com/", "v": 1 },
	"1NBrKsmBzHq69KDeiToFNVGzWJ32KXd32j": { "n": "TopPTC Sites", "l": "http://topptc-sites.tk/bitcoin.html", "v": 1 },
	"1GRAPe77YxmX9VwsmvpfbRsvNJefTRvLMW": { "n": "GrapeApe", "l": "http://bitcointaxi.co", "v": 1 },
	"1Ci74SvzuLTrRhfcaXosvbbDcLsRdqxm7E": { "n": "Block Chain Lottery Change", "l": "http://www.blockchainlottery.com/", "v": 1 },
	"1AV8ZCbgY4zxdMLndke8GSkWCEX1QE1DdV": { "n": "BlockChainLottery Tips", "l": "http://www.blockchainlottery.com/", "v": 1 },
	"1P2pkANY6wvgZPEszNsR7XQpD7oKmzFCCN": { "n": "Diodesign", "l": "http://www.diodesign.co.uk/", "v": 1 },
	"1BCLxkE6t9HQysu81SNVkkhhbYTWetDrPi": { "n": "Block Chain Lottery", "l": "http://www.blockchainlottery.com/", "v": 1 },
	"1L32MPuyu4wxeRfoSaNPY575Myw6e2HZmv": { "n": "Bitcoins 4 CokeRewards", "l": "https://docs.google.com/forms/d/15GA1MGsjL3SuzGj8fraDHSsNmWdVpMf3GSiwWIi7mlA/viewform", "v": 1 },
	"1KLyCcy8L9Lvgf35C2BttAwbKgugGyxFd8": { "n": "Block Chain Lottery Other", "l": "http://www.blockchainlottery.com/", "v": 1 },
	"1BCL35QuR79tbPFCSeghEfG7mQoyeqepXc": { "n": "Block Chain Lottery 3", "l": "http://www.blockchainlottery.com/", "v": 1 },
	"1BCL2ccUwEF92JpyPp7WG4rC4VuGRBGCKr": { "n": "Block Chain Lottery 2", "l": "http://www.blockchainlottery.com/", "v": 1 },
	"17gH3YynN34VVRhwwrnEjfc31LnpP7rcTm": { "n": "BitcoinBrowserWallet Donations", "l": "https://chrome.google.com/webstore/detail/bitcoin-browser-wallet/liopgbfpkngindhbgplllgjhfpcfnmig", "v": 1 },
	"16gb4uGDAjaeRJwKVmKr2EXa8x2fmvT8EQ": { "n": "Wappalyzer", "l": "https://github.com/ElbertF/Wappalyzer", "v": 1 },
	"18Vm8AvDr9Bkvij6UfVR7MerCyrz3KS3h4": { "n": "Bitcoin QR Code.org", "l": "http://bitcoinqrcode.org/", "v": 1 },
	"1KFHE7w8BhaENAswwryaoccDb6qcT6DbYY": { "n": "Discus Fish (F2Pool)", "l": "https://www.f2pool.com", "v": 1 },
	"1LrxT3aFPUKpYHD7pxvGNiDq4s2JjRiyjf": { "n": "Payment From FreakFaucet", "l": "http://www.freakfaucet.com/faucet2.php", "v": 1 },
	"1rainZRw5iKzWtzxQzXoLPP6dotpPzeCN": { "n": "MakeItRainBitcoins", "l": "http://www.makeitrainbitcoins.com/", "v": 1 },
	"1HhbHxRe6pK7tJzLLDitzvjcHr5zWT7u7J": { "n": "Bitcoin-Play.com", "l": "http://bitcoin-play.com", "v": 1 },
	"15DGuJsTbb8CAUjr5pLcpcUT7F8gSFTUhL": { "n": "Win free BTC at GratisBitco.in", "l": "http://www.gratisbitco.in", "v": 1 },
	"1NXB6NVxGSdaeMWq2mmyxQTYLVLjz5ASun": { "n": "Blank Banshee", "l": "http://blankbanshee.bandcamp.com/album/blank-banshee-0", "v": 1 },
	"1DesLgpVAFPSiYnULwyB54ChgBZS5RCLys": { "n": "Nakacoin Foundraising", "l": "http://www.nakacoin.org", "v": 1 },
	"1RCX1m5K3Jk1d98NLL3RjdRLLVU4tGT9i": { "n": "www.r.cx Realtime Coin Xchange", "l": "http://www.r.cx/", "v": 1 },
	"189DJpmnCqYxr2oDijrVBqYEkVuo8FKvfv": { "n": "Help build my house", "l": "http://bitcoin-help.livejournal.com/", "v": 1 },
	"12yYt1Ydt9ycCDUnMBeQBmK2sUP5LZuPLs": { "n": "aggaming", "l": "http://ag288.net", "v": 1 },
	"19oj3C4cRoi2dB1NtvhRtzBKU1jsdKJUca": { "n": "Ngecrot.In", "l": "http://ngecrot.in/", "v": 1 },
	"1CKx5yc1s2z7N98uZczsDgixq37LL7bC1s": { "n": "IT Apprenticeship, Non-Profit", "l": "http://internship.integrityak.com", "v": 1 },
	"1JJDPREg59fJnrEd6VPEM6V5J83FKv6WtZ": { "n": "Impossibly Stupid", "l": "http://www.impossiblystupid.com/", "v": 1 },
	"171bQ5dkP1HKrQxMRTKtgTBTSjHNRLdkMt": { "n": "ZLOK tipjar", "l": "http://klout.com/ZLOK", "v": 1 },
	"1B9aqSLCEK6d3zzNP8sXGHZE2pUdW1ZvhF": { "n": "btcaddr.es", "l": "http://btcaddr.es", "v": 1 },
	"1e9ZWBTMz5fU6w3FnVNKHitqU44Prrcvv": { "n": "FreeBitcoinFaucet.com", "l": "http://freebitcoinfaucet.com", "v": 1 },
	"16y8e6Ngoi3KH5oByYfSXxTtPgxbW2JoHr": { "n": "OK38.com", "l": "https://www.ok38.com/", "v": 1 },
	"1GCW9MWTZAvkwvePQyG8qknVDXt1MD96YR": { "n": "Kali Linux Donation", "l": "http://images.offensive-security.com/download-stats.html", "v": 1 },
	"1NXmkcaYaShRRGukveQsSmjL92PVxZoUEn": { "n": "TopPTC Sites", "l": "http://topptc-sites.tk/bitcoin.html", "v": 1 },
	"1997Sf9GY4xYyKmNYc8UEhMm571dboHKTU": { "n": "Bead Art", "l": "http://www.bizhur.ru", "v": 1 },
	"1CounterpartyXXXXXXXXXXXXXXXUWLpVr": { "n": "XCP Proof-of-Burn", "l": "http://counterpartyd-build.readthedocs.org/en/latest/HowToBurn.html", "v": 1 },
	"1M9kzNAURtUijDX9yPGh5UAmcEHvWT79VJ": { "n": "Fiat Paper Wallet", "l": "http://cryptofrog.blogspot.com/2014/01/durable-fiat-paper-wallets.html", "v": 1 },
	"1PpVLFS4UbsSa3gHK81ocG8daBBm16EVPv": { "n": "papobitcoin.com", "l": "http://papobitcoin.com", "v": 1 },
	"DD6CPtiNWVAwtAofXxatDmWmrALLeXPnPy": { "n": "Doge.CC Donation Address", "l": "http://doge.cc", "v": 1 },
	"1CnDNtDzs5TgFEhdHDj58N2CfV33p5Y8N5": { "n": "Meditation, Self-Hypnosis", "l": "http://www.get2calm.com/", "v": 1 },
	"13jFhJqxuBudvuChfyiqTM7FrQEzAuaNzs": { "n": "Vote 4 a BNB Podcast with BTC!", "l": "http://www.bitcoinnotbombs.com/bitcoin-not-bombs-year-in-review-podcast/", "v": 1 },
	"1H428mcqXXHNXVkiWVNXppQ42udwhKTp6C": { "n": "Bitcoin-Play.com (4-6)", "l": "http://bitcoin-play.com/", "v": 1 },
	"15YqMBuXFPkmYVaSfsuCuWJwXNckuYqvuZ": { "n": "Bitcoin-Play.com (1-3)", "l": "http://bitcoin-play.com/", "v": 1 },
	"1EnzoK1fR8EeCWA9B6LXWgX9Hc9Y2Dqg32": { "n": "DeadWallet", "l": "https://plus.google.com/+EnzoLaroche/about", "v": 1 },
	"1DT4xqWDmxvTroYbiacR5dT3Po2xxnz8Eu": { "n": "Exchange Gold for Cash", "l": "http://exchangegoldforcash.com", "v": 1 },
	"1FtqGUZRTYm5UJgB7WbNdSEefBgJ6XDWQN": { "n": "VitalVas Exchange 10702", "l": "http://www.vitalvas.com", "v": 1 },
	"1CoinTqxdoz1oV44AN8jBUgrAhhjc1Pn8b": { "n": "Coin Ticker Donation", "l": "http://amewong.com/donation", "v": 1 },
	"1CdDJxg2ECBNStddVAjrQVxKppEkmRBhZL": { "n": "Bit Moeda", "l": "http://www.bitmoeda.tk", "v": 1 },
	"1FCENEkkw45bhXZmW4ih74SR659CC5B2Le": { "n": "Bitcoins From Pieh0", "l": "https://bitbargain.co.uk/profile/pieh0", "v": 1 },
	"172Jrw4Cir5TDGy9jVo15YDEgaPhNy77XV": { "n": "phambit.com", "l": "http://phambit.com", "v": 1 },
	"1DSZcgeRHP1qrshERPyWiQwfRdiZ2wxd4o": { "n": "fiatleak.info", "l": "http://fiatleak.info/", "v": 1 },
	"19UjZ56cos4wKJPd5FRD41PJzhYrmPYSu5": { "n": "Bitcoin Pulse", "l": "http://bitcoinpulse.tumblr.com", "v": 1 },
	"1BCL1B5TbGRdoccRJWmYBQqMVYvP9Qsdsp": { "n": "Block Chain Lottery 1", "l": "http://blockchainlottery.com", "v": 1 },
	"1DwsHSKpCaD3pfDTJzHwLp6wPa2zHAdfGv": { "n": "EarnCrypto.com", "l": "http://www.earncrypto.com/", "v": 1 },
	"1K8SWDjE33LHs7T67GyJbajuW4rQ9Xh83u": { "n": "BTC_LTC_Xchange", "l": "https://www.rebelmouse.com/btc_ltc_xchange/", "v": 1 },
	"128Dwx6qckYEftrUGmYWfn5PRcKvQtW6bp": { "n": "PeerTech.org Hack Bounty", "l": "https://peertech.org/bountyrewardprize", "v": 1 },
	"1JiDMUXsRnCTojAp24suNTiCDjuRrTuJbN": { "n": "Codicode.com", "l": "http://www.codicode.com", "v": 1 },
	"1TLVsqcLR6ZAsjmproYrDJUas6127ecfJ": { "n": "SatoshiTLV", "l": "http://satoshisquare.org.il/", "v": 1 },
	"1KDZMzoahiAHtAbp8VuVvNahm5SaN3PFXc": { "n": "Bitrated", "l": "https://www.bitrated.com/", "v": 1 },
	"1F5WtD7UiyfSVkBj42qxn4xFD2TYPcZ5mJ": { "n": "Bitcoin Pulse", "l": "http://www.bitcoinpulse.com", "v": 1 },
	"18sJQz4vpP688XRavD1mCDP5J7DzChzTjE": { "n": "Why Invest In Bitcoin", "l": "http://www.whyinvestinbitcoin.org", "v": 1 },
	"1NgzyBZKYfdt7GwBr4UomDyGptUcZp64Cd": { "n": "DOGMA Portraits", "l": "http://dogmaportraits.com", "v": 1 },
	"12vX1coDtNAcNFsKaG4Qw4L4K68CNwajpJ": { "n": "Alpine at PeerTech.org", "l": "https://peertech.org/alpine", "v": 1 },
	"1F8xxFxVmFQgZnb6akG84sqWFCQghusE53": { "n": "PeerTech.org Donation", "l": "https://peertech.org/donate", "v": 1 },
	"19t7Y6bAMkVjbUNNV8cazvgHtjdbi46mkN": { "n": "Lemon Party Donations", "l": "http://lemonparty.org", "v": 1 },
	"18wKHQ7ZKAnR64BDbSp2xqkMdBRqLF6WPD": { "n": "Open Meteo Foundation", "l": "http://openmeteofoundation.org/support-us", "v": 1 },
	"1ET1pjAyzmA8UBQadoY7wYemJpm7CibPsN": { "n": "Woodcraft Folk", "l": "http://woodcraft.org.uk/bitcoin", "v": 1 },
	"15nFKQQpqW44BLptx2xTAzp2jRByvaMQ53": { "n": "JJonline", "l": "http://blog.jjonline.cn", "v": 1 },
	"1HZtYJbuBJ7JJ5X2dGKh7mzT6VuJqj8ErJ": { "n": "bitcoinsvergelijken.nl", "l": "http://www.bitcoinsvergelijken.nl/", "v": 1 },
	"1JxTsJtcf3pwGRJptkdui5BPnxKJWp84eq": { "n": "Escape Velocity", "l": "http://chrispacia.wordpress.com/", "v": 1 },
	"1stakefTd3paxhaxTKNwrqdh3rWNtK6K3": { "n": "SatoshiBones Stakeholder", "l": "http://bitzillions.com/satoshibones/stake", "v": 1 },
	"1FkpYc4GpK53vSS4WchmfNnGMH9pX4HWek": { "n": "Bitcoinboerse", "l": "http://www.bitcoinboerse.eu/", "v": 1 },
	"1StatsQytc7UEZ9sHJ9BGX2csmkj8XZr2": { "n": "wizstats donations", "l": "https://github.com/wizkid057/wizstats", "v": 1 },
	"1G9vdg3S8GYzpDVVnwxYWhoFLzuPi5iX8b": { "n": "UFOHQ UFO NEWS -updated 24X7", "l": "http://ufohqs.com/techblog/2013/11/21/bitcoin-resources/", "v": 1 },
	"1Da7HTENhPHu2NEGWnvDLx9XdKjf3tBc9s": { "n": "BSNEWS - known scamm site", "l": "http://bsnews.info/donate-using-bitcoin/", "v": 1 },
	"1EhtD6FYBUBAT4MggVMZSBgMVgA16WGiEv": { "n": "Longr", "l": "http://longr.co/connect.php", "v": 1 },
	"1APgKTc5qiUst9wwvmEcD2xW2zYDr3FnM1": { "n": "Vespar", "l": "http://vespar.co/", "v": 1 },
	"12smid9gRzkBcDUhczPJocjyzuWQLJFfCv": { "n": "Despar", "l": "http://despar.co/", "v": 1 },
	"19pSndqCXcja9BxuSmuPeh51qrTCf2L96v": { "n": "LoopNote", "l": "http://loopnote.co", "v": 1 },
	"19ck18UfZZxZ82Wnnf3LFQACohm3BD2E5q": { "n": "godsendmebitcoins", "l": "http://godsendmebitcoins.tumblr.com/", "v": 1 },
	"1Jn8xX95UJ5CYHgPDV8vERn5YM9ZhWopYy": { "n": "NerdSpace", "l": "http://nerdspace.co", "v": 1 },
	"1PN1JwqftbqFWvpfoBCC2iJ4KBeY4xik6H": { "n": "TorSearch", "l": "https://torsearch.es/", "v": 1 },
	"1BoatSLRHtKNngkdXEeobR76b53LETtpyT": { "n": "VanityGen Sample Address", "l": "https://en.bitcoin.it/wiki/Vanitygen", "v": 1 },
	"1EQDEEbYJuevPpJsDczQzspTV8GRTCpk1T": { "n": "bitcoinaverage.com", "l": "https://bitcoinaverage.com/", "v": 1 },
	"14A9PdnEKXGn1PxMciyfz5XJ9oU3pgtWJY": { "n": "Coinsiderthis.com", "l": "http://www.coinsiderthis.com/", "v": 1 },
	"1Archive1n2C579dMsAu3iC6tWzuQJz8dN": { "n": "Internet Archive", "l": "https://archive.org/donate/bitcoin.php", "v": 1 },
	"1CTQP6g2GMMc99JoZ63qE8yxtpZeV2NJnP": { "n": "La Quadrature du Net", "l": "http://soutien.laquadrature.net/", "v": 1 },
	"1LACoPdgzYGpPgwpHuFzz8mh8dggsMXjaZ": { "n": "lacop", "l": "http://bitcoin.yreg.me/", "v": 1 },
	"13gpMizSNvQCbJzAPyGCUnfUGqFD8ryzcv": { "n": "BitcoinRichList.com", "l": "http://bitcoinrichlist.com", "v": 1 },
	"12Fv75hTYEKTy4YNAszoLY375u65aUD782": { "n": "Game Music Themes", "l": "http://www.gamemusicthemes.com/supportus/index.html", "v": 1 },
	"1PidAtUZ4M3SWiLNkFWNnaQirD2Xsr9fQT": { "n": "newsBTC", "l": "http://newsbtc.com/sponsorship/", "v": 1 },
	"14GrZK91ekUivjn2erFKTTFLNm9h5Huc85": { "n": "CX - Official", "l": "http://carderx.com", "v": 1 },
	"1PVjy8A7R4awzhi82s3bbtgdX9PWKReTHj": { "n": "PocketMine", "l": "http://www.pocketmine.net/", "v": 1 },
	"1ML5aXvR3WTn2vB3ehTgqyZUhSGDjVWe4B": { "n": "Bitmessage.ch", "l": "https://bitmessage.ch", "v": 1 },
	"1EmwL2qtpcQwcKnkpGvTsAssSgbnJ3qRfC": { "n": "Aileron", "l": "http://aileron.no/", "v": 1 },
	"12uVm69FcV77js9KNhPHdRnvk3q2CpXuAN": { "n": "HamV", "l": "http://hamburgervaeter.de/", "v": 1 },
	"1MGcZjvsujKqTwbSswK3ma4aZ7agbZ9EXW": { "n": "KonNeko.com Donations", "l": "http://konneko.com/welcome-3/", "v": 1 },
	"1PTgJ9wH1KtAnrDwy7WwLHbpCBC7FKdhqP": { "n": "MultiRBL.valli.org Donations", "l": "http://multirbl.valli.org/", "v": 1 },
	"1RedJJLBmQXLXFpdtbZ2TXKAPQkUhjK8B": { "n": "Who is Red John Contest", "l": "https://whoisredjohn.wordpress.com/", "v": 1 },
	"1Dokuw1Ki8dGk4p2hAWZv4TwGj8Ax1Vcqz": { "n": "DokuWiki Donations", "l": "https://www.dokuwiki.org/donate", "v": 1 },
	"161MdohA97QKTJrKuM324mjeZQDj4TSZVY": { "n": "Kware Ji", "l": "http://kware.blogbus.com", "v": 1 },
	"14zaV2fFct63L1JEoajawNEPBv38kLrQjP": { "n": "SteveGriff.com Cigars", "l": "https://www.stevegriff.com", "v": 1 },
	"1KfdjXK1eYVGNknMhackMCT6LdRSnMhzbo": { "n": "Bitcoinfury", "l": "http://bitcoinfury.com/a-propos/", "v": 1 },
	"18XLkVSNxZJzR7WWDP78kuZfC1wnF2nMrK": { "n": "Orgone.ch", "l": "http://www.orgone.ch", "v": 1 },
	"175o52E64wHQumzfLFnKrPaukJsvo9pgMb": { "n": "Win Free Bitcoins Every Hour!", "l": "http://freebitco.in/", "v": 1 },
	"1ArSXYLfVPTD2qFwymc1ut2DbfW8vXrj86": { "n": "Tvin.Me", "l": "http://tvin.me/", "v": 1 },
	"18abPtTNNcRnrbSpE1GA8X5JBjqXSgetJU": { "n": "We Mine Bitcoin (Deposit)", "l": "http://weminebitcoin.co.uk", "v": 1 },
	"1NErjjGtYjcDvkWrALkUAkVkChz5sia4BW": { "n": "2MF.ru", "l": "https://fedorov.net", "v": 1 },
	"1MihaFxDyz1HMru2593JEyBXMYbA486FmN": { "n": "2MF.ru", "l": "https://fedorov.net", "v": 1 },
	"16v83vgBD9Zi3NBs7sNmABpJFRbruLHxTC": { "n": "2Unlimited", "l": "http://2unlimited.info/", "v": 1 },
	"1P7XMdfcQGb442rCu72s8gqcniKnHCafAT": { "n": "TopPTC Sites", "l": "http://topptc-sites.tk/bitcoin.html", "v": 1 },
	"11NHqX9gAU7vnmSAMRDzfmSnUXQUmuj62": { "n": "DoubleMyCoins! Cold Storage", "l": "http://doublemycoins.com/cold-storage", "v": 1 },
	"1WTFa8iZdUNLK7K14fMzL9A8tqUnXx7L1": { "n": "WhyTheFed", "l": "http://www.whythefed.com", "v": 1 },
	"1KwdqGGxSUmLVxd9w85zoC6DSEoGRFoAkE": { "n": "www.functions-online.com", "l": "http://www.functions-online.com", "v": 1 },
	"1DESRnKjMhXe8g89HYQQdJ4uf7EzJesrgc": { "n": "NewB", "l": "http://koobuk.blogspot.kr", "v": 1 },
	"1MMiQejuedFwwuB2AvbhE32ns3cEdHoypi": { "n": "Mike Mutual", "l": "https://sites.google.com/site/therulesasdf/mike-mutual", "v": 1 },
	"1BZDeCvxBoUtRERmEripA8odUzxtPytzd": { "n": "New AnonNews.org address", "l": "http://anonnews.org/static/donate", "v": 1 },
	"1Q1wVsNNiUo68caU7BfyFFQ8fVBqxC2DSc": { "n": "Local Bitcoins signing address", "l": "https://www.localbitcoins.com/faq", "v": 1 },
	"1BTCkS3VuzagwZffVFVggDtTsgZM2hiCjw": { "n": "Bitcoin Bonanza", "l": "http://bitcoinbonanza.tk", "v": 1 },
	"1oskarZKuAXqpExQkLHXesoYBpeTfAzbu": { "n": "Oskar", "l": "http://oskar.blog.root.cz/", "v": 1 },
	"122aCxcGwnfKB96dyBCi2oGrfkbQKNWBy8": { "n": "TopPTC Sites", "l": "http://topptc-sites.tk/bitcoin.html", "v": 1 },
	"1MkUu7TtzBVG2VZ15pm4H6CrqfdezKMmST": { "n": "1furesoft23", "l": "http://tca.pf-control.de/", "v": 1 },
	"1EEg2m6ujyYpNRozqR6HTwy2mND4Jcy66Y": { "n": "BitcoinRichList", "l": "http://bitcoinrichlist.com/top100", "v": 1 },
	"16wrTxqhG1gRyXRdYA6kaSkVxfNvi5mWKe": { "n": "Pizza For Homeless", "l": "http://pizzaforcoins.com/pizza-for-homeless", "v": 1 },
	"1THRF26KAsDDLh1JyWB5Hbm5mYgN6LwZt": { "n": "Typhoon Haiyan Relief Fund", "l": "http://typhoonhaiyanrelieffund.org/", "v": 1 },
	"1JRVxWphAwxQeYkTqEPHjw2nzpikEGLx3K": { "n": "BestBitcoin Donations", "l": "http://bestbitcoin.com.br/", "v": 1 },
	"1JHGAcPRqg88QNzjoN6rdzEe8vmczQrBax": { "n": "Jianhui Gong", "l": "http://gongjianhui.com", "v": 1 },
	"1KCjWWhESnJHb3rDvRh65AJYACbRCWGPof": { "n": "Philippines relief efforts", "l": "http://www.fr33aid.com/1311/aid-for-phillippines-typhoon-victims/", "v": 1 },
	"1Fm8XdPvGzKbfuHrBrsK8d7ZDLvCCM1WWc": { "n": "BitMe Typhoon Relief Fund", "l": "https://bitme.com", "v": 1 },
	"1iceTzzakxvKBJvQtoLsXeyCnbsF3EXRR": { "n": "iceTwy", "l": "http://icetwy.re/", "v": 1 },
	"1AEoiHY23fbBn8QiJ5y6oAjrhRY1Fb85uc": { "n": "Cryptolocker ransom", "l": "http://www.reddit.com/r/Bitcoin/comments/1o53hl/disturbing_bitcoin_virus_encrypts_instead_of/", "v": 1 },
	"1NTs92VRppSsSeYLAXJtP1SxAzBwYk8JeH": { "n": "G3raint", "l": "http://weminebitcoin.co.uk", "v": 1 },
	"1sLPs5LkhgNKuhgQqFVmrcEnkXNEnjapG": { "n": "To The Moon Guy Game", "l": "http://www.tothemoonguy.com/", "v": 1 },
	"1BaiBPorJ3g9PxV1s9qsRv8uJRbM3cEUqZ": { "n": "bitcoin.LIFT Lottery Pool", "l": "http://bitcoin.lift-institute.com/lottery/", "v": 1 },
	"1GMRdttmWgbszyU1UBZeurbS7i322FYbv9": { "n": "Bitcoin Java", "l": "http://www.bitcoinjava.com", "v": 1 },
	"14Db5HZh4iQ9AuVjm91UPTSJ6Wcpvm74bi": { "n": "Erowid Donations (Oct. 2013)", "l": "https://www.erowid.org/donations/donations_bitcoin.php", "v": 1 },
	"1GrPK9t5PdXf6Vi8sMend4HN4AWJsuqF4s": { "n": "sudosurootdev", "l": "https://sudosurootdev.com", "v": 1 },
	"1istendqWJ1mKvrdRUQZDL2F3tVDDyKdj": { "n": "BitListen.com Visualizer", "l": "http://www.bitlisten.com/", "v": 1 },
	"1MsfHcEqv3Q46bgX5c1nmNtXu6K7fGja2i": { "n": "vnbitcoin.org", "l": "http://www.vnbitcoin.org/freebitcoin.php", "v": 1 },
	"1Rattyf1yPnD8s87q6TiWey4UeQiRmtWE": { "n": "Ratty", "l": "http://rat.org", "v": 1 },
	"13vhTK14y1pVU5q8NoN2fGjEVFWGhvmEvh": { "n": "Bitcoin Exchange", "l": "http://bitcoinschanger.com/", "v": 1 },
	"1DRvipNAaUcP1Xu9iy4s1LJCBjXwm9Brno": { "n": "BioEnergy", "l": "http://www.bioenergy.by/", "v": 1 },
	"1EMztWbGCBBrUAHquVeNjWpJKcB8gBzAFx": { "n": "Inputs.io Hack", "l": "https://inputs.io/", "v": 1 },
	"1PLxMiUVj7vNdvGNbAqAQhvrERvttFK8RY": { "n": "Radioactivity", "l": "https://drupal.org/project/radioactivity", "v": 1 },
	"1LmtdcvLTtfHCAkQhCN29n9Y37omz2hdCG": { "n": "2Unlimited", "l": "http://2unlimited.info/", "v": 1 },
	"181qBDLagJWDfvfz7v7f3c7vgw4vk8areK": { "n": "Everest Gliding Donation", "l": "http://bitcoinmagazine.com/7381/sebastian-kawa-and-his-bitcoin-funded-mt-everest-flight/", "v": 1 },
	"1DLLTZU8dYMUGsHWaXcexb9H7pCwrGxAod": { "n": "Dagensia client_01", "l": "https://dagensia.eu", "v": 1 },
	"1Aaw447CaLUmUcD9ysnAbre5dK46fZ8iCy": { "n": "Fria Tider", "l": "http://www.friatider.se/ny-bitcoin-adress-for-donationer", "v": 1 },
	"1FQXqcRskzys6HK2uqMrfbdvPiRQFXTAnc": { "n": "gwern.net donations", "l": "http://www.gwern.net/hpmor", "v": 1 },
	"18HLotEwvSTTWAtHBX5mrib5p1q9svz2Xu": { "n": "zonk.be", "l": "http://zonk.be/flattr-me/", "v": 1 },
	"1BitangoaBiPiX6dqcLCHZUjsvzsuauB2x": { "n": "Bitango", "l": "http://bitango.me", "v": 1 },
	"1AwW6GoougWHxZkiQEfGTput3Yh8c1mHmU": { "n": "Gonglibo", "l": "http://blog.csdn.net/gonglibo", "v": 1 },
	"1E2VuZ5Rr4oAPG8veJw8zXUWdDBhtyFv9E": { "n": "AnarchistRepo", "l": "https://anarchistrepo.com/index.php/Donate", "v": 1 },
	"14auekVm3ph4q6Ncowv844DMZDU58XjHfp": { "n": "Syari.net P2Pool", "l": "http://syari.net/pool/btc/", "v": 1 },
	"1Lwu6gNmrH6nBUcm7EeUQjuHrA1uujQtjh": { "n": "thinkdevcode donation", "l": "http://thinkdevcode.wordpress.com/about/", "v": 1 },
	"1P3BAWpCdugQJoaNKWTsBBiCJxfkNLnTjK": { "n": "zvedavec.org", "l": "http://www.zvedavec.org/komentare/2013/11/5723-stoji-investice-do-bitcoin-za-uvahu.htm", "v": 1 },
	"1PFVHCnmL3xdqc9rr369YQqJbMg44HUwZT": { "n": "iosp", "l": "http://iosp.ru/", "v": 1 },
	"1J73KQTj4Vi4DQbntu1PEh69eSQKV3pSJe": { "n": "iosp", "l": "http://iosp.ru/", "v": 1 },
	"1Gt1anYr6gEuiNgacFouhy4RUNQFH3YY9Y": { "n": "South Pole Transaction", "l": "http://www.coindesk.com/adventurer-make-first-ever-bitcoin-transaction-south-pole/", "v": 1 },
	"1NeoTanKAxHEXanM9Y54t6ErpGH8JU7kSh": { "n": "NeoTan", "l": "http://www.kingteller.com/", "v": 1 },
	"1bonesYMDyzAZRjYPszT8dU9ysakav5MS": { "n": "SatoshiBONES 0.09766pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones8VWK2LbDYZ8TJAME9gpHaV2ZCGT": { "n": "SatoshiBONES 1.562pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesBos9NC2BHHB3apg9nfMgG9CvVHW": { "n": "SatoshiBONES 6.25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesEeTcABPjLzAb1VkFgySY6Zqu3sX": { "n": "SatoshiBONES 12.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesBjs3DQUbx4wxPQwrbwCkNjWtLB4": { "n": "SatoshiBONES 25pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones2wX8sqGHcuXeKPzHgZegtL2dnGC": { "n": "SatoshiBONES 37.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesF1NYidcd5veLqy1RZgF4mpYJWXZ": { "n": "SatoshiBONES 50pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones5gF1HJeiexQus6UtvhU4EUD4qfj": { "n": "SatoshiBONES 62.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesUhqtbLAGKWZuawCzsYqmYWEgPwH": { "n": "SatoshiBONES 75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bones2foMuSFG5dr4x6N8k5hDyPTs8fu": { "n": "SatoshiBONES 87.5pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1bonesPdRYS91Mq9arbiUratHy2J5gDut": { "n": "SatoshiBONES 93.75pct", "l": "http://bitzillions.com/satoshibones", "v": 1 },
	"1FUnKy36TgN6mPqdSrT3vQHv18pFS8wuVZ": { "n": "Funky Faucet", "l": "http://funkyfaucet.tk", "v": 1 },
	"1SbitjJQsHQkiFgqxEZpHqM1NQH28j98G": { "n": "Slot_bit", "l": "http://www.slotbit.info/", "v": 1 },
	"19SbeTc3JArQiM1gq7s3UPTJv1h6mtA1DW": { "n": "FUCK THE FBI - BITCOIN FTW", "l": "http://www.heypasteit.com/clip/10Y9", "v": 1 },
	"18W5KaeGsB7uZeeA1CWX5hgUbdRYrPtyVr": { "n": "BC Test Label", "l": "http://bitwatch.co/labeltest.html", "v": 1 },
	"1diceFTWyfofAVNDNCCogB4avJBPP7A1c": { "n": "SatoshiDICE Tribute", "l": "https://satoshidice.com", "v": 1 },
	"1bccV3LXEd2kRwxopZenDwVSFyQtMnmVU": { "n": "BitCoinChangeClub", "l": "http://bitchangeclub.org/", "v": 1 },
	"1LKN6CHCf5RnhwKYU51watsb2Z14jth3mF": { "n": "flippa-bradgosse", "l": "https://flippa.com/2988863-no-reserve-2-151-00-mo-link-cloaking-redirect-plugin-bitcoin-accepted", "v": 1 },
	"1LagServ4ZMtyHnLyNiVftJPgJzJEk4Njt": { "n": "LagServ.com", "l": "http://www.lagserv.com", "v": 1 },
	"1snowqQP5VmZgU47i5AWwz9fsgHQg94Fa": { "n": "Official Snowden Defense Fund", "l": "https://fundrazr.com/campaigns/dYhk0", "v": 1 },
	"1JQaM6JBQRSwFyUmo4MDPuzndYzegxbuUN": { "n": "Ice-Dice.com Cold Storage", "l": "https://ice-dice.com", "v": 1 },
	"1MvzX9qeGvm2V3KvWfZhK244v3WD4iSr2N": { "n": "Invest Bitcoins", "l": "http://bitcoinschanger.com/", "v": 1 },
	"1BetDPqjEQSbBaB9hPuZEUx9vMH3Foq5KJ": { "n": "Berg Poker Simulator", "l": "http://www.codethrowdown.com/", "v": 1 },
	"1PT78metKnSkYKxdsAQD35c6ShXPwATX6V": { "n": "bitcoinstats donations", "l": "http://bitcoinstats.com/", "v": 1 },
	"1cT4JiM8cMSdBvQQ7UuqJUzAtgvcKQMoY": { "n": "Bitell.com", "l": "http://www.bitell.com", "v": 1 },
	"18sQnMCavXPPBzWfTYXd9aDju6NbWc89NL": { "n": "DAM donations", "l": "https://github.com/goshakkk/decentralized-anonymous-marketplace-concept", "v": 1 },
	"1FfmbHfnpaZjKFvyi1okTjJJusN455paPH": { "n": "DPR Seized Coins", "l": "http://www.forbes.com/sites/andygreenberg/2013/10/25/fbi-says-its-seized-20-million-in-bitcoins-from-ross-ulbricht-alleged-owner-of-silk-road/", "v": 1 },
	"1LuckyR1fFHEsXYyx5QK4UFzv3PEAepPMK": { "n": "LuckyBit red", "l": "http://luckyb.it/", "v": 1 },
	"1LuckyY9fRzcJre7aou7ZhWVXktxjjBb9S": { "n": "LuckyBit yellow", "l": "http://luckyb.it/", "v": 1 },
	"1LuckyG4tMMZf64j6ea7JhCz7sDpk6vdcS": { "n": "LuckyBit green", "l": "http://luckyb.it/", "v": 1 },
	"1P4MBgFP46mByiswyu3cg4qYZ3xRE8ooT": { "n": "re8oot", "l": "http://re8oot.com/", "v": 1 },
	"14TUZT3QF9MxjWvgLLfpzaQBzNW4PA2M3a": { "n": "Jeanny Cameron", "l": "http://jeannycam.com/nsfw-images/", "v": 1 },
	"1BCN1ugdKdWd9pQ8Am9hMhtHZfmbXzxE8a": { "n": "Nxt", "l": "http://altcoins.com/nxt-descendant-of-bitcoin.html", "v": 1 },
	"15UUBLiadWEbewpBjD46A4d7h58eXkN2BG": { "n": "Free Bitcoin Faucet", "l": "http://freebitcoinfaucet.com/faucet.php", "v": 1 },
	"1HhiFZnMqzE42kT8MaiQMeLpMygoPde1tR": { "n": "Coinplorer", "l": "http://coinplorer.com/Pages/FAQ", "v": 1 },
	"1RichoHNquusV8Tb4wkSU6VGoQBSj58pM": { "n": "GetRich In Minutes-BTC HYIP", "l": "http://www.richiewealthy.com/", "v": 1 },
	"1PxxYyZNtfRJc5ikYJ5bKr3hHHfMeEmtAu": { "n": "P2PBUCKS.COM", "l": "http://p2pbucks.com/", "v": 1 },
	"1BetCnsbQDbiJkQBf8xcH7NwUUUJGuu2hU": { "n": "BetCoin.tm", "l": "http://betcoin.tm", "v": 1 },
	"1LvMZKGGKXLsY4eRMcx1CaqfugpKtocrYX": { "n": "Loverman", "l": "http://www.loverman.net", "v": 1 },
	"1HorNmss5cp3yNi34mq47tRHSdSuK3jAnk": { "n": "Alexander Technau", "l": "http://alexander-technau.de/bitcoin/BTC.html", "v": 1 },
	"1MAWhq6fk8vzgp81Wd48akj8Qn6CW7LHQF": { "n": "Lets Talk Bitcoin E50", "l": "http://letstalkbitcoin.com/e50-georgia-in-october/", "v": 1 },
	"16RuurS5f29duMepnVsZws3z5JMYL8t5MM": { "n": "coininaction", "l": "http://www.coininaction.de/", "v": 1 },
	"1B6NP9eb4RKy9tRrXYCJnNcenZkrt5Q2gb": { "n": "bitcoin-assets donations", "l": "http://bitcoin-assets.com/", "v": 1 },
	"1NtbQKVFxAPc8mmBoWwRzhg7o3EMCBsxNg": { "n": "Baidu Jashule", "l": "http://jiasule.baidu.com/news/525cd5aabf9efd699f800e7e/", "v": 1 },
	"1FreefoKihgKN1nCPD4FNxuRDwwWjoiVFi": { "n": "Win Free Bitcoins Every Hour!", "l": "http://freebitco.in", "v": 1 },
	"1LDAdsJHqtqb5LTaLqghTxbFyDiDrAFbnK": { "n": "LetsDice.com", "l": "https://letsdice.com/", "v": 1 },
	"1LDAdsVnTCMes8jgaYfYAzvmFmKcgjj4QD": { "n": "LetsDice.com", "l": "https://letsdice.com/stat/", "v": 1 },
	"1M72Sfpbz1BPpXFHz9m3CdqATR44Jvaydd": { "n": "Seans Outpost", "l": "http://seansoutpost.com/donate/", "v": 1 },
	"1255snpLjXYeK5SJvuYyFnEBhNvqEWEdhc": { "n": "2nd half bit opened casascius", "l": "http://blockexplorer.com/address/1255snpLjXYeK5SJvuYyFnEBhNvqEWEdhc", "v": 1 },
	"1JhsdtAC8K55P2z1aco8GLeBnEB6AjoQZN": { "n": "Thunderbird PennyPost Add-on", "l": "http://whtsnw.tk/", "v": 1 },
	"1Ki1FJQX2PhAp15vtaHGFTeuB3XkB38FJn": { "n": "Dieter Tecnax", "l": "http://alexander-technau.de/", "v": 1 },
	"19PzzPHSgoyGyjiCbqDHq3Zq9MSNgs5sRS": { "n": "btc-chart.com", "l": "http://btc-chart.com/market/bitstamp/7948800", "v": 1 },
	"1aLpBZL4ptiyjwEv1SY4DSEKDqeW2cb8K": { "n": "BitcoinProspectors.com", "l": "http://www.bitcoinprospectors.com/bitcoin-prospecting-address-tags/", "v": 1 },
	"1ALEX13F6SgWpkZoszkk9YwxPQgqkzqGWa": { "n": "alex-radeke.com", "l": "http://www.alex-radeke.com", "v": 1 },
	"1JvcfSKuzk3VENJm9XtqGp2DCTesgokkG2": { "n": "pyLoad", "l": "http://pyload.org", "v": 1 },
	"1AoYA4NmweQuTVRvTKf4PPLcjwWGHJGSj8": { "n": "175btc", "l": "http://175btc.com", "v": 1 },
	"15NMJSTLhXAsxhrZNREzmuWDUiicLsTsCa": { "n": "Future Block", "l": "http://www.futureblock.com/", "v": 1 },
	"1HKTecnwT6QCtYjwTmYfZ6Jg1o6mpesBp9": { "n": "Dred Pirate Roberts Legal Fund", "l": "http://thefreebitcoinslist.com", "v": 1 },
	"1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX": { "n": "Silkroad Seized Coins", "l": "http://en.wikipedia.org/wiki/Silk_Road_(marketplace)", "v": 1 },
	"133ztkNaGrw4tMWpkXShz9wbq4JXBUP19r": { "n": "satoshi-karoshi", "l": "http://satoshi-karoshi.com", "v": 1 },
	"1RyU1WNb8J9AC5aMKAKDgB9GxGjYjj3nN": { "n": "BTCOracle Down 10 percent 1 week", "l": "http://www.btcoracle.com/", "v": 1 },
	"1RYu3ddha97ebXjFCQJTQbwSLqHACHSb4": { "n": "BTCOracle Down 10 percent 3 day", "l": "http://www.btcoracle.com/", "v": 1 },
	"1Ryu1dRXiQMVRe3h2RoRPwENRGKTLy4Mf": { "n": "BTCOracle Down 10 percent 1 day", "l": "http://www.btcoracle.com/", "v": 1 },
	"1Ken1WyQfbHY8M46fLeNSzrSWZPKGwrWnB": { "n": "BTCOracle Up 10 percent 1 week", "l": "http://www.btcoracle.com/", "v": 1 },
	"1Ken3d1oSsDngJvJVAL5rTgmUvW7PZ49Dd": { "n": "BTCOracle Up 10 percent 3 days", "l": "http://www.btcoracle.com/", "v": 1 },
	"1KeN1DWJVj8P9xPFQf37SQu93fVBUm7gBz": { "n": "BTCOracle Up 10 percent 1 day", "l": "http://www.btcoracle.com/", "v": 1 },
	"1Down1wQgV48Birha7Cb9n3gjRB2ni7Vg4": { "n": "BTCOracle Down 1 week", "l": "http://www.btcoracle.com/", "v": 1 },
	"1Down3DXbFdSQMCZRG7GBr5WknU3FxiW46": { "n": "BTCOracle Down 3 days", "l": "http://www.btcoracle.com/", "v": 1 },
	"1DoWn1dX4wrdFRLu2AAFZ4XU8P5XpPjVV4": { "n": "BTCOracle Down 1 day", "l": "http://www.btcoracle.com/", "v": 1 },
	"1DoWn3HvQszJuiyzUN2YBXwCFLynew6JnW": { "n": "BTCOracle Down 3 hours", "l": "http://www.btcoracle.com/", "v": 1 },
	"1DowN15MRJnui7Qj3VFkhLPDFMm8bYsEX6": { "n": "BTCOracle Down 15 min", "l": "http://www.btcoracle.com/", "v": 1 },
	"1up1wf3oiVL9PDqVNsKjFxPe7gfVux9RP": { "n": "BTCOracle Up bet 1 week", "l": "http://www.btcoracle.com/", "v": 1 },
	"1up3DLgeHx2yLm4WP75AsuzEJ92Uk83zD": { "n": "BTCOracle Up bet 3 day", "l": "http://www.btcoracle.com/", "v": 1 },
	"1up1dJ9Y1t9ZEQRh3ZsDzEq9DqZrf2F4P": { "n": "BTCOracle Up bet 1 day", "l": "http://www.btcoracle.com/", "v": 1 },
	"1up3hyCXBeaa97FkCsw8XiWS2bJnrsRgJ": { "n": "BTCOracle up bet 3 hours", "l": "http://www.btcoracle.com/", "v": 1 },
	"1Up15Msx4sbvUCGm8Xgo2Zp5FQim3wE59": { "n": "BTCOracle up bet 15 min", "l": "http://www.btcoracle.com/", "v": 1 },
	"15CetK2a1kJAM9VNDmwVJ67HGxkHuGyTiM": { "n": "John Zhao", "l": "http://www.zhaojin.org.cn/", "v": 1 },
	"122MeuyZpYz4GSHNrF98e6dnQCXZfHJeGS": { "n": "coinwidget", "l": "http://coinwidget.com/", "v": 1 },
	"1LMvYJx26XMKnnX4R5AhWsxCg6bnSkAk3F": { "n": "TouchID hack", "l": "http://istouchidhackedyet.com", "v": 1 },
	"1FarsetjbrNzAuEaZyKzCwscn2mCSw1vEg": { "n": "Farset Labs Club Mate Donation", "l": "http://wiki.farsetlabs.org.uk/Bitcoin/Addresses", "v": 1 },
	"3QJmV3qfvL9SuYo34YihAf3sRCW3qSinyC": { "n": "gavinandresen Multisig Test", "l": "https://gist.github.com/gavinandresen/3966071", "v": 1 },
	"1ANH58UbrQ7YcpBVdbfAhN6C7iu4YSwMeS": { "n": "numismatics", "l": "http://bitcoin-otc.com/viewgpg.php?nick=numismatics", "v": 1 },
	"16WF96k5rwK1GUrcUNz9qvnPq7XMQWv1V7": { "n": "feindura CMS Donations", "l": "http://feindura.org/page/download/", "v": 1 },
	"1FarsetkknKCc4KRiS854aEAamV5S65ZKz": { "n": "Farset Labs Mining 3", "l": "http://wiki.farsetlabs.org.uk/Bitcoin/Mining", "v": 1 },
	"1FarsetgqL3ufnTrnTKzSMGaRDSYvqKeAe": { "n": "Farset Labs Mining 2", "l": "http://wiki.farsetlabs.org.uk/Bitcoin/Mining", "v": 1 },
	"1FarsetgEvcYaPqo7Cm1YEwroe9y8tsdh1": { "n": "Farset Labs Mining 1", "l": "http://wiki.farsetlabs.org.uk/Bitcoin/Mining", "v": 1 },
	"1NDSCwNMhEAtryBfY3fscwhYr7btz1fWg8": { "n": "1stash", "l": "http://bitcoin.com.my", "v": 1 },
	"1TANEL9EX451ejTuyNY459xUGScPEw96S": { "n": "tanel", "l": "http://tanelpuhu.com", "v": 1 },
	"1Pot8xVFGajUYnknii5mTKwswxnBFnUpZ7": { "n": "JackpotDICE - 1 vs 7", "l": "http://jackpotdice.com", "v": 1 },
	"1Pot7qPLDdVgnjHNFExk4SRx88CGi7faJ5": { "n": "JackpotDICE - 1 vs 6", "l": "http://jackpotdice.com", "v": 1 },
	"1Pot6WEaWHZtxhJdTQ35nPXxo5tVzATmDL": { "n": "JackpotDICE - 1 vs 5", "l": "http://jackpotdice.com", "v": 1 },
	"1Pot554yw1GKM5qmV84Xdj5VGKENHRHg6t": { "n": "JackpotDICE - 1 vs 4", "l": "http://jackpotdice.com", "v": 1 },
	"1Pot4RWKcUWrY8x56vBKir4EQxgHHMFwHq": { "n": "JackpotDICE - 1 vs 3", "l": "http://jackpotdice.com", "v": 1 },
	"1Pot3P1ERrwkSaFN9bi4fKT5BE6utdowSh": { "n": "JackpotDICE - 1 vs 2", "l": "http://jackpotdice.com", "v": 1 },
	"1Pot2tTZPEEm856JspGEUBq5G5MLM9jTkH": { "n": "JackpotDICE - 1 vs 1", "l": "http://jackpotdice.com", "v": 1 },
	"1RapidBsj33CXnB42pphsfPENsKSFFHdv": { "n": "RapidBalls 5 Minute Lotto", "l": "http://btc.rapidballs.eu", "v": 1 },
	"1AceevvdFx5aBBLktHsjQbgYiEMQCU4jJU": { "n": "yabtcl.com cold wallet", "l": "https://yabtcl.com", "v": 1 },
	"12ZDggFG3EyyPuz7PwEq3o58gWWCgB5pf3": { "n": "yabtcl.com", "l": "https://yabtcl.com", "v": 1 },
	"1ERxkXGeUeJbJuqpr5n293HJcU3DtPZ9Uu": { "n": "Satoshijackpot 85.4492 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"1EK2kS85CMEsB33FE66xAsorxubjTcwWPW": { "n": "Satoshijackpot 97.6563 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"1A2tSRJ621R2riio99uXUgs4ZHG37ubMVN": { "n": "Satoshijackpot 91.5527 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"1C1RPa1PFgsYgpn1vcdwepejVyfpuVvLvA": { "n": "Satoshijackpot 79.3457 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"16zMp1FTSPC26CSjxgEeJFUrBCXMTjb7Xf": { "n": "Satoshijackpot 73.2422 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"12S3uJKy7zZfDvpGrhEFQZYnYbWEYH1ZX5": { "n": "Satoshijackpot 36.6211 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"1F76X8uVenNJ6yH7yXbpKoZYLTbV5qvCMk": { "n": "Satoshijackpot 50.0000 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"1PSRi9RBsrGWLraMEEhpy3eUma6P81BA4x": { "n": "Satoshijackpot 48.8281 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"1GNUxD6DyUrFAvEQVB65G2r6GQda7FG8UT": { "n": "Satoshijackpot 24.4141 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"1HpU3TLfhnFwxMgC8tdq65r1q8m444F5HD": { "n": "Satoshijackpot 18.3105 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"1AW4FEsusJDW9xe2wYa9bQ6AHjttnwpW4m": { "n": "Satoshijackpot 6.1035 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"14FLagXncNmfQEmSPqSvcqsex4aTAp9h3u": { "n": "Satoshijackpot 12.2070 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"193ATm14NrBKhUrvd9WNXGGU4oVW2jjwC9": { "n": "Satoshijackpot 2.2888 percent", "l": "http://satoshijackpot.com/", "v": 1 },
	"1Ratty1GaBcbDagwiio4CFrEAuhH7q38a": { "n": "Ratty", "l": "http://rat.org/", "v": 1 },
	"1NK8nCN9jqS7We54pD6Ykyz4Pfk6k8q5Lg": { "n": "RapidBalls", "l": "http://btc.rapidballs.eu", "v": 1 },
	"1KcJUtGFsnT5tmHA6GubUQFdrHSVUXfJtC": { "n": "Bitcoin Mining Calculator", "l": "http://btcmc.de", "v": 1 },
	"1LoT1kmTjyuRbSCAfSykXje9Dawkj4hyu8": { "n": "TheLordOfTime", "l": "http://lordoftime.info/?page_id=69", "v": 1 },
	"14Tyk13ELKcRaJe1CfZE8f58QcBHfeV1tQ": { "n": "OTR project", "l": "http://www.cypherpunks.ca/otr/", "v": 1 },
	"1CjPR7Z5ZSyWk6WtXvSFgkptmpoi4UM9BC": { "n": "ghash.io", "l": "https://www.ghash.io/", "v": 1 },
	"17eActmmkyLivJUzfmk6hGLUYkuo3RT4nL": { "n": "Au Rucher de Sainte Barbe", "l": "http://ruchersaintebarbe.fr/contact/", "v": 1 },
	"1P2Pchab1Awgbrk7DJn24S3YLQ7QrLDcXG": { "n": "P2PChange.com", "l": "https://p2pchange.com/", "v": 1 },
	"1AkUP8F9Hn29CefHYStweTNLAdKCupY6wS": { "n": "BTC Price donation", "l": "https://play.google.com/store/apps/details?id=com.farproc.btcprice", "v": 1 },
	"14nGXDYwBEFaE7wtqyqEenHHHNYNugC1mt": { "n": "Melkyore", "l": "http://rat.org/melk.html", "v": 1 },
	"1Ratty5sYyzdC5jNxX3d25v8wzMmxpM9G": { "n": "Ratty", "l": "http://rat.org/", "v": 1 },
	"12tumHm8bvgqPZmLPTY2rebgssNMNjBYae": { "n": "hroservices", "l": "http://hroservices.co.uk", "v": 1 },
	"1TReMem1HUQfpZymjTKUm2uVp6VoEy1GT": { "n": "HHTT Mining Tremendous", "l": "http://hhtt.1209k.com/", "v": 1 },
	"1teRRiBaUJHDohmURJFeNH2bHK4cam63u": { "n": "HHTT Mining Terrible", "l": "http://hhtt.1209k.com/", "v": 1 },
	"1HoRREnSsBNXs7StysVE3MBoCYoL7FRYSD": { "n": "HHTT Mining Horrendous", "l": "http://hhtt.1209k.com/", "v": 1 },
	"1HorriBLeWypTH3YqEAn8J5LweNJHrZ7bo": { "n": "HHTT Mining Horrible", "l": "http://hhtt.1209k.com/", "v": 1 },
	"1HHTTPaz86gcxqntnjZMHbaoF4EvyYZCka": { "n": "HHTT Fund Pool", "l": "http://hhtt.1209k.com/", "v": 1 },
	"1MP4pu1Ff5E2YKRK1hgGQYkHxmhXfrYAEq": { "n": "Coin Republic", "l": "http://coinrepublic.com", "v": 1 },
	"1L7BihPLAqPgmjD2fUMBrjFZTcnYNa5PN9": { "n": "CoinAxis", "l": "https://coinaxis.com/index.php/donate", "v": 1 },
	"1J2svn2GxYx9LPrpCLFikmzn9kkrXBrk8B": { "n": "Mastercoin explorer", "l": "http://mastercoin-explorer.com", "v": 1 },
	"14p3H4maHgtFQRfe4Qp1vKaYzFRfnoseLe": { "n": "Bitcoinchain", "l": "http://bitcoinchain.com/", "v": 1 },
	"1Jar1AX9qheRsnkJZfKjAn8bSYq4NS2c3X": { "n": "Jarl Mezentius", "l": "http://multipledisorders.com/my-disorders/bitcoin-germany-and-the-internets-decentralized-currency/", "v": 1 },
	"1MakersiNBFMdM5i6R8dgD9pkgMFE6rkAD": { "n": "Dallas Makerspace", "l": "http://dallasmakerspace.org/contribute/", "v": 1 },
	"1PSz5W1JaoQ9kZp75jYEubCKL85izj9RJx": { "n": "TheFreeBitCoinsList.com", "l": "http://TheFreeBitCoinsList.com", "v": 1 },
	"1coinL9gVnHwetayFQ6HmxTqPVyPTWPNH": { "n": "Coinflow", "l": "http://www.coinflow.co", "v": 1 },
	"1MqX4JmYKGxsG5UWy5AW8QNu4cGAdgq3hp": { "n": "robert", "l": "http://robrankin.com/btc.html", "v": 1 },
	"1NmMhQVFNLJQvc2Q9KVwNgrHW8yfJvAd9L": { "n": "dkmfsbitcoin", "l": "http://dkmfs.net/donate-bitcoins/", "v": 1 },
	"1DTiiobTw8LTFwCRoVVCg1gYeBfe4tzyHN": { "n": "SatoshiRat", "l": "http://satoshirat.com/", "v": 1 },
	"1DiDHcugy1DNw74GYsiiwFZt2oodqFTqzR": { "n": "CNY2BTC", "l": "https://cny2btc.com", "v": 1 },
	"13kRstbpb9GNhq72q9Ki8YQpRD54k44x7h": { "n": "PolMine.pl", "l": "https://polmine.pl/", "v": 1 },
	"1BTCxbkar8yvoLr2PVGgq3ifbQ6iQK9nUs": { "n": "BitoMania.pl", "l": "http://www.bitomania.pl/", "v": 1 },
	"12DLbJY48o5vFn3f7eDy7g98yPfo215W4b": { "n": "CoinNotify", "l": "http://ibittler.github.io/CoinNotify/", "v": 1 },
	"194GJuEauVdybZ7ngdCcCDuLam5anWp67R": { "n": "HostGyn", "l": "http://www.hostgyn.com", "v": 1 },
	"17gSFCT1AWUNTi6vhmaCq2fAJmjRDYC3Pg": { "n": "Kai Elvin", "l": "http://kaielvin.org/", "v": 1 },
	"198PnzXVjxU4nYWYPBHRDGoGQYYGEShyYn": { "n": "Skami", "l": "http://www.skami.net/", "v": 1 },
	"1freekgtN1BGj5bjnyPo9p8kVrH2Hd6PJ": { "n": "BitCoin Information Faucet", "l": "http://bitcoininformation.appspot.com/faucet/", "v": 1 },
	"13kDL4Tzaj7DMH2q3EfqEck6QKLexT6JwT": { "n": "OmegaWiki", "l": "http://www.omegawiki.org/Meta:Donate", "v": 1 },
	"1AxjjAxzieNRQkBixT2w9PRJxo297nKSEF": { "n": "artificialbrains.com", "l": "http://www.artificialbrains.com/about", "v": 1 },
	"1CBtcGivXmHQ8ZqdPgeMfcpQNJrqTrSAcG": { "n": "CoreBitcoin", "l": "https://github.com/oleganza/CoreBitcoin", "v": 1 },
	"13z55AGS14pSPiPpMqAAFHb576tSmSmR77": { "n": "mailpile", "l": "http://www.mailpile.is", "v": 1 },
	"1AYTkpQDA2nu6vu6JjZvbDgMXa1SjehVYu": { "n": "ASICME mining address", "l": "http://asicme.com/mining-address", "v": 1 },
	"1PHE76VpBgQGp2JXTCqZrunY3SYre4DiGG": { "n": "Ratchet Zufreur", "l": "http://ratchet.sl", "v": 1 },
	"1PxH5B5KEN1T7NSjyCuf4jRE5Sd1n3anQr": { "n": "SG Mining Consortium", "l": "http://sgminingconsortium.wordpress.com", "v": 1 },
	"1GqLryn9EGhWAHvWkooHGBeSNLw8aPqPtW": { "n": "Polyatomic", "l": "http://bitcoin-otc.com/viewgpg.php?nick=Polyatomic", "v": 1 },
	"1PFH8NPWu2g6TdRQsirTPGpbnPBhkzQMvM": { "n": "Noisetor01 Tor exit node", "l": "http://tor.noisebridge.net/", "v": 1 },
	"17xaMCKwPJxo6pHSc64j2DnDCmDgc1gaD2": { "n": "DL Networks", "l": "http://p2pool.dlnetworks.net:9332/static/", "v": 1 },
	"1Fd8RuZqJNG4v56rPD1v6rgYptwnHeJRWs": { "n": "FreeDomainRadio.com", "l": "http://freedomainradio.com/Donate.aspx", "v": 1 },
	"1FriLLFadyH4vb8vkuW3S7qHfVbhwvuAGX": { "n": "mykee", "l": "http://bitcoin-otc.com/viewgpg.php?nick=mykee", "v": 1 },
	"1M45CEmfdEQNE9kqgDGU2SoJdqhitdka3B": { "n": "Anonymous", "l": "http://bitcoinsgratis.tk/gastar/", "v": 1 },
	"12rPHS1yF8DWH3uLM4UJE9SFBBkWwAKA3E": { "n": "Bitcoins Norge", "l": "http://www.bitcoinsnorge.no", "v": 1 },
	"1JKvCnFEESTY2TvRsxy8ezisr198pLMDqZ": { "n": "OnionCloud", "l": "https://github.com/Miserlou/OnionCloud", "v": 1 },
	"1X2Y2aL1YkZPM4o3GmqcwsHe4Ez2jeKur": { "n": "X2Y2 Donations", "l": "http://xiaoer.tv/donation/", "v": 1 },
	"1C2j5YLgiEbMJigQ8VwMLPw2JstKjxtGDD": { "n": "Bitoomba Roulette 32,33,35,36", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"161bXZeVKhRfwyVdX9LT5Skr3Vei1jrNzX": { "n": "Bitoomba Roulette 31,32,34,35", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1E1tTng15Uv1yVUmJx1bSkFAraSXB3ZNes": { "n": "Bitoomba Roulette 29,30,32,33", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1LaKgDnUK9vWZb15b3QnMnnFuAmsMBx7YC": { "n": "Bitoomba Roulette 33,36", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"16EyvJsUB3Xa2XFQNaYDcJsWVbVcAAwwHq": { "n": "Bitoomba Roulette 32,35", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1Es9PWLDTcsngy8hwp1LW5ouge1dTPYeRV": { "n": "Bitoomba Roulette 28,29,31,32", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1PSy4xtvjxRuVZ2BZv6neSfnHoVhfoorUY": { "n": "Bitoomba Roulette 31,34", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"16FZX5bYPekgWp6VZpTxARk1sKDV5yXg5L": { "n": "Bitoomba Roulette 30,33", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"16PD8HgC96eRuZTMukQKYmJspEKPvqr3w2": { "n": "Bitoomba Roulette 29,32", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1LiaXWGFMKcRRZUh4mNGZN1EvrkJ4rMoTw": { "n": "Bitoomba Roulette 28,31", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1DpMjPpSxgzEn5oRoQWi1LbYQi4MoGbLrf": { "n": "Bitoomba Roulette 26,27,29,30", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1F21Akkp8FJSdHHo2DAEEY6Eztz6CPRTfm": { "n": "Bitoomba Roulette 25,26,28,29", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"19dtCmFP9guWAxdzdX5n2v9hjUhntQQ71J": { "n": "Bitoomba Roulette 27,30", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"17N4XJxFJJm5ntGSASPbEcP994Qge6UVbJ": { "n": "Bitoomba Roulette 26,29", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1MrqGUf1kgTss1S22h4R6aK5Ntu8oAJA1E": { "n": "Bitoomba Roulette 25,28", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1MruxQ1XFxXcbNZV4vgfgyMLb4tRNEaACj": { "n": "Bitoomba Roulette 23,26", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1MeUrX5Pwc6JqJ2GFZ9E3dYFwoVpNNQsT": { "n": "Bitoomba Roulette 23,24,26,27", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"18Acg48G5bGZbiNRVL6B8QUmnW8khAbwXH": { "n": "Bitoomba Roulette 22,23,25,26", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"12AJR1dXaXYeV3Z2tC14z61yB9Lx1jajSX": { "n": "Bitoomba Roulette 24,27", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1QBBn12Cg3toDWrWVCTTRW2573o3s9uAfQ": { "n": "Bitoomba Roulette 22,25", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1GgJ4XCsko24tDsSvNJxpjhJ1doJ1ntvCg": { "n": "Bitoomba Roulette 20,21,23,24", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"19oqmWKuwXaYKGR57iNZT2UBQ3rL8wjHDc": { "n": "Bitoomba Roulette 19,20,22,23", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1MAQgcbfaUthPzAnZz42EQyzwoocpA7ga3": { "n": "Bitoomba Roulette 21,24", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1AjDoECe8toZ7KWwUpDqtYGx6yxKFgukSV": { "n": "Bitoomba Roulette 20,23", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"17KSkdD1iyg2bxqgdgnM5dsK3p66P8iozg": { "n": "Bitoomba Roulette 19,22", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"18C5uSgtzcHV4xp3EdCMvhQ2RuHfUZB6gF": { "n": "Bitoomba Roulette 16,17,19,20", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1HLULqosQq95TgExaTN9BWbbX2ReGCMEFv": { "n": "Bitoomba Roulette 17,18,20,21", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1Krm34jy6yASGTggVuyNz6njuK1NBDEJnD": { "n": "Bitoomba Roulette - 18,21", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1E2emMNnXeryTs9Ss3SGcM2kHvLDBfqac6": { "n": "Bitoomba Roulette - 17,20", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1GYoTEHoVDZ7m6mhhDwmuWV4wkWTdAwZcJ": { "n": "Bitoomba Roulette 16,18", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1DMf8nxtNHnYbLZd81mKMVX4XjNxWvXmvo": { "n": "Bitoomba Roulette 14,15,17,18", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"13ZuoibPr6LDNboGtxDLoHStadxYAHqy4p": { "n": "Bitoomba Roulette 13,14,16,17", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"15xYDwgaXwqBUAwnLsEdXc8PbUrYaLGaFT": { "n": "Bitoomba Roulette 15,18", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1MSnok2Yj89rMLas658i8pX7Ku9NWok87R": { "n": "Bitoomba Roulette 13,16", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1N8dPgkKUzNrzUwvw59XphArtA5MW874h": { "n": "Bitoomba Roulette 14,17", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1BcEDVnqj1cAxFAFmAWJb8vHnrAS7nDghM": { "n": "Bitoomba Roulette 10,11,13,14", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"19J3impHYV1mtV2P8jgPzee7wpdzDd1T5r": { "n": "Bitoomba Roulette 11,12,14,15", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1LbbtCC3973akRJZ58buLYXB5GBWyJk2Uc": { "n": "Bitoomba Roulette - 10,13", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"15yorzWcmqRytsL8rQWiM93XNnhMn9mV1U": { "n": "Bitoomba Roulette - 12,15", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"16xSi54FUTtMA6KQ6K8zqvMmygvC5h9fPJ": { "n": "Bitoomba Roulette - 11,14", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1PKeL5CW5dsiLck5NVQx7C7ieV3p9QEcTo": { "n": "Bitoomba Roulette - 8,9,11,12", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"19VDkNcPgXtdDuC1VePRN6M1YEV6tnJDqQ": { "n": "Bitoomba Roulette - 7,8,10,11", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1D22VC8nnWKCqEGLJ1QAKuSbd1CjUybMBD": { "n": "Bitoomba Roulette - 9,12", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1As6aU3kNRHbrPUj1EdzbMpxqRw96fUSns": { "n": "Bitoomba Roulette - 8,11", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1GBK15WBWBzs965CvkFpdpM74DAfXhVNeF": { "n": "Bitoomba Roulette - 7,10", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1DuSbeRukCFBd1hnz9WB7UPFX6skyD67AF": { "n": "Bitoomba Roulette - 5,6,8,9", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1Bn4FbZcpo3L9AgMWgfHD9CzQ6k3BBJFfQ": { "n": "Bitoomba Roulette - 4,5,7,8", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1ZpuQUczD5AY1WcUKkAD9ZnLffAVopZHx": { "n": "Bitoomba Roulette - 6,9", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1MNGba3NpJw5L5vV7rrszztZdVBAaeQGuz": { "n": "Bitoomba Roulette - 5,8", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"13mHhRE1S71DR5JYfJu4WNBoL2Gy3zbnnN": { "n": "Bitoomba Roulette - 4,7", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"198M2TkVkotLgjmjbfyLrYj6HjH8h33Xf1": { "n": "Bitoomba Roulette - 2,3,5,6", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1HiXJ2hd6mS9e32Y8zDkjUtRbauiirBzKh": { "n": "Bitoomba Roulette - 1,2,4,5", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1E2Y2EUXFoS5ucGADffFa1HRnbQ7YAdEBP": { "n": "Bitoomba Roulette - 3,6", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1JvtUZgxAnELJMSA4AdaGo76FxURtC8HG8": { "n": "Bitoomba Roulette - 2,5", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1DG8RmpwrEinn58XGz33ajohCpSdm4AzL4": { "n": "Bitoomba Roulette - 1,4", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"12R6xDiRC8YDvqpj3zc9cuk2UbAMR2e3Zg": { "n": "Bitoomba Roulette - 35,36", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"13wTp9AkAiQCRNYQKsXrCx2JE7EZJEXBtD": { "n": "Bitoomba Roulette - 34,35", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1ED4ybp9BKuQSmhVjTBvtCYTv97iaqPqEg": { "n": "Bitoomba Roulette - 32,33", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1ET4YAWE5zoag12veqt9aKttN2YSR9inVN": { "n": "Bitoomba Roulette - 31,32", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1KV1eVCJUMdZQQfBQHRfezx8ANxfDPTXJV": { "n": "Bitoomba Roulette - 31-36", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1Gwq9xmATwGXLgynFEf8HcjE7DYmyesYLq": { "n": "Bitoomba Roulette - 31-34", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1Nnt4rS5ecgcBcc4en9td5uYsYc2i6VWo9": { "n": "Bitoomba Roulette - 29,30", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1K7TcyxCm3qXYLwPNL6AstWXwABPs8LiAC": { "n": "Bitoomba Roulette - 28,29", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1LY445hTo8NQC5WBhHQYEZqqdbJKP1QQ8M": { "n": "Bitoomba Roulette - 28-33", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"14K3yTsAmSNGoMmf4C8FpGiwagEeJhdNVn": { "n": "Bitoomba Roulette - 28-31", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"18LE5pyWoKUcxWFAxBBS1yKqg4TQv4MebN": { "n": "Bitoomba Roulette - 26,27", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1KefJRoQhHaXvcuBBSBvQUKFBiECLMQA3n": { "n": "Bitoomba Roulette - 25,26", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"14dV7cfXDcS9VrwE7JhaTa6caECDxWWPvy": { "n": "Bitoomba Roulette - 25-30", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"17LkoCbTFjxsoDPc7dLDFP4RaP2vymNb69": { "n": "Bitoomba Roulette - 25-28", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"15nJpYjybivzGEE7wEcCSgcv8dBURycgSK": { "n": "Bitoomba Roulette - 23,24", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1QWjF81DsinTVucQwae78jQk7mvCFXdtL": { "n": "Bitoomba Roulette - 22,23", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1FvZEF2JBpGnES4ja3swzUq9WyDoP7mzGd": { "n": "Bitoomba Roulette - 22-27", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1PuYkVMB5EJp3NEdfaKPboKA3sdGrJnYpF": { "n": "Bitoomba Roulette - 22-25", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"16dXYNQMhqFUisS5PDVUAN6JioNJhzq2LQ": { "n": "Bitoomba Roulette - 20,21", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"16okMTKAv7bGoKYf9nKSuVKkRzCyJn8fnz": { "n": "Bitoomba Roulette - 19,20", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1AGDjnxJvircJ2xxk51yjBwf4groNoUVsg": { "n": "Bitoomba Roulette - 19-24", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"132ccK44ZkfgiWKVDCejdn4gDr4Ja8G2gj": { "n": "Bitoomba Roulette - 19,22", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"14rTfvZgiWwdD9UT6m8agj6zDZRgTypTFm": { "n": "Bitoomba Roulette - 17,18", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1P48G8pV9TuuDuvk6mfX8GD6HwSB7aBeYu": { "n": "Bitoomba Roulette - 16,17", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"15VRc9xRpg2zb6gUvteqhrJaQmat3vH5wa": { "n": "Bitoomba Roulette - 16-21", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1H16fVjSgzUKZzqh5FD8iSLfCLNJP4VpYG": { "n": "Bitoomba Roulette - 16-19", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"19CL9Tw1WuFsXuUXMH5rwCuMCnL2JQQ37L": { "n": "Bitoomba Roulette - 14,15", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1KS2avVDG1aLaw5GnL5B7XftiJ9naf3ykR": { "n": "Bitoomba Roulette - 13,14", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"18TwTf3RQfWbPFZx5514j6FewSHNriKEkX": { "n": "Bitoomba Roulette - 13-18", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1G4RAVXfg4ywvtmJwhQukMqAVZuGWhBFJc": { "n": "Bitoomba Roulette - 13-16", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"17hGTd2CniAGUPMCDf4B4CuDZWbi9xdDKp": { "n": "Bitoomba Roulette - 10-13", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1FNL3R5mLh7WzbiGTiG5jhLrJQujWQKixV": { "n": "Bitoomba Roulette - 11,12", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"15RW1UFivtpYwa78gP3uL5qv8Rq8cUjdDU": { "n": "Bitoomba Roulette - 10,11", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1Htxyi2WrtHmGWJghgY1Jan1Z37SpeL3Fr": { "n": "Bitoomba Roulette - 8,9", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"14LAWzezKDmTFdRtR2YMEEwMMj5uLG3o4q": { "n": "Bitoomba Roulette - 7,8", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"14NibyajL1nr6rrVwoPNwv3PLAWzyn7tkS": { "n": "Bitoomba Roulette - 10-15", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1HUsL21vtBmP9wvKhwjcYUQhVn3Dc1dQ2f": { "n": "Bitoomba Roulette - 7-12", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"17GxQLv5Jw91ez3JGaQQZiTteDsrcFASFp": { "n": "Bitoomba Roulette - 7-10", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1E9LdGKW4L3HmatBZaE1oaRP4kuWZwAhpp": { "n": "Bitoomba Roulette - 5,6", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"19ttG4okP3anj1soVei9S57Sahj5yuRGCJ": { "n": "Bitoomba Roulette - 4,5", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1AB9TChVFFkZBF9QfvKba6hCvxbHtmQwJd": { "n": "Bitoomba Roulette - 4-9", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"19LjvjWmjRCtg4Vu813funC6kAR4C9yTCN": { "n": "Bitoomba Roulette - 4-7", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1DSegGzPGiacTwF88CDmrVT3b7AUik5SEs": { "n": "Bitoomba Roulette - 1-6", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1MbWY8XWRb9bMVFxJtbUM5ht3icSySjvrn": { "n": "Bitoomba Roulette - 2,3", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1Jsep3Hvzwqp4bXzjLHdJqyn5gg8d8iBzw": { "n": "Bitoomba Roulette - 1-4", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"14Nh8nGXoaPWeMZkgpbSMWYBF3EPsUXVAC": { "n": "Bitoomba Roulette - 1,2", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1QH4Qw439hUrEdafjUxXYThp1nLZW7MKzJ": { "n": "Bitoomba Roulette - 36", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"132RsMbEsR6q7Xgz45hitvYKsVkZDBmPXa": { "n": "Bitoomba Roulette - 35", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1Gg91xc58BWgJGxjdrwfrLKTCKB1Gv1ZMr": { "n": "Bitoomba Roulette - 34", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1N1r411rX3LvVyYCuBvzXqNAcpFgjh4xKX": { "n": "Bitoomba Roulette - 33", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1C3gP1DMVQaABLmy9sotmGtYWnVNSmaMQi": { "n": "Bitoomba Roulette - 32", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1ARJf2kLJW6B67DrKVXYaMXmxLAX8Hy259": { "n": "Bitoomba Roulette - 31", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"16KZNRzg6fcnzuEJDmRAJPZsZz2KBggeDR": { "n": "Bitoomba Roulette - 30", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"13ajDs3MeREt5P8WiNvz6erhCuZxQbWav1": { "n": "Bitoomba Roulette - 29", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"15q9UmmGbDDun5aHUCyHzNoAkw61hZmGvK": { "n": "Bitoomba Roulette - 26", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1L43Xm2c7jKTQKQHJ8uNtNoXRcFxRhZvqz": { "n": "Bitoomba Roulette - 25", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1PwLLT2NF4w6q72uRoCANnyLnAJUFAkFmB": { "n": "Bitoomba Roulette - 24", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1CRtSRej2pumFwPJUpbNF191WxZ9ZrgZ83": { "n": "Bitoomba Roulette - 28", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1EhB68aHS8DyWMAjKkXTyjBgQMzHkcFXR7": { "n": "Bitoomba Roulette - 23", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1KQtW85E2NZpAJuhxVcB4toLoLvJZ2e4jf": { "n": "Bitoomba Roulette - 27", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1EGP2yiwDZFPDXU6GVwBoA8AXhomknRrCp": { "n": "Bitoomba Roulette - 22", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1CcPcwK9h2czW7jXo7G6cEjHVeFCxqHkwX": { "n": "Bitoomba Roulette - 21", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1L9AfimyieyBeGYE6fTdGdZjTNektHYByE": { "n": "Bitoomba Roulette - 20", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1FBFrkTMYHA9jGbPAPde8aLzXn2NPFUDF8": { "n": "Bitoomba Roulette - 19", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"14HnToWhYC7zSpEsR39K9pWa6ohe9q1j6m": { "n": "Bitoomba Roulette - 18", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1JxAdZWJBhrpCa23p3p1zL2FAjcPWKGcau": { "n": "Bitoomba Roulette - 17", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1E7cSyQENCX8tLxEfuxMmD8pCMP4pqF3y8": { "n": "Bitoomba Roulette - 16", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"14H2U3tg3Vh7DJ39A8d6aSMFgvat63tmQU": { "n": "Bitoomba Roulette - 15", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1QBmwafhxGxmYCkCxYWzhhLjUtSQvuPWFu": { "n": "Bitoomba Roulette - 14", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"115jPC4FHqvUBp7jU8eADdt7wzEzzdTitF": { "n": "Bitoomba Roulette - 13", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1GqiWz7tywqWpTnFeoTuYHoitMZmwpdXUp": { "n": "Bitoomba Roulette - 12", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1BQE8K13vGJWo85zjBEf4WprrqHAcCkvF1": { "n": "Bitoomba Roulette - 11", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1ETBRS9Kj6RH9H4mL93qLA8FfAaZ6sG62o": { "n": "Bitoomba Roulette - 10", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"13yjZPdKZ42Jd6oQT78R8Qna64GRdicsvm": { "n": "Bitoomba Roulette - 9", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1NTquTDRbtovwH55Uh1NVqYfF3WfKWNGhr": { "n": "Bitoomba Roulette - 8", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"18nd1vK4VrRadKJJTFU58SaGLjgVo2qdRy": { "n": "Bitoomba Roulette - 7", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1MLdncLHEuopGfrfb9wNEC9qF1awc7WvCu": { "n": "Bitoomba Roulette - 6", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1CUgGvScTPNPhsCk7dNVXmtZg2xZqdJEnH": { "n": "Bitoomba Roulette - 5", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"15JL3AErrPyh1X82MQ64eUKxuoGEVb5wpW": { "n": "Bitoomba Roulette - 4", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1JAyvXNmrXeCkgeE7V1YdHnDoHRqwpyhAr": { "n": "Bitoomba Roulette - 3", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"18nuT3SRcBD793MHsG7GHnXNW8r6EAEkPz": { "n": "Bitoomba Roulette - 2", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1PTCFd1ZZL8bYE6UmkDfXRuesQrYuUEfcX": { "n": "Bitoomba Roulette - 1", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1D2HNyvHLZtHLM3Q9TP3VKeceaNsueEiwH": { "n": "Bitoomba Roulette - 0", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"15HxMKouD6nYctDuMa56cZtbgw8ZLUZEcr": { "n": "Bitoomba Roulette - 3rd row", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1BEXudKbx8TvjknoU21x9SQ2WyaVrJ8pDW": { "n": "Bitoomba Roulette - 2nd row", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"16Uvxa2gx2d4R4HbJSq4YuRsAhSbxKDxAC": { "n": "Bitoomba Roulette - 1st row", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1APkCUuWhYiVUUd6mB2J5HuZKJvWGeF9LJ": { "n": "Bitoomba Roulette - 25-36", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"19yEKaHtH4Pqe8YwXn5bqPxmYnsyKu1wTo": { "n": "Bitoomba Roulette - 13-24", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"177xpnC8FsesF41TqFgZqJTY7wAkAuenk9": { "n": "Bitoomba Roulette - 1-12", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1BZiTk2tKV2P5NEcaMLi9nWqeaXdmp1Msy": { "n": "Bitoomba Roulette - 19-36", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1BuMqZqUsaYCrqbtpUN6eB4r9ckAHZCoeU": { "n": "Bitoomba Roulette - 1-18", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1JkHmkXUJpqYJ7U5DdNtxk8Di4qSayN2CZ": { "n": "Bitoomba Roulette - Odd", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1JRVPx88Tr7T9acZMVgz5phVWZeYVwUAXB": { "n": "Bitoomba Roulette - Even", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"17xYQRRPxmVQ42UxfMwLxykY84K7mXsvh9": { "n": "Bitoomba Roulette - Black", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"12ZyTyamVXm21G8X5MBKUTLxe1Ma8AvfFy": { "n": "Bitoomba Roulette - Red", "l": "http://www.bitoomba.com/roulette/strategies/", "v": 1 },
	"1D8yKvNVdmj9huWdazb3Adx9pGBDhxmjJN": { "n": "CGP Grey", "l": "http://www.reddit.com/r/CGPGrey/comments/1jcwh7/help_support_cgp_grey_on_subbable/cbdf52l", "v": 1 },
	"1CDjWb7zupTfQihc6sMeDvPmUHkfeMhC83": { "n": "tip KgBC on GitHub", "l": "https://github.com/KgBC", "v": 1 },
	"1P9caz1ZM67ySHY4tV9zKbNuVRkbwTHeRH": { "n": "Poemcraft", "l": "http://asoulinprogress.quasigentsia.com/", "v": 1 },
	"1DLqi9ZifvwipBqY3G2gfgd1WYwHSpLbjE": { "n": "DPP_", "l": "http://bitcoin-otc.com/viewgpg.php?nick=DPP_", "v": 1 },
	"1H7Xj9wt6aKiRsHrKjV8WE9Hk6S7zVDZqx": { "n": "BitcoinFaucet.TK", "l": "http://bitcoinfaucet.tk/", "v": 1 },
	"1N2BS4QEvokWzndD3e4mXpqxnJPjphKa7m": { "n": "Refractal.net Cygwin Mirror", "l": "http://cygwin.refractal.net/", "v": 1 },
	"1PQCrkzWweCw4huVLcDXttAZbSrrLbJ92L": { "n": "Linux Mint Donations", "l": "http://www.linuxmint.com/donors.php", "v": 1 },
	"1McKayQNGaKdkoJnhSLWHEtWW8t9hDpan4": { "n": "McKay Donations", "l": "https://www.doctormckay.com/donate.php", "v": 1 },
	"1HpVUGyw4kdktDMrrPzMLaX1nLm7ZRdff8": { "n": "alt229", "l": "http://alt229.com", "v": 1 },
	"13tgjejUJ6NtQVX9HvKz8svdcuWPNwgr5T": { "n": "fsf-replicant-android", "l": "http://replicant.us/", "v": 1 },
	"1McGoughQuFMLn2XeYY7EDV6CDgJ9J8TD5": { "n": "McGough", "l": "https://www.dropbox.com/s/yrffay11jxhmbpc/1McGoughQuFMLn2XeYY7EDV6CDgJ9J8TD5.txt", "v": 1 },
	"18qbfN3fZBzPu75KwFBQCbVJfDQkRAwEbr": { "n": "BitcoinSandInterestPayment", "l": "https://docs.google.com/document/d/1W76HmWVxd-XfLm95yI2G0hPIuYBNqSVJ80k7DnWwRXo/pub", "v": 1 },
	"1cfhobo7o6jbtUR7ZGgs9nBCG8qZkKmo7": { "n": "cornfeedhobo", "l": "http://bitcoin-otc.com/viewgpg.php?nick=cornfeedhobo", "v": 1 },
	"1MPRZxQr8PiEFmwNDzUhvNybkYF6oty84V": { "n": "Michcioperz", "l": "http://ijestfajnie.pl", "v": 1 },
	"1L6Xzog5krZ4KZF344NvGZMRpx2bND7ogE": { "n": "BitcoinsandInterestPayment", "l": "https://docs.google.com/document/d/1W76HmWVxd-XfLm95yI2G0hPIuYBNqSVJ80k7DnWwRXo/pub", "v": 1 },
	"1JfvCK3NAaKdQZCmu4vBjGhqAzxYrePsHg": { "n": "bitcoinsand", "l": "https://docs.google.com/document/d/1W76HmWVxd-XfLm95yI2G0hPIuYBNqSVJ80k7DnWwRXo/pub", "v": 1 },
	"1BitBuxAFVYvpJ7oRU84PJZNTYQsM2qUxV": { "n": "BitBucks", "l": "http://bitbucks.com/", "v": 1 },
	"1BLAxN8GcC2RZQvEXhg2Ppi2PSiWnQm82r": { "n": "BitChirp", "l": "https://bitchirp.org/about/", "v": 1 },
	"1P4uWNPAUJY8FZyWvbT3YANyWY577EYJPe": { "n": "OSEG Universal Prototyping Kit", "l": "http://wiki.opensourceecology.de/Universal_Prototyping_Kit/Bitcoins", "v": 1 },
	"1SATANwNtPht5aHdih5EN2FeurhXvvGqL": { "n": "SATAN", "l": "http://natas.pw", "v": 1 },
	"1Pieq28yVbVCnUEqHhvpnkX6eyEtM9BHbs": { "n": "jlgrobe", "l": "http://juliangrobe.com.ar/pagos/", "v": 1 },
	"12zRQui2E661MkJ4pMeBvUHJSoqVkwYYoj": { "n": "penis", "l": "http://vm-0.danieldaniel.koding.kd.io/t.html", "v": 1 },
	"16MFpynMuJRj16EqmuMZHF84D11bkS6nYs": { "n": "GitLab", "l": "http://gitlab.org/donate/", "v": 1 },
	"1925Vq4Yz14gpoo98ap9fswLpBG6Eu7GJM": { "n": "MY-BTC.INFO", "l": "http://my-btc.info/donate.php", "v": 1 },
	"1VBTCXXcYmUCzYUcmdcakSGdyavUnByFF": { "n": "Visual Bitcoin transactions", "l": "http://www.visualbtc.com", "v": 1 },
	"14vYm7Ba95GKoPDd243k9SF15z2ZjoLHK8": { "n": "BitTop100", "l": "http://www.bittop100.com/", "v": 1 },
	"1B9Ent8Fm7va445j4qdeyt54UVZAQhzRvG": { "n": "jprice", "l": "http://www.joshprice.net", "v": 1 },
	"1CSxAWeGvkXWc28shE2ndB3Z7tWg4uiYdR": { "n": "SerpCoin v1 (27 of 48)", "l": "http://lordoftime.info/?page_id=69", "v": 1 },
	"14wZEs1JLAnjgHU22ktHmyrLkbNvVinM6z": { "n": "SerpCoin v1 (3 of 48)", "l": "http://lordoftime.info/?page_id=69", "v": 1 },
	"19QasU7zRHQae7oFd5ogPXKRy1CFK3Qpob": { "n": "SerpCoin v1 (41 of 48)", "l": "http://lordoftime.info/?page_id=69", "v": 1 },
	"1BanXdTjFPk1fXsjYxj9tZx718D8PtuyHC": { "n": "Hail the Ban Rifle!", "l": "http://lordoftime.info/?page_id=69", "v": 1 },
	"1666xA8BhAz3csM5QMMZmV41wss6f8ZnQP": { "n": "666 IS EVIL", "l": "http://lordoftime.info/?page_id=69", "v": 1 },
	"1Lttg6yN6A9xwF2fYZ1neZ8JKGmzTBzuh5": { "n": "TimeLord Cold Storage", "l": "http://lordoftime.info/?page_id=69", "v": 1 },
	"16xAoiD7nqJ1q84M9xHZYYR54DNQCfVFcV": { "n": "Donate Bitcoin", "l": "http://paperstreetdiaries.com/donate/", "v": 1 },
	"1Ge6ubv3eHLQ8HcKtGhEMYX5urHPn3WMtL": { "n": "Bitcoin Oms", "l": "http://www.bitcoinoms.com", "v": 1 },
	"16V3xQnAzUVWbNLnt3cfkNwkCyF8Z2irSV": { "n": "", "l": "http://www.zeropage-media.com/contact", "v": 1 },
	"1Nameid3brhZrbTN1M7t6afMAfVBiGioJT": { "n": "NameID", "l": "http://nameid.org/", "v": 1 },
	"18Z8Gn1saWeLoJyLZrEttkYPiGAgTc8Xbd": { "n": "Spam is fun", "l": "https://gist.github.com/abrkn/5974658", "v": 1 },
	"1ETNVAgKT5RikQ6yRsS2TRKBJmmhc3goHc": { "n": "tagging test", "l": "https://gist.github.com/abrkn/48f21e9827a36d4151ec", "v": 1 },
	"1HhXEHQHgi4yfgyRKYbPZBxHirYMfN5cuJ": { "n": "Heml.is", "l": "https://heml.is/", "v": 1 },
	"1KoKp7uCaNjVQgtCRhKH71Mw7cU7pLG2Xi": { "n": "", "l": "https://jess.ursa.uberspace.de/about/", "v": 1 },
	"1DuKong1BAVkW8x6SPcG8gSduDgArJecuJ": { "n": "DuKong", "l": "http://www.flickr.com/people/dukong/", "v": 1 },
	"1riSHoDiEJYugSYzfzrDrdLDmi4MaLYqK": { "n": "Rishodi", "l": "http://bitcoin-otc.com/viewgpg.php?nick=Rishodi", "v": 1 },
	"1NtEdJka5vo2D7xT3NZnhkF2dBPMfhKMRe": { "n": "foo bar", "l": "http://blockexplorer.com/block/000000000000009f551f983270c009b24708539b507ac5e49baa07ccbb6f11ba", "v": 1 },
	"16vnh6gwFYLGneBa8JUk7NaXpEt3Qojqs1": { "n": "BTC-E API Donations", "l": "https://github.com/alanmcintyre/btce-api", "v": 1 },
	"13z3QCSe4Uuykg3isMEuCiwvvdggwgF7Wd": { "n": "P-Lib Spanish Political Party", "l": "http://www.p-lib.es/bitcoin/", "v": 1 },
	"1LunaKViDsLzE4QZzzfPKhMuytogGQy9RV": { "n": "OTC Luna", "l": "http://bitcoin-otc.com/viewgpg.php?nick=Luna", "v": 1 },
	"1BLazedp2eGDrDM3NMbxkn7n4PCCk6WYVX": { "n": "Blazedout419", "l": "http://bitcoin-otc.com/viewgpg.php?nick=Blazedout419", "v": 1 },
	"1DrTenX8izz6WM3sJhN1RYSEHjwN6tn5f3": { "n": "TheLordOfTime", "l": "http://bitcoin-otc.com/viewgpg.php?nick=TheLordOfTime", "v": 1 },
	"16NY1ES69g5EaRLXqQ69d9KsHmyuW8Lbc9": { "n": "Free Bitcoins! Bitcoinboosting", "l": "http://bitcoinboosting.com/", "v": 1 },
	"1CYmbMpRWTcdE3UVvA8SoRNXojopY6rz6z": { "n": "Just-Dice.com Hot Wallet", "l": "https://just-dice.com/", "v": 1 },
	"14Fu4z4EBmX8Lq7H3whG9bUJFLAdBDEevY": { "n": "Just-Dice.com Online Storage", "l": "https://just-dice.com/", "v": 1 },
	"1KuanYmTGKQEa18D21HKUa9NUcZENZSyDc": { "n": "asd", "l": "http://blockexplorer.com/block/00000000000000b791d0ba88d81d13fd57881aaea4a1413782a32ba2915363b8", "v": 1 },
	"1GPBWd8C4e6JD7wDWV3YxMuTDzH1Vy3mf6": { "n": "bitcoinmalaysia", "l": "http://bitcoinmalaysia.com/contact/", "v": 1 },
	"1CaptChA27J4pdWn4Ed4ePakDz5Eh4RZsH": { "n": "CaptchaCoin Faucet", "l": "http://www.captchacoin.com", "v": 1 },
	"1EqUvWsahsvo3oxYaahtSKKJnoz6WnDC72": { "n": "Donate Bitcoins", "l": "http://www.xogger.org", "v": 1 },
	"1MnKnd2t7Tfpy1Cs8bm5DraC9HzrHmHoso": { "n": "Bitcoin Escrow", "l": "http://www.bitescrow.org", "v": 1 },
	"1AutomatLx3AxZSs1CBt47SGRcouaCQmko": { "n": "Bitcoin Vending Machine", "l": "http://bitcoin.ars.is", "v": 1 },
	"1NastyFRkeUTmMdbMmzggDVTQA6r3ibUoX": { "n": "NastyFans.org", "l": "https://www.nastyfans.org/about", "v": 1 },
	"1QJoVSaYwWaev1SXYFiE1qaZAhC1orS3s": { "n": "Hank????Bitcoin", "l": "http://hsnu109128.blogspot.tw/2013/04/bitcoin_22.html", "v": 1 },
	"18uEELkxZMtDCUPVKrXJN73D7nFBTDZyuM": { "n": "Hank Bitcoin Consultant ?????", "l": "http://hsnu109128.blogspot.tw/2013/06/bitcoin.html", "v": 1 },
	"1L58XKm3ALgFEDHumAEDDgxd8d5JBQyZPa": { "n": "Bitcoin ???????", "l": "http://hsnu109128.blogspot.tw/2013/06/bitcoin.html", "v": 1 },
	"1JfUAeJ8R5jRVx6AqWKXz8SjeYCBnG5t2Z": { "n": "SatoshiBet", "l": "https://satoshibet.com", "v": 1 },
	"14o7zMMUJkG6De24r3JkJ6USgChq7iWF86": { "n": "Just-Dice.com Cold Storage", "l": "https://just-dice.com/", "v": 1 },
	"1Dch7ZW9SBWyypYUoemRDYn9tvFpDxAt78": { "n": "derekleong75", "l": "http://sgminingconsortium.wordpress.com", "v": 1 },
	"14rDamyE53BNLPSj4cku6ZXiW6xbBdMJ97": { "n": "GPGTools", "l": "https://gpgtools.org/donate.html", "v": 1 },
	"12oNDcYKQgH3QTMm2rChMC4a6FdQC65wLb": { "n": "Lambda Fairy", "l": "http://lfairy.github.io/", "v": 1 },
	"1HsaPhVwXJ2jwaNLhCu7bwjUX3pNhLeFW6": { "n": "RapCAD Donations", "l": "http://gilesbathgate.com/about/", "v": 1 },
	"1NVMCeoBfTAJQ1qwX2Dx1C8zkcRCQWwHBq": { "n": "Gimp.org", "l": "http://www.gimp.org/donating/", "v": 1 },
	"1NoteJpV8nA2TD5QhDYbvM6CLaGQNgyYmJ": { "n": "GotoNote - Free bitcoins!", "l": "http://gotonote.site90.net/", "v": 1 },
	"1domobKsPZ5cWk2kXssD8p8ES1qffGUCm": { "n": "domob", "l": "http://www.domob.eu/donate.php", "v": 1 },
	"158LLTVQRtmLD5d9xFfSe8eNCmyssppE3q": { "n": "BitcoinMoxy.com", "l": "http://bitcoinmoxy.com", "v": 1 },
	"1QBykYpXajTybj8Zxf4zggNNKJaUCwRm8K": { "n": "BitFond.com", "l": "http://www.bitfond.com", "v": 1 },
	"1FbitsRZvASRdGLtfK8Wd8NMdNipxNjdrd": { "n": "[BitcoinFirstbits.com]", "l": "http://bitcoinfirstbits.com/", "v": 1 },
	"1GdZYon1Nx8vCB3m3n42skmzf1fxnk3gzx": { "n": "pthree.org", "l": "http://pthree.org/donate/", "v": 1 },
	"1MBPw2DGg6goZBeChCyR7o8xXoeafa7Xbj": { "n": "texasnode.mybtcstore.com", "l": "http://texasnode.mybtcstore.com", "v": 1 },
	"1NASTYfxUpKPwin7b1KTBFjeeofrLSgXDJ": { "n": "NASTY MINING", "l": "https://nastyfans.org/about", "v": 1 },
	"1TuLLyiYD275CJZdQTRddat1D8Fr7yYTZ": { "n": "House Tully of Riverrun", "l": "http://www.reddit.com/r/Bitcoin/comments/1fun2g/the_great_savings_houses_of_westeros/", "v": 1 },
	"1GreyjoywA4Add9jHSxUw6ubMSfVzXD5Z": { "n": "House Greyjoy of Pyke", "l": "http://www.reddit.com/r/Bitcoin/comments/1fun2g/the_great_savings_houses_of_westeros/", "v": 1 },
	"1Arryn1ZV1vLLt1449RUcLZbtozAQMWiAu": { "n": "House Arryn of the Eyrie", "l": "http://www.reddit.com/r/Bitcoin/comments/1fun2g/the_great_savings_houses_of_westeros/", "v": 1 },
	"1MarteLLc7jC3Ju7WFgYZTDgZwRXYyDJTx": { "n": "House Martell of Sunspear", "l": "http://www.reddit.com/r/Bitcoin/comments/1fun2g/the_great_savings_houses_of_westeros/", "v": 1 },
	"1TyreLLjBHHsecd485fjjtTGrhFbdkPXF": { "n": "House Tyrell of Highgarden", "l": "http://www.reddit.com/r/Bitcoin/comments/1fun2g/the_great_savings_houses_of_westeros/", "v": 1 },
	"1EZrRLKHv8yeuRu53j3djwgyhnzMHYBRvC": { "n": "CFM Faucet", "l": "http://cfm.crayeo.com/coin/faucet", "v": 1 },
	"17orEh51ab8HoU7g8Ezwcp76jCpeL7PabJ": { "n": "Blender Foundation", "l": "http://www.blender.org/blenderorg/", "v": 1 },
	"1Stark7Zbfy1c18CdGdSqrJQtMpXcKSvS": { "n": "Stark of Winterfell", "l": "http://www.reddit.com/r/Bitcoin/comments/1fun2g/the_great_savings_houses_of_westeros/", "v": 1 },
	"1NAfx5GEZHR8t69LjxTeShPP4XXaxeUqQw": { "n": "prism-break.org", "l": "http://prism-break.org/", "v": 1 },
	"1KCckA5MQDHoJwS9Mi9bGknAYz6LqXj5rv": { "n": "Life On Bitcoin", "l": "http://lifeonbitcoin.com/donate/", "v": 1 },
	"1ErcSeqE6pdhAW67rgTgy2EJo1uMCZjiWn": { "n": "Green Money", "l": "http://zoldpenz.com", "v": 1 },
	"189tfJJhCJFtkr4MZJgcB3yuGTfUh7cvUL": { "n": "Bitcoin Education Project", "l": "https://www.udemy.com/bitcoin-or-how-i-learned-to-stop-worrying-and-love-crypto/", "v": 1 },
	"18hxBDXri3hMqa9G7Rb8Y3aRRm8E1DPa4a": { "n": "wendelinen", "l": "https://www.flashback.org/u760178", "v": 1 },
	"1va4sqj5AFnMYicD7JzhDfxauk5w6Uuug": { "n": "bitcoin_news_donations", "l": "http://bitcoin.gw.gd/", "v": 1 },
	"14cBNrTYW9XCnYhJqJ9ooAMzz7zAnojWaz": { "n": "KNOWN SCAMMER - KRUNIAC", "l": "http://hastebin.com/raw/kijavudera", "v": 1 },
	"18hmynLnHC44XiGiiPqfuTL3M4xPeJ5KqW": { "n": "TorChat", "l": "https://github.com/prof7bit/TorChat", "v": 1 },
	"1BCpU4frq4kmoc7JPtoNDqvEf4rcUDRPYf": { "n": "HoB Straight 1", "l": "http://houseofbitcoins.com", "v": 1 },
	"12yauWVWaxKKSUZPm2cmd2uTrepzrbceuq": { "n": "HoB Straight 2", "l": "http://houseofbitcoins.com", "v": 1 },
	"16MkWYTqQeXFEhePaS1WLqKZb1ZfC2vN9h": { "n": "HoB Straight 3", "l": "http://houseofbitcoins.com", "v": 1 },
	"1ASezxvygetQpa6j8WtGG7DTKSF4pJSWcs": { "n": "HoB Straight 4", "l": "http://houseofbitcoins.com", "v": 1 },
	"179xNd8RqLzcwHZ8xDzbvTsZDuefPpMybG": { "n": "HoB Straight 5", "l": "http://houseofbitcoins.com", "v": 1 },
	"15hHAGktBNNWPS8czTpijwYTCxcQQkf6TV": { "n": "HoB Straight 6", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CKLZMsQs6zmJjXLNMB6DzwQ7X3quWoaSm": { "n": "HoB Straight 7", "l": "http://houseofbitcoins.com", "v": 1 },
	"1FNNQ8LGhkKk1CKYq2UKYZoa8P8X5wi6iz": { "n": "HoB Straight 8", "l": "http://houseofbitcoins.com", "v": 1 },
	"1fG2647fYVzGF8gRruMDk4F5iaYibwrc9": { "n": "HoB Straight 9", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CVHJDLtFDjkPkHTVxtjeYZU9rhxSrz8b6": { "n": "HoB Straight 10", "l": "http://houseofbitcoins.com", "v": 1 },
	"15FJwb8SEiZZYGqhG19dHcNACrEQM3ovwh": { "n": "HoB Straight 11", "l": "http://houseofbitcoins.com", "v": 1 },
	"15Fa8TXe7N4pkbQBMY28csbzTJaecx5eeM": { "n": "HoB Straight 12", "l": "http://houseofbitcoins.com", "v": 1 },
	"1AvSRzHuZ9eDqXovNVMe62DCzrj8XvTYwH": { "n": "HoB Straight 13", "l": "http://houseofbitcoins.com", "v": 1 },
	"1NeLxeTeCbcN37YFhwXq6buSxdtyn1ENvh": { "n": "HoB Straight 14", "l": "http://houseofbitcoins.com", "v": 1 },
	"1LMFNx6d7rbAjzX9Za2FXVsqKhYoJUgHq9": { "n": "HoB Straight 15", "l": "http://houseofbitcoins.com", "v": 1 },
	"17g5BybvHVEuuviAubAMxdVSAnrrmX1Pxj": { "n": "HoB Straight 16", "l": "http://houseofbitcoins.com", "v": 1 },
	"1L9kyjQf9Ji7mDxnyKNBi3YEgFbcVmTarv": { "n": "HoB Straight 17", "l": "http://houseofbitcoins.com", "v": 1 },
	"1HAPZn71uz2V4FEip6Bs8fAtKQoKLVp9d2": { "n": "HoB Straight 20", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CeDRaJxPcJb5eKDHCP7sjDdJkC6EgnUSe": { "n": "Powercoin", "l": "http://powercoin.co/faq", "v": 1 },
	"12fFFK1WTGwnfYNwUbuVYUTy2QW6mx64MT": { "n": "HoB Straight 18", "l": "http://houseofbitcoins.com", "v": 1 },
	"13NZBsT5jPZAQVYPpbVH1EDT32wUR9nWLd": { "n": "HoB Straight 21", "l": "http://houseofbitcoins.com", "v": 1 },
	"1EYsPYpWXqPEitvpnygcqQSkiEtoUn4xdS": { "n": "HoB Straight 19", "l": "http://houseofbitcoins.com", "v": 1 },
	"1NPN4UrBnCvasAKuconXz8L382GimtNyHQ": { "n": "HoB Straight 22", "l": "http://houseofbitcoins.com", "v": 1 },
	"1Phd1PgXtPJDNLGXGhnDiMd9u8RbERmPYQ": { "n": "HoB Straight 23", "l": "http://houseofbitcoins.com", "v": 1 },
	"1LfTvgetwRrTtT9dxvhJSuhSgDqzDbJcYh": { "n": "HoB Straight 24", "l": "http://houseofbitcoins.com", "v": 1 },
	"14DFY9UwDoKHud2erGxY83fy7ChawWwspg": { "n": "HoB Straight 25", "l": "http://houseofbitcoins.com", "v": 1 },
	"1UkoVd4wuvDavEMse3CjYfsbx7HRg39nL": { "n": "HoB Straight 26", "l": "http://houseofbitcoins.com", "v": 1 },
	"1LBmbAGzdYJWJzFoaiCyvThZ4ac7dV3Div": { "n": "HoB Straight 27", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CsyPmV2pi3Ry5pxGoSFRE82spzEWeahaB": { "n": "HoB Straight 28", "l": "http://houseofbitcoins.com", "v": 1 },
	"1PiZXskigAnjz2PFA8JYxy9zpNpTn9KSmX": { "n": "HoB Straight 29", "l": "http://houseofbitcoins.com", "v": 1 },
	"1NXNBomQ54pEsADTog6dAotiqfPPsUHKMG": { "n": "HoB Straight 30", "l": "http://houseofbitcoins.com", "v": 1 },
	"14HWr9cuZCB6TuDejaVcbreBBRUe3BDECC": { "n": "HoB Straight 31", "l": "http://houseofbitcoins.com", "v": 1 },
	"1ARh2WvZrR7fDSMtfNy3mVQRc86FPYD2Ez": { "n": "HoB Straight 32", "l": "http://houseofbitcoins.com", "v": 1 },
	"19NA7SbLNJFcByfX92jVz4VT1wSPsT26w2": { "n": "HoB Straight 33", "l": "http://houseofbitcoins.com", "v": 1 },
	"1NZEdq3PdmUTRN6zvebf6KXdpKbXuxB6fm": { "n": "HoB Straight 34", "l": "http://houseofbitcoins.com", "v": 1 },
	"1HjR37pQBKzHD3kXGFouRLostbFNSuiQYD": { "n": "HoB Straight 35", "l": "http://houseofbitcoins.com", "v": 1 },
	"18s52vG5ns3LrrhgCeShzmCLtzXLXTfXqB": { "n": "HoB Straight 36", "l": "http://houseofbitcoins.com", "v": 1 },
	"17NCTNMbWAyUUdTMMgUemdE7XDJpVUmd8b": { "n": "HoB Straight 0", "l": "http://houseofbitcoins.com", "v": 1 },
	"1h4vkUjEDpdqX2sjd6PwLPMXNU4cE7TxQ": { "n": "HoB Straight 00", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CSkYtZGCWBqA6Eyvovs2BYeJk9CTtMJDQ": { "n": "HoB Split 1 &amp; 2", "l": "http://houseofbitcoins.com", "v": 1 },
	"1PHTtHFJFrqiyyx1Y8z3L1zL1GUjkztca7": { "n": "HoB Split 2 &amp; 3", "l": "http://houseofbitcoins.com", "v": 1 },
	"13bDWTnwWXDz7CkjRudyBZjiL7RVzJejJ8": { "n": "HoB Split 1 &amp; 4", "l": "http://houseofbitcoins.com", "v": 1 },
	"1PtsPmdGs77cG8r9PWRyuMgQ4YBmAdFiBX": { "n": "HoB Split 2 &amp; 5", "l": "http://houseofbitcoins.com", "v": 1 },
	"1B25TmZzspabUoHjYBnbtuPQkMR5bZXUwn": { "n": "HoB Split 3 &amp; 6", "l": "http://houseofbitcoins.com", "v": 1 },
	"14mRb9ZuGtSsDYW9Jphj9jWxnYyBaRm2Tp": { "n": "HoB Split 4 &amp; 5", "l": "http://houseofbitcoins.com", "v": 1 },
	"15zszPckgCeUTkRapc3WnznFiqGTYmRER8": { "n": "HoB Split 5 &amp; 6", "l": "http://houseofbitcoins.com", "v": 1 },
	"17UbZKfpbHVUPMgRaUZxPcNRydxEyUKN9D": { "n": "HoB Split 4 &amp; 7", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CE1ijz62wEkL23Qiaws2Vkd1PULnxK8R6": { "n": "HoB Split 5 &amp; 8", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CG6pS4gpeKfGQ4sFYFni5eRJTQGPoTFPo": { "n": "HoB Split 6 &amp; 9", "l": "http://houseofbitcoins.com", "v": 1 },
	"18xWHH5j15dVREeSc1VNrccnXdF5hWitF7": { "n": "HoB Split 7 &amp; 8", "l": "http://houseofbitcoins.com", "v": 1 },
	"1NDY8N52dXwnRvNFFt5HNtdCP99ZGz3gfp": { "n": "HoB Split 8 &amp; 9", "l": "http://houseofbitcoins.com", "v": 1 },
	"1224VoxLzCiyNWZwbNnCFMAeeqGPYZ326S": { "n": "HoB Split 7 &amp; 10", "l": "http://houseofbitcoins.com", "v": 1 },
	"1HLQsMGZbQDyuCdMd9N4H2MmLNYwxBJRSD": { "n": "HoB Split 8 &amp; 11", "l": "http://houseofbitcoins.com", "v": 1 },
	"1PAUpRZ7pratLLvh9nPCVN8vtXqVJv63a": { "n": "HoB Split 9 &amp; 12", "l": "http://houseofbitcoins.com", "v": 1 },
	"1G9eCkzVbq49ysAXBS6SbjVgZSXEAQYUpW": { "n": "HoB Split 10 &amp; 11", "l": "http://houseofbitcoins.com", "v": 1 },
	"15vKUCfT7Xp6fFp59xz7ai4RyL814d2oAN": { "n": "HoB Split 11 &amp; 12", "l": "http://houseofbitcoins.com", "v": 1 },
	"1K6mEty22zCwbARJyU4jfpNnPQGL28qUue": { "n": "HoB Split 10 &amp; 13", "l": "http://houseofbitcoins.com", "v": 1 },
	"1AeiixYkqDnVm9otmZABVxJiAYnCYQ6haP": { "n": "HoB Split 11 &amp; 14", "l": "http://houseofbitcoins.com", "v": 1 },
	"1QARwxLzUWLxBToD1g6FV8dSZfVAdRCthU": { "n": "HoB Split 12 &amp; 15", "l": "http://houseofbitcoins.com", "v": 1 },
	"14DUAh5XnWkzkHC8JrqFHi9Q3SdxB2SzKV": { "n": "HoB Split 13 &amp; 14", "l": "http://houseofbitcoins.com", "v": 1 },
	"1KGjFcZzgS9Qr2tcmK3iQJ3BF7eyamNEMC": { "n": "HoB Split 14 &amp; 15", "l": "http://houseofbitcoins.com", "v": 1 },
	"1BCVvUSjV5CNARRYhK2vK9F7seaiSyFFCE": { "n": "HoB Split 13 &amp; 16", "l": "http://houseofbitcoins.com", "v": 1 },
	"115h6x6d858g8B3hzeuG15rB3LYndQ4hGM": { "n": "HoB Split 14 &amp; 17", "l": "http://houseofbitcoins.com", "v": 1 },
	"16AXdfVS1EafdqAVwFscTqA2e88jjeFCJs": { "n": "HoB Split 15 &amp; 18", "l": "http://houseofbitcoins.com", "v": 1 },
	"1EHLkYtXQPfghvhmuCNLAtNqDq657hdjmy": { "n": "HoB Split 16 &amp; 17", "l": "http://houseofbitcoins.com", "v": 1 },
	"1GjTGUZuhx6nabEiR1nTP6jq27GNeuYxCR": { "n": "HoB Split 17 &amp; 18", "l": "http://houseofbitcoins.com", "v": 1 },
	"1H5NxtyDk1iU6XAJxEGJwd9QYqZQ7Q2YSM": { "n": "HoB Split 16 &amp; 19", "l": "http://houseofbitcoins.com", "v": 1 },
	"1An57JjjyEk67FsaZSsSCSUy1xhCQZeN5Q": { "n": "HoB Split 17 &amp; 20", "l": "http://houseofbitcoins.com", "v": 1 },
	"18RdtmoHfA6zHQva74Jooywyxg97C3LfJx": { "n": "HoB Split 18 &amp; 21", "l": "http://houseofbitcoins.com", "v": 1 },
	"18ERor9kt369k4r7ekxgDuGdBQVLnyjCUC": { "n": "HoB Split 19 &amp; 20", "l": "http://houseofbitcoins.com", "v": 1 },
	"1rqEKcvoTzV73htmqXLnKjaexy9odMRTR": { "n": "HoB Split 20 &amp; 21", "l": "http://houseofbitcoins.com", "v": 1 },
	"1NwVDMeon8RdTUMtmr7rPqFXmNJTJEtafV": { "n": "HoB Split 19 &amp; 22", "l": "http://houseofbitcoins.com", "v": 1 },
	"15Khtx8hNex8Xd6dGR7XmzWmbGLdVLFi8U": { "n": "HoB Split 20 &amp; 23", "l": "http://houseofbitcoins.com", "v": 1 },
	"1GEedTStCWYypPRhcshopjvBiGnREG3xVF": { "n": "HoB Split 21 &amp; 24", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CJYzbzuurGXGLiF8i5moWxAkh4KLBHppW": { "n": "HoB Split 22 &amp; 23", "l": "http://houseofbitcoins.com", "v": 1 },
	"16Nx1B2GNafSBz5Zzm9ZjRUZXkQX9G3ZNB": { "n": "HoB Split 23 &amp; 24", "l": "http://houseofbitcoins.com", "v": 1 },
	"17fpj1xVesN6JSzvtb7wyAG7waVzLEgAo5": { "n": "HoB Split 22 &amp; 25", "l": "http://houseofbitcoins.com", "v": 1 },
	"19pgkxGh7GC1eKWRCDye71PABgg8X6auq3": { "n": "HoB Split 23 &amp; 26", "l": "http://houseofbitcoins.com", "v": 1 },
	"176SJ7VAnzUKfZybWGM66NmS2hAugRykAN": { "n": "HoB Split 24 &amp; 27", "l": "http://houseofbitcoins.com", "v": 1 },
	"1Pz5HcfERh2RmXEaErWLy4k8wwZV2d3WNM": { "n": "HoB Split 25 &amp; 26", "l": "http://houseofbitcoins.com", "v": 1 },
	"1HYLH5y7VDJBb8coaSUbBpxFypMCZDodLJ": { "n": "HoB Split 26 &amp; 27", "l": "http://houseofbitcoins.com", "v": 1 },
	"1BvzrPcGHT2xFE5SeNbJvbEzGm1GviRJQ1": { "n": "HoB Split 25 &amp; 28", "l": "http://houseofbitcoins.com", "v": 1 },
	"16mrSZRZoqcWATGnxqQDGLCgDUP5wz57BW": { "n": "HoB Split 26 &amp; 29", "l": "http://houseofbitcoins.com", "v": 1 },
	"17dNhSGjutYJNrTs7Gco4XRhsfhXPq5tjz": { "n": "HoB Split 27 &amp; 30", "l": "http://houseofbitcoins.com", "v": 1 },
	"19RNwa9N3yUGaXhpZtQ1cdbCGS66vL673L": { "n": "HoB Split 28 &amp; 29", "l": "http://houseofbitcoins.com", "v": 1 },
	"19EcbEnfemzNFHcP4FSgnKrgtEXjcWeBtY": { "n": "HoB Split 29 &amp; 30", "l": "http://houseofbitcoins.com", "v": 1 },
	"1PUQ1z159ti57CzhcpJvHPcHsoFTbWrbVH": { "n": "HoB Split 28 &amp; 31", "l": "http://houseofbitcoins.com", "v": 1 },
	"19sARmLW9DqJRNhUWfRSTigaXBdgkyuuGu": { "n": "HoB Split 30 &amp; 33", "l": "http://houseofbitcoins.com", "v": 1 },
	"1FmGNQayyyQfU72ysBZyaDV5aYgFaHND1U": { "n": "HoB Split 29 &amp; 32", "l": "http://houseofbitcoins.com", "v": 1 },
	"1KJ4hMtphznAHbEws8FGi84aEdsyEppdXG": { "n": "HoB Split 31 &amp; 32", "l": "http://houseofbitcoins.com", "v": 1 },
	"1E4TvKhmuFy4sfHeNQD5BkkcmCfqnexrxW": { "n": "HoB Split 32 &amp; 33", "l": "http://houseofbitcoins.com", "v": 1 },
	"1MtC1fSeWJ2RkauuFjDs78KYiDWhArA3tk": { "n": "HoB Split 31 &amp; 34", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DSEmvp9G9w5ja55TrLujVcC4phnnKELLk": { "n": "HoB Split 32 &amp; 35", "l": "http://houseofbitcoins.com", "v": 1 },
	"18KidRqCgK4zBLFgBGvEiEvATVjpJiuwRq": { "n": "HoB Split 33 &amp; 36", "l": "http://houseofbitcoins.com", "v": 1 },
	"1PRPJLeCwCBECLBfASYSoX3LWyRXSGbFZd": { "n": "HoB Split 34 &amp; 35", "l": "http://houseofbitcoins.com", "v": 1 },
	"1HwAPMQU7DmiByYnW5PHL43igoxCztNoYr": { "n": "HoB Split 35 &amp; 36", "l": "http://houseofbitcoins.com", "v": 1 },
	"16aoL26NNtfGiQpv9H3KNEVq7siS5CCgPw": { "n": "HoB Split 0 &amp; 00", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DPkcbDEj59FDzg9fXHwLZSLur9PAZwKyy": { "n": "HoB Corner 1, 2, 4, 5", "l": "http://houseofbitcoins.com", "v": 1 },
	"1JXhh1mPPg4uPDUYa9inUGCRXUULmbvXvG": { "n": "HoB Corner 2, 3, 5, 6", "l": "http://houseofbitcoins.com", "v": 1 },
	"114BgnrDDL22mrT81fMqbEVqxSAUXTjRJs": { "n": "HoB Corner 4, 5, 7, 8", "l": "http://houseofbitcoins.com", "v": 1 },
	"18u1wztEQWAa6XBDrb3u1HkZud3EvLKxwo": { "n": "HoB Corner 5, 6, 8, 9", "l": "http://houseofbitcoins.com", "v": 1 },
	"1BEvsYyw6e4kagBoJdLmDmJ1VbDE2X5n39": { "n": "HoB Corner 7, 8, 10, 11", "l": "http://houseofbitcoins.com", "v": 1 },
	"1NYxFtQL7NYBerL1F5BEHBe3QtX1DuzkFq": { "n": "HoB Corner 8, 9, 11, 12", "l": "http://houseofbitcoins.com", "v": 1 },
	"1EoBDbhuN1vNCfnohVEvBNX7zxwMhJmSFw": { "n": "HoB Corner 10, 11, 13, 14", "l": "http://houseofbitcoins.com", "v": 1 },
	"12TGzEF3C6Stp18zQdiMUjamyAPro2tu8U": { "n": "HoB Corner 11, 12, 14, 15", "l": "http://houseofbitcoins.com", "v": 1 },
	"1KTY7VB2w2Jp6cSynxdqsB5iN9zNUhi4do": { "n": "HoB Corner 13, 14, 16, 17", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CsXFmefpLTUd6YTicE97rubcrH6Cwvp46": { "n": "HoB Corner 14, 15, 17, 18", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DQkMkaewgtuqr5gHmyXb7TASsi146j2VS": { "n": "HoB Corner 16, 17, 19, 20", "l": "http://houseofbitcoins.com", "v": 1 },
	"1JPQNdfdRJY4gCFD18H5av7u9zRMso32D6": { "n": "HoB Corner 17, 18, 20, 21", "l": "http://houseofbitcoins.com", "v": 1 },
	"19QU6Aqw4WXrETrBTkSb7MiVxZ1kdDAY9c": { "n": "HoB Corner 19, 20, 22, 23", "l": "http://houseofbitcoins.com", "v": 1 },
	"1FrozcvSmjFrs8UnMSKXUTkQQX4KhscsvW": { "n": "HoB Corner 20, 21, 23, 24", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DsMvpnApQ1knEUYwYfPMPWAshJ41yzUrB": { "n": "HoB Corner 22, 23, 25, 26", "l": "http://houseofbitcoins.com", "v": 1 },
	"1EibozK5n8LwgpLGLcZQ7pLk4xLALJU8Sv": { "n": "HoB Corner 23, 24, 26, 27", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DG5KFdEhHDaWwE5v3ZBAMAfUgPaDb3sLB": { "n": "HoB Corner 25, 26, 28, 29", "l": "http://houseofbitcoins.com", "v": 1 },
	"1M3rNQB2qiXiYjnKG9J7QvybRoLyBsN63y": { "n": "HoB Corner 26, 27, 29, 30", "l": "http://houseofbitcoins.com", "v": 1 },
	"1MNY5ikP5otas4szGYfttdC8Vi1xmm6bn3": { "n": "HoB Corner 28, 29, 31, 32", "l": "http://houseofbitcoins.com", "v": 1 },
	"1BVGrV13AyeUsPVWEC3sZ6PoqGwTRePQA7": { "n": "HoB Corner 29, 30, 32, 33", "l": "http://houseofbitcoins.com", "v": 1 },
	"1QJXTSrFdozQWWMM7Gna9qbhfak3hwb92j": { "n": "HoB Corner 32, 33, 35, 36", "l": "http://houseofbitcoins.com", "v": 1 },
	"18888ZgAneZWtyRmCwmhAMTTNcmqAfQqF2": { "n": "HoB Street 1-3", "l": "http://houseofbitcoins.com", "v": 1 },
	"1K1cvUS8e6yCXYNPoS5C1FuuPmv5HRa4y9": { "n": "HoB Street 4-6", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DgRBxvJFfApirnoRoGT9xhcXvn4LxHBkP": { "n": "HoB Street 7-9", "l": "http://houseofbitcoins.com", "v": 1 },
	"17V3vtGk9odCWm3iefcP5RvPUkpMbZ7B1m": { "n": "HoB Street 10-12", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DBa241GQuX2Hz85PRNp3G5Cj5iUW2zhNH": { "n": "HoB Street 13-15", "l": "http://houseofbitcoins.com", "v": 1 },
	"18cKveXNe1kHm7gB33XGRp6kwCsipPGgxQ": { "n": "HoB Street 19-21", "l": "http://houseofbitcoins.com", "v": 1 },
	"13cFszjvxyPDLPDi6WHYbwbm5DtJLoJSTW": { "n": "HoB Street 16-18", "l": "http://houseofbitcoins.com", "v": 1 },
	"1NgFw32SqGRS3LdNgi6djCFHdTkhQy5t51": { "n": "HoB Street 22-24", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DMqYCbHEEEYwzy21p4Da8bqxpwZVoEY8N": { "n": "HoB Street 25-27", "l": "http://houseofbitcoins.com", "v": 1 },
	"143sdyFbzBCk3i8Qpfd8hMvseficBTnZsR": { "n": "HoB Street 28-30", "l": "http://houseofbitcoins.com", "v": 1 },
	"1G52V3sKJq5cPUwk2CQ2NGCyokitZzKwHT": { "n": "HoB Street 31-33", "l": "http://houseofbitcoins.com", "v": 1 },
	"1CKCEWmwbtRDzfJPQqrzUfvrPS74EheyEg": { "n": "HoB Street 34-36", "l": "http://houseofbitcoins.com", "v": 1 },
	"15fkNeqM4qzD2cq8s1pbwv2oeYNSFzGhvR": { "n": "HoB Line 1-6", "l": "http://houseofbitcoins.com", "v": 1 },
	"1Hz5iFUo496reQpngt9jfa2mgKDVSioKZY": { "n": "HoB Line 4-9", "l": "http://houseofbitcoins.com", "v": 1 },
	"1LqZecQYEoUCoKMpf1v58fWSPuyv781e4d": { "n": "HoB Line 7-12", "l": "http://houseofbitcoins.com", "v": 1 },
	"1Hqf6GLbPPSZznLz9oxqLw6wqAJ7TUa96i": { "n": "HoB Line 10-15", "l": "http://houseofbitcoins.com", "v": 1 },
	"17jjPDvyR8xtFybLa3CF3RGZYCJaS54UPs": { "n": "HoB Line 13-18", "l": "http://houseofbitcoins.com", "v": 1 },
	"1EYQZqzLvAuc7nhxYGwN632AWMyXQnsrVm": { "n": "HoB Line 16-21", "l": "http://houseofbitcoins.com", "v": 1 },
	"1A6erH8hy7ceAfB6yckQ7794tj9KDKjkA2": { "n": "HoB Line 19-24", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DnA6CwTSgAzZmycV7RUrFUKp2Hn3tStPb": { "n": "HoB Line 22-27", "l": "http://houseofbitcoins.com", "v": 1 },
	"18nJv16Fp1dDSeKoSrQ4DbpGXbQhXV1Kxj": { "n": "HoB Line 25-30", "l": "http://houseofbitcoins.com", "v": 1 },
	"1BKUyZaeo4fhLPtKqL4CVgWhdtHAjxUeMP": { "n": "HoB Line 28-33", "l": "http://houseofbitcoins.com", "v": 1 },
	"1AnA9wcUDRhUT4RVCAp7NRd7KcgyECGbh5": { "n": "HoB Line 31-36", "l": "http://houseofbitcoins.com", "v": 1 },
	"1JqNLB7GaK1goRtkXRizqAD8FQksBZ8ZuY": { "n": "HoB Column 1-34", "l": "http://houseofbitcoins.com", "v": 1 },
	"1K23Wg1KCxNmymWDPUMdP6hx2LoRS5dKWF": { "n": "HoB Column 2-35", "l": "http://houseofbitcoins.com", "v": 1 },
	"1PGizhMsMgADaf19cTfyCBkcsdwfz9CX5R": { "n": "HoB Column 3-36", "l": "http://houseofbitcoins.com", "v": 1 },
	"1LJ2Dzz8LrsJU3pBchWDnXnThPsmZ9i5g3": { "n": "HoB 1st 12", "l": "http://houseofbitcoins.com", "v": 1 },
	"17norJ9kA6YLdAPYQV65u5UVXxAgVa9vmQ": { "n": "HoB 2nd 12", "l": "http://houseofbitcoins.com", "v": 1 },
	"19Ew3aqqx9jyWHXet7ep6m2KZd66itTfhU": { "n": "HoB 3rd 12", "l": "http://houseofbitcoins.com", "v": 1 },
	"18A156YGjsyNp2693Bo2ia9NZhJTVipHaJ": { "n": "HoB 1st Half", "l": "http://houseofbitcoins.com", "v": 1 },
	"16m9KxJiFZjG4wAyY6v5Juuenn8kK4siBi": { "n": "HoB 2nd Half", "l": "http://houseofbitcoins.com", "v": 1 },
	"1Bgs4aiEq2ESwG9i5vSWApWj93EEEEpmhZ": { "n": "HoB Even", "l": "http://houseofbitcoins.com", "v": 1 },
	"18azBQsL5JqX6hA8haSfgrAPq8h8hNT4Ub": { "n": "HoB Odd", "l": "http://houseofbitcoins.com", "v": 1 },
	"1DE2rFjQAqiQyjJm7XjcNLXnoz64c5oqjL": { "n": "HoB Red", "l": "http://houseofbitcoins.com", "v": 1 },
	"1JJgqNqBKcFoCtWGVsQ2kR3FtuAXdwvc5A": { "n": "HoB Black", "l": "http://houseofbitcoins.com", "v": 1 },
	"1EZTVaGQ6UsjYJ9fwqGnd45oZ6HGT7WKZd": { "n": "EZTV", "l": "https://eztv.it/", "v": 1 },
	"1234567ACtsSyTJ9CXQC92LqgsxG1GVBNk": { "n": "B1z SUCKS!", "l": "http://bitcoin-otc.com/viewgpg.php?nick=b1z", "v": 1 },
	"1BTCre3vo5KZCu5k2oLxu1DcimkNipadV6": { "n": "BTC.re - Regarding Bitcoin", "l": "http://btc.re", "v": 1 },
	"1KyQdQ9ctjCrGjGRCWSBhPKcj5omy4gv5S": { "n": "askmike", "l": "http://askmike.org", "v": 1 },
	"13r1jyivitShUiv9FJvjLH7Nh1ZZptumwW": { "n": "Gekko", "l": "https://github.com/askmike/gekko", "v": 1 },
	"16yRRwokeqgZ9WMgjhV77p8BR2xJbyMXmZ": { "n": "Gekko - open source tradingbot", "l": "https://github.com/askmike/gekko", "v": 1 },
	"1KxTwMdH2sK9ttKad8ohVtn2m1uvi6MpGa": { "n": "Coinrun Donation", "l": "http://coinrun.bits2win.com/", "v": 1 },
	"1CimGCrT3XQSJ1VEgrUa9BGMv7u2ECoJv4": { "n": "Minr.info", "l": "http://minr.info/", "v": 1 },
	"1Jk49k4sLJdYc4aVgybwtP88uFgeLp9Xyt": { "n": "Coingig.com Payment Address 50", "l": "http://www.coingig.com/donate", "v": 1 },
	"1Nd8C6qEygD8AegQiNwcV4Vepo9pw4z4PZ": { "n": "Coingig.com Payment Address 49", "l": "http://www.coingig.com/donate", "v": 1 },
	"1HimQjxNLA2B8zmQb2782ty1qQuLMdf35G": { "n": "Coingig.com Payment Address 48", "l": "http://www.coingig.com/donate", "v": 1 },
	"1HQXUXmHNeAYSU5nD6aqax8RKFHKWCU5Ve": { "n": "Coingig.com Payment Address 47", "l": "http://www.coingig.com/donate", "v": 1 },
	"1CWnkEqu2HbbBdaeop2tZ5vBxGRZpDZ62L": { "n": "Coingig.com Payment Address 46", "l": "http://www.coingig.com/donate", "v": 1 },
	"15xNsaaTBPhnvNqYJDDhtMG1gKAAHog3k2": { "n": "Coingig.com Payment Address 45", "l": "http://www.coingig.com/donate", "v": 1 },
	"1BarxYzjorU8CDxiEuGHK7Ss3JCDQkBjAd": { "n": "Coingig.com Payment Address 44", "l": "http://www.coingig.com/donate", "v": 1 },
	"1Fg57JvRnz1DS4p3Swf9KJ9kMrJhyUy5Sh": { "n": "Coingig.com Payment Address 43", "l": "http://www.coingig.com/donate", "v": 1 },
	"1DCXdWARVkr64fqUSGJTmTmiA14pvjwqfr": { "n": "Coingig.com Payment Address 42", "l": "http://www.coingig.com/donate", "v": 1 },
	"1MfEMouSoFPW8KsZMUhaWZBJDbMB75XMWF": { "n": "Coingig.com Payment Address 41", "l": "http://www.coingig.com/donate", "v": 1 },
	"1AyN5rZDZRRU3w2PLrhbpcZszGCyJeVvc9": { "n": "Coingig.com Payment Address 40", "l": "http://www.coingig.com/donate", "v": 1 },
	"1NwW6LGM3p1TU8AKJkfRYKPeR86KjTikaD": { "n": "Coingig.com Payment Address 39", "l": "http://www.coingig.com/donate", "v": 1 },
	"1JqNLGhdxLb1rLekQHiUckowM48voYXsb8": { "n": "Coingig.com Payment Address 38", "l": "http://www.coingig.com/donate", "v": 1 },
	"15RLKSvn4CDy4znrJ3ptgT65Fe6NMMSSjn": { "n": "Coingig.com Payment Address 37", "l": "http://www.coingig.com/donate", "v": 1 },
	"13Q1UY5Wo3ry33ZxWWp392unnTJvHG9TjV": { "n": "Coingig.com Payment Address 36", "l": "http://www.coingig.com/donate", "v": 1 },
	"1MqVK1aCYmgYMBvLWyRbGr1xy4wYj4Qagj": { "n": "Coingig.com Payment Address 35", "l": "http://www.coingig.com/donate", "v": 1 },
	"1JA9z4y8xTnfbBqXkfXxmn7yt2AWzsfMgs": { "n": "Coingig.com Payment Address 34", "l": "http://www.coingig.com/donate", "v": 1 },
	"12iNucXhzLxmfvb4rZo38HHFhTwLBwd99J": { "n": "Coingig.com Payment Address 33", "l": "http://www.coingig.com/donate", "v": 1 },
	"1GmqDLKqVDUAsyx9RaokE6AW8KjCp4pRFf": { "n": "Coingig.com Payment Address 32", "l": "http://www.coingig.com/donate", "v": 1 },
	"18STHuWxawnhQA1yoiv4vWWBtKcszLoAJ": { "n": "Coingig.com Payment Address 31", "l": "http://www.coingig.com/donate", "v": 1 },
	"1FavQrrzTTvoYNm9Wjecfii6yxzCXPJizM": { "n": "Coingig.com Payment Address 30", "l": "http://www.coingig.com/donate", "v": 1 },
	"1EN4irtfme5obKC9frRYhPiAQqUusuE1rF": { "n": "Coingig.com Payment Address 29", "l": "http://www.coingig.com/donate", "v": 1 },
	"14D2QdiQ1uXiR91JwzsSZranYGjkZMCdLC": { "n": "Coingig.com Payment Address 28", "l": "http://www.coingig.com/donate", "v": 1 },
	"1LuukhXDNyhGHjkYXwkCYmR5H1G71YPug8": { "n": "Coingig.com Payment Address 27", "l": "http://www.coingig.com/donate", "v": 1 },
	"1BQpXjbnfNAuGz6sGNHSve41qdureFZF1D": { "n": "Coingig.com Payment Address 26", "l": "http://www.coingig.com/donate", "v": 1 },
	"1CQ5ATq8Hq3qVhj7zK32DfMzfVf9LaAAnk": { "n": "Coingig.com Payment Address 25", "l": "http://www.coingig.com/donate", "v": 1 },
	"13aXhMkbQnYyT1eNogWxShARB5LkDCQaGT": { "n": "Coingig.com Payment Address 24", "l": "http://www.coingig.com/donate", "v": 1 },
	"1CXT48RynKYBG1W8H6u16s8EV6hho3uuNG": { "n": "Coingig.com Payment Address 23", "l": "http://www.coingig.com/donate", "v": 1 },
	"13r86HeaxTuiQYA1A42uekieRyN1V6jjFV": { "n": "Coingig.com Payment Address 22", "l": "http://www.coingig.com/donate", "v": 1 },
	"1MvUnHW7fL67jBbLiTuToSBiX5stK3Pudm": { "n": "Coingig.com Payment Address 21", "l": "http://www.coingig.com/donate", "v": 1 },
	"1KwzeaYwfsWuQbLKtFmAUYCVWqnkWnPxUL": { "n": "Coingig.com Payment Address 20", "l": "http://www.coingig.com/donate", "v": 1 },
	"17dWyg44uLLPgjPdVAUTnzZwBsxRejVZd2": { "n": "Coingig.com Payment Address 19", "l": "http://www.coingig.com/donate", "v": 1 },
	"1PnVdJ77VxF67YgWg5TsDT4R3WBnHUfS6E": { "n": "Coingig.com Payment Address 18", "l": "http://www.coingig.com/donate", "v": 1 },
	"1CaA8Pmdsecqrmv9H8BNmgM831MrwY1g2u": { "n": "Coingig.com Payment Address 17", "l": "http://www.coingig.com/donate", "v": 1 },
	"12tR6663ncd1RaV9ALz16RemcRzJYzzYQP": { "n": "Coingig.com Payment Address 16", "l": "http://www.coingig.com/donate", "v": 1 },
	"13tZVAciA7kimRPMRTHsSsQg5f6PCXUuWf": { "n": "Coingig.com Payment Address 15", "l": "http://www.coingig.com/donate", "v": 1 },
	"1BfFFQcsDyrmWAWzsJwkMAtqLk9ArwPXYB": { "n": "Coingig.com Payment Address 14", "l": "http://www.coingig.com/donate", "v": 1 },
	"14iA7YSewDTUD3ioUUhL7jdze8K12nvmqW": { "n": "Coingig.com Payment Address 13", "l": "http://www.coingig.com/donate", "v": 1 },
	"1Nny98FnaQvDTKpTEfA1bYh58GyAiuxiFo": { "n": "Coingig.com Payment Address 12", "l": "http://www.coingig.com/donate", "v": 1 },
	"13aHjGax2MKQtEAqB35dS6fZpyDocGqv95": { "n": "Coingig.com Payment Address 11", "l": "http://www.coingig.com/donate", "v": 1 },
	"1cTSn9ySUKC7UY6oZjD8BN5QeMPELqxGe": { "n": "Coingig.com Payment Address 10", "l": "http://www.coingig.com/donate", "v": 1 },
	"16vtvc79J6rgbj4uSnU8CsWGDis3SKGw6a": { "n": "Coingig.com Payment Address 9", "l": "http://www.coingig.com/donate", "v": 1 },
	"16zxiDotxjH5svEPM1dF8H67f5breN46bd": { "n": "Coingig.com Payment Address 8", "l": "http://www.coingig.com/donate", "v": 1 },
	"13b3MVgzMJL62uxS8pxQaXFJccL9ryaXYb": { "n": "Coingig.com Payment Address 7", "l": "http://www.coingig.com/donate", "v": 1 },
	"1DFDjnu2JJXHDe5BdnPzDX8v1GvGWudM65": { "n": "Coingig.com Payment Address 6", "l": "http://www.coingig.com/donate", "v": 1 },
	"1YqBjzqmMLWJUSDs6YbKjebSkW2RQD8uh": { "n": "Coingig.com Payment Address 5", "l": "http://www.coingig.com/donate", "v": 1 },
	"19obxRKLJnnUQKEdH5WDxgZGeef9Nj1kR4": { "n": "Coingig.com Payment Address 4", "l": "http://www.coingig.com/donate", "v": 1 },
	"1ZTe1nmStshUP2RfpMYVH7xmZ8nUn2Wsr": { "n": "Coingig.com Payment Address 2", "l": "http://www.coingig.com/donate", "v": 1 },
	"13twh2yyyjjWKvXCvy79pSBZmY8biVq6gA": { "n": "Coingig.com Payment Address 3", "l": "http://www.coingig.com/donate", "v": 1 },
	"1CEiUuoqdMPFXRt8kE4j9y2kB7D1McZQRA": { "n": "Coingig.com Payment Address 1", "l": "http://www.coingig.com/donate", "v": 1 },
	"1C4cuj3iaYmSHehw8Qy7yHzFRuP4cqSuky": { "n": "davos", "l": "http://davosbtc.wordpress.com/", "v": 1 },
	"19foqNZgE5UPWCRDWu41YXW8pUYqexaMAx": { "n": "TossBit.com TAILS", "l": "http://tossbit.wordpress.com/", "v": 1 },
	"138A9GXNYL82T7psVnGvMnAQUpgnYRWWcn": { "n": "TossBit.com HEADS", "l": "http://tossbit.wordpress.com/", "v": 1 },
	"1DoNNchAB64WDyAW9MDVQ8hsNiw2HPXDUv": { "n": "Donncha.is", "l": "http://donncha.is", "v": 1 },
	"1GWgXDwged3LjCsFYD5KSutk2G4YMbUpGb": { "n": "SatoshiDiamond", "l": "http://www.satoshidiamond.org/en/index.php", "v": 1 },
	"1ERi2kpdQL7i3cPgRx1RcabLmBuvuTdz7s": { "n": "CrowdJustice", "l": "http://www.reddit.com/r/Bitcoin/comments/1fmmgd/crowdfunding_for_bitcoin_justice_the_bfl/", "v": 1 },
	"1N8yFVWZcixNYdnzDp3iKSRgwphzrM5QZ5": { "n": "SatoshiDiamond", "l": "http://www.satoshidiamond.org/en/index.php", "v": 1 },
	"15eHdYLLYw5Yp8Yqp7ACpb6HNHVnQX6YXt": { "n": "take a bitcoin leave a bitcoin", "l": "http://www.reddit.com/r/Bitcoin/comments/1f9h1n/asking_ourselves_to_indebt_ourselves_in_order_to/", "v": 1 },
	"1FLAKu79QTtZJs3ac172jtAZcZxFNfZ1iM": { "n": "The Way Invious", "l": "http://aymon.me", "v": 1 },
	"1EiPo8ztDSaNnLqx9148qXbpAN5jZu8f3h": { "n": "legionlara", "l": "http://legionlara.wordpress.com/bitcoin-gratis-free/", "v": 1 },
	"1dicezFKJGL6yL2ubLF1t865g9G4ydJLP": { "n": "SatoshiDICE 100.00", "l": "https://p.6core.net/p/vdhSiRqRl6AQKBpYJFhDqAhy", "v": 1 },
	"1Bardi4eoUvJomBEtVoxPcP8VK26E3Ayxn": { "n": "Bardi Harborow", "l": "https://plus.google.com/116253181307888533825/about", "v": 1 },
	"1Lotto3CMJwLLpRUPHxkmDXbXqhHC9Jffo": { "n": "DabsLotto", "l": "http://blockexplorer.com/address/1Lotto3CMJwLLpRUPHxkmDXbXqhHC9Jffo", "v": 1 },
	"1FpFxpNmoj1GeZ4PoG533446FjDXvgvMi4": { "n": "PLEASE give a DONATION", "l": "http://blockexplorer.com/address/1FpFxpNmoj1GeZ4PoG533446FjDXvgvMi4", "v": 1 },
	"18BfHRvBnpTTDNY1dNTazonEyLfG3aTXfj": { "n": "Bitcoin Extra Amazon Store", "l": "http://bitcoinextra.weebly.com/bitcoin-extra-amazon-store.html", "v": 1 },
	"1LQGG3P73ioV2e9jo8uzyCjnEJYxYpkUMR": { "n": "Seattle Meshnet Project", "l": "https://www.meshwith.me", "v": 1 },
	"1XeRocJ6PRUX419QQo9crW5nbsjetJLUn": { "n": "xeroc", "l": "http://www.xeroc.org", "v": 1 },
	"185tUi5UpxsRth4isF1BwQAcr25gQJLtSn": { "n": "GodDice", "l": "http://www.goddice.info/", "v": 1 },
	"1EpU7n1zmU6zjzDDBdo5Ggxm1wucMyrZ3K": { "n": "GodDice", "l": "http://www.goddice.info/0/", "v": 1 },
	"1AerisqW72fb896PH297t5KiD5YaDYpVQm": { "n": "aeris", "l": "http://imirhil.fr/", "v": 1 },
	"1aerisnnLWPchhDSXpxWGYWwLiSFUVFnd": { "n": "aeris", "l": "http://imirhil.fr/", "v": 1 },
	"18CbEZk3hUkoPbWVQVXvxn4M4q2ju1PLn1": { "n": "iqdb donate", "l": "http://iqdb.org/", "v": 1 },
	"1MoTLDxxwp73ftUVy476DPzmcCQJRtNyQT": { "n": "MoTLD", "l": "https://motld.jottit.com/", "v": 1 },
	"1P9wrpA2UQ2GEmMpt81Ch3Wt4poq5LhpiW": { "n": "Duncan Elms Bitcoin Video", "l": "http://vimeo.com/63502573", "v": 1 },
	"1HtUGfbDcMzTeHWx2Dbgnhc6kYnj1Hp24i": { "n": "ASICMiner mining address", "l": "http://www.reddit.com/r/Bitcoin/comments/1extr4/asicminer_mining_address/", "v": 1 },
	"1PVmqfC7GcpPVg5jTTGHuv49EwAB8tEqwM": { "n": "CoinLenders Signing Server 1", "l": "http://coinlenders.com", "v": 1 },
	"133333bm8n6VyP5x5on7sU9KV9C28TH1Av": { "n": "ya", "l": "http://search.tut.by/?status=1&ru=1&encoding=1&page=0&how=rlv&query=133333bm8n6VyP5x5on7sU9KV9C28TH1Av", "v": 1 },
	"1MkFEB4ijvqjUULRnc9pXvDtcjVC3PGNF8": { "n": "Bitcoin Bazaar", "l": "http://bitcoinbazaar.wordpress.com/donations/", "v": 1 },
	"1LBizLVYSjJG9wNUNAWYtU1ABX63N33PDV": { "n": "bitcoincollector.net", "l": "http://www.bitcoincollector.net/home", "v": 1 },
	"1AthBNQdw3Lva92EJCGYD7C8fiac9c4CLw": { "n": "Easy Miner", "l": "http://www.first-world.info/easy-miner.html", "v": 1 },
	"13AVZEHrv26svPa8cNr7WF5RKXrkqTGhAW": { "n": "Ultracopier", "l": "http://ultracopier.first-world.info/", "v": 1 },
	"1L2ZDT3xdHNTwR6FmAMitNPvWFMT8JCgpu": { "n": "OpenNIC Project", "l": "http://www.opennicproject.org", "v": 1 },
	"17YVia7Yq2m5r4Y6Pkfvu6b9HRAh1RjCmp": { "n": "Bitcoin.stoto.net", "l": "http://bitcoin.stoto.net", "v": 1 },
	"1Nk6vMFjiUGbuV2APAcV2Ux3ENS1DapmhE": { "n": "Bitcoinforest.com", "l": "http://www.bitcoinforest.com", "v": 1 },
	"1HgP2fFZNBq5hU8f2yjXBc7wna1Di22oLA": { "n": "Public Enemy 2K6 MesAZ", "l": "http://www.youtube.com/watch?v=PqLPQhhT1Yw", "v": 1 },
	"19xb2pAzyv7feFkBhbh3n3rtBJ9JPTufm": { "n": "The Rise and Rise of Bitcoin", "l": "http://www.youtube.com/watch?v=V-3haBibXWc", "v": 1 },
	"1d6iMwjjNo8ZGYeJBZKXgcgVk9o7fXcjc": { "n": "QtBitcoinTrader", "l": "https://github.com/JulyIGHOR/QtBitcoinTrader", "v": 1 },
	"1JuiceFY97v92LHvkAjHy1FWoqFkAnQiC4": { "n": "Injust", "l": "http://coinurlclicks.blogspot.ca/", "v": 1 },
	"1NqjkhCdvUjX4waw9gCJ98LTqQhw3REYoR": { "n": "coinrun.bits2win.com", "l": "http://coinrun.bits2win.com/", "v": 1 },
	"1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2": { "n": "Tails Project Donations", "l": "https://tails.boum.org/contribute/how/donate/", "v": 1 },
	"185By4a1Lt2HnKLAKR5EmidZMYgp5DDSaj": { "n": "Bitcoin 2013", "l": "https://www.youtube.com/watch?v=s5In1uBWcHg", "v": 1 },
	"1GodMcqPpqpmQVfnuzCUWA9TFGn6AsMd4": { "n": "Gods Wallet", "l": "http://blockexplorer.com/address/1GodMcqPpqpmQVfnuzCUWA9TFGn6AsMd4", "v": 1 },
	"1CqiFv4oEfWLegaADaZBLPKeStvkQoSPG4": { "n": "Raise1BTC", "l": "http://raise1btc.site11.com/", "v": 1 },
	"1F4FmJCdpCNrFhJwhAbHS6gMFBakR7Ezse": { "n": "Bitcoinforest.com", "l": "http://www.bitcoinforest.com", "v": 1 },
	"1coinFi1SLV1LaQZiUkJ87wfz4nLJZaxz": { "n": "CoinBox.me", "l": "http://www.coinbox.me", "v": 1 },
	"1HZnBy2BPvPk5kcxfjNTet6FYjFCxutxSd": { "n": "Coind.net", "l": "http://coind.net/", "v": 1 },
	"17BwFp7zBZTzN1bNcuiHpkh2jynTA27yrc": { "n": "Bitcoinkiez Donations", "l": "http://bitcoinkiez.wordpress.com/support/", "v": 1 },
	"1KK4WkkV9siKe1TiMJ6Csb8JuYQKAezbJA": { "n": "SatoshiDiamond", "l": "http://www.satoshidiamond.org/en/", "v": 1 },
	"1GSTdDUuBFqbabNCaV8Dh4UsuqFMvGZ9kX": { "n": "gst.name", "l": "http://gst.name/", "v": 1 },
	"1JwSSubhmg6iPtRjtyqhUYYH7bZg3Lfy1T": { "n": "KRISTINE-EK", "l": "http://www.reddit.com/r/Bitcoin/comments/1egi51/there_is_currently_over_10000_unconfirmed/", "v": 1 },
	"1cointQVgw2EwnJx3EFVPvD65gSsD9nJ7": { "n": "CoinBox.me", "l": "http://www.coinbox.me", "v": 1 },
	"1L9PMy5K3uWovPXvXi538ntweEAh7Qyo1A": { "n": "SatoshiBet", "l": "https://satoshibet.com", "v": 1 },
	"1DUxQCTiHMxYZWcHjZ4SyQ55pqDzQKRNqw": { "n": "LavaWave", "l": "http://www.LavaWave.com/", "v": 1 },
	"1CwMz8PGTt7tPmXWqURjztumU9faRiLBgU": { "n": "Public Pump Syndicate", "l": "http://www.publicpumps.info/", "v": 1 },
	"1AMAMHQFpKCuPWivyzgUv1ip6BPz9V73QN": { "n": "BTC news aggregator", "l": "http://bits.aihosting.com", "v": 1 },
	"115T6jzGrVMgQ2Nt1Wnua7Ch1EuL9WXT2g": { "n": "sd", "l": "http://fucksheep.org/~sd/warez/semtex.c", "v": 1 },
	"1Ciwfg7H54j2xNMH1yiEX46RxvoqNPZC1m": { "n": "elliottcable", "l": "http://elliottcable.name/", "v": 1 },
	"1FCM1LqDS9uesBjCqosp1axjRnC1EsGDcQ": { "n": "BFL Order Book", "l": "http://bfl.ptz.ro", "v": 1 },
	"1Pjg628vjMLBvADrPHsthtzKiryM2y46DG": { "n": "BitcoinPaperWallet", "l": "https://bitcoinpaperwallet.com", "v": 1 },
	"1JdzWLNEbrwTDexwJ1NsgyHxSBKLvDY3t4": { "n": "MousetrapTraffic.com", "l": "http://www.mousetraptraffic.com/index.php", "v": 1 },
	"1GiFtSkepPZjUfSkg5KdVpfKmbHy6Acv4V": { "n": "BitVanity", "l": "https://github.com/trevory/BitVanity", "v": 1 },
	"1J3pt9koWJZTo2jarg98RL89iJqff9Kobp": { "n": "OpenStreetMap Donations", "l": "http://donate.openstreetmap.org/server2013/", "v": 1 },
	"12aAnVpeL6V4jxw4CX3PZGU25eX5udTL4i": { "n": "miningunited 0.50", "l": "http://www.miningunited.com/index.html", "v": 1 },
	"16Vh6nDN7wWxpzhKEPhBP6KnPCpxtQntzo": { "n": "btc6000", "l": "http://bitcoin-otc.com/viewgpg.php?nick=btc6000", "v": 1 },
	"1KqeqiJtmtmuf8jHDiGt3kYXvLSRHFw2MS": { "n": "MiningUnited.com", "l": "http://www.miningunited.com/index.html", "v": 1 },
	"1LXLpAsi9xmFHzaie5h1abMnd2N7Y95inu": { "n": "GreenCoins.org", "l": "http://www.greencoins.org", "v": 1 },
	"1CZPvje299xsSHD9M3J2Cp3hV2h8tfYJLy": { "n": "glencooper.com", "l": "http://www.glencooper.com/", "v": 1 },
	"1MaxKayeQg4YhFkzFz4x6NDeeNv1bwKKVA": { "n": "Max Kaye", "l": "http://xk.io/", "v": 1 },
	"1NcKW2fP9qMx4di8bLwfCKGidXwjciC7D1": { "n": "ShroudWriter", "l": "http://shroudwriter.blog.com/", "v": 1 },
	"1Bmkkj72f4A3MraeCmw2rjn1EEC1tP2mn6": { "n": "conversions,conversion", "l": "http://salescopywriter.net/", "v": 1 },
	"1CuboxZYwtENJrrbdE5Kf4i7UHnRWF1zRN": { "n": "CuboxSiteWeb", "l": "http://cubox.me", "v": 1 },
	"15qSxP1SQcUX3o4nhkfdbgyoWEFMomJ4rZ": { "n": "Con Kolivas", "l": "http://ck.kolivas.org/apps/cgminer/README", "v": 1 },
	"15ArtCgi3wmpQAAfYx4riaFmo4prJA4VsK": { "n": "faucet donation", "l": "http://web.archive.org/web/20120407230101/http://freebitcoins.appspot.com/", "v": 1 },
	"15VjRaDX9zpbA8LVnbrCAFzrVzN7ixHNsC": { "n": "faucet donation", "l": "http://web.archive.org/web/20111018145837/http://freebitcoins.appspot.com/", "v": 1 },
	"1CpiuvRBDL412FvqSY4b5Wog7c6Ux88Nyi": { "n": "Question Everything", "l": "http://qellc.co", "v": 1 },
	"1AMvSJgu1qhehSFCQysc2wAHWe6oNLMh8U": { "n": "Donations to WautierEnt", "l": "http://www.wautierent.com", "v": 1 },
	"16CcNWYZjfYYNQFEFCXtxvzWmyYKFg4hyK": { "n": "Bitcoin Extra Website Wallet", "l": "http://bitcoinextra.weebly.com/", "v": 1 },
	"1H63WEQbK45K3xgC7DRfphMWMJMZHrX542": { "n": "DiasporaProject.org", "l": "http://diasporaproject.org/donate", "v": 1 },
	"15uuf2A9ZkcgTTuFJnZiNZwjkEGDfxwjVS": { "n": "Bitcoinforest.com", "l": "http://www.bitcoinforest.com", "v": 1 },
	"1KjJGvZwkb4YF3Yda1MdCo7YyqKvFc2Y9V": { "n": "Blackmail", "l": "http://www.reddit.com/r/Bitcoin/comments/1dt1zz/if_50btc_are_not_sent_to_this_address_by_0000_gmt/", "v": 1 },
	"1L7LgaRtr3WSw5g1MaJQWj19T6RByssz41": { "n": "gwern.net", "l": "http://www.gwern.net/Links", "v": 1 },
	"1REDFSXcU1ki4Ai2NJZo2UuFQfKUoBv5E": { "n": "REDCOINS.co", "l": "http://www.redcoins.co/", "v": 1 },
	"1PuwdYjTaY7hKUD1F7VExccBCXNDj1rmLn": { "n": "The Bitcoin Catalog", "l": "http://thebitcoincatalog.com", "v": 1 },
	"14ZwfLwn7H43ejCph4Q3UN4sErk5qBRVNq": { "n": "MiningUnited.com", "l": "http://miningunited.com/", "v": 1 },
	"1BJJKn6jyfk8CDtYLjHutLoSbky3MWdoG": { "n": "The Pirate Bay Proxy Website", "l": "http://tpb.pw/", "v": 1 },
	"13NGgGU9YzCTxhFjTCwREGys6tKkGCaCwR": { "n": "BTCmine.net", "l": "http://www.btcmine.net", "v": 1 },
	"1BW253r25WvXqJy7V49hVz3AW4QBunhYA8": { "n": "Bitcoin World", "l": "http://bitcoinworld.me/", "v": 1 },
	"15Z4XmorKSN51ndyPrZ2EtL7Nnksb88888": { "n": "one chinese sb which love 8", "l": "http://blockexplorer.com/address/15Z4XmorKSN51ndyPrZ2EtL7Nnksb88888", "v": 1 },
	"1Pt9TRJKeAW61aR1ELQpUZKdMaYXzkCTrn": { "n": "Internet Archive Converter Box", "l": "http://blog.archive.org/2013/03/05/bitcoin-to-cash-converter-box/", "v": 1 },
	"1HR3EoCArWjYNiBhPtMiFfA5oUoM8aRgLn": { "n": "Lobbyplag", "l": "http://lobbyplag.eu/support-us", "v": 1 },
	"1EoUJadqQWyuNwgs9ez1hsGewNkK7BrmpF": { "n": "Living On Bitcoin For A Week", "l": "http://www.forbes.com/sites/kashmirhill/2013/05/01/living-on-bitcoin-for-a-week-the-journey-begins/2/", "v": 1 },
	"1DanViciiFrWnTUjytRANfMa9VXQZWnVPo": { "n": "Dan Victor", "l": "https://sites.google.com/site/btcdanvic/", "v": 1 },
	"1Tom11Ujmt99yxrSXVEnMzZKkvc5zXTRx": { "n": "wingsuit", "l": "https://sites.google.com/site/skydivingfallingflying/", "v": 1 },
	"1WT6sCpeZm2R6HPdtR67o9tpi1m8KpwX9": { "n": "The Age Of Bitcoin", "l": "http://www.age-of-bitcoin.com/donate-page", "v": 1 },
	"1AKjchmLkKFKRrEpXpBUNre4ixHoeBVpJo": { "n": "BCtip", "l": "https://www.bctip.org", "v": 1 },
	"1opstorqnZywe1uKSoZQXejggDrKaohTK": { "n": "Andreas M. Antonopoulos", "l": "http://openbitcoinstore.com/index.php/donate/", "v": 1 },
	"155ozmQo4hj7og7Cv5azxRwqHJgEuWnLBs": { "n": "nioctiB.net", "l": "http://www.nioctib.net", "v": 1 },
	"1GZiGeqWN1DYB9TQErcfR8uDhQJrW1ccFE": { "n": "BTCShop", "l": "http://btcshop.org", "v": 1 },
	"13HtqbzdMU3WUsJBKAZ5JzUBaufcdPnqkm": { "n": "SrBitcoin.com", "l": "http://www.srbitcoin.com", "v": 1 },
	"1vQABhs6gjhDz8bc2i6KNcPMr3bS5HvxN": { "n": "BtcLotto.de", "l": "http://btclotto.de", "v": 1 },
	"1BnpG4jddgNXsQBQjsU8BS3F1Ubm9XgVah": { "n": "CoinMap.org", "l": "http://coinmap.org/", "v": 1 },
	"1ShokaTAuTW5tkDgpPvHyxqVTZzhUWkrZ": { "n": "notathing", "l": "http://disposablewebpage.com/turn/e3qXPzQTgN", "v": 1 },
	"18Ed8oh2aCjcCsweSk1pd77D4GJSxbHMu5": { "n": "BT-Chat.com - Follow the Swarm", "l": "http://www.bt-chat.com/", "v": 1 },
	"155TY9EpfpML46QA5bhYxRkxXpcJJFZfxU": { "n": "Cryptotrack.com", "l": "http://cryptotrack.com", "v": 1 },
	"123ZYj4MCXiek1btZQ7dE5qGD6hTLHzxRs": { "n": "TWiT.tv", "l": "http://twit.tv", "v": 1 },
	"16qqqZLQheW3mGchRVJ18CEocpdUcW2zCn": { "n": "BitcoinAR", "l": "http://www.bitcoinar.net", "v": 1 },
	"1HzcaTisbjKFpM2LYmUkcEpbjcf6h8uqVy": { "n": "Bitcoins For Boston", "l": "http://bitcoinsforboston.com/", "v": 1 },
	"1PwMrobDD8CjA4Mv3FFUNvkzkEjVFhiKP5": { "n": "Bitcoinmining.com", "l": "http://www.bitcoinmining.com/about-us/", "v": 1 },
	"16DrKT1JpA4tCVxzhCYQ4FxLnGbbZ46ukE": { "n": "Papercoin.org", "l": "http://papercoin.org", "v": 1 },
	"1AdVDXrxtJpV1xnurc8RFQX2mvpcjCA9pc": { "n": "eteache", "l": "http://box.eth1.es/", "v": 1 },
	"1BSorg3JEvDSQ7GBdBbuwkYVTnx6BDaG4W": { "n": "bitcoinstatus.org", "l": "http://bitcoinstatus.org/", "v": 1 },
	"15dDsATuR4Z5EGXdEwizBHhNE8PpQmkYP1": { "n": "Hamish", "l": "http://delta.geek.nz/", "v": 1 },
	"1CmeoUQHMBiRQvAxnLhrHqYApiWvEbhyAQ": { "n": "Comprarbitcoin.net", "l": "http://www.comprarbitcoin.net", "v": 1 },
	"19hJLtfs5pqv2S4kRySMcnxnCzkNf7rhGS": { "n": "Bitcoin.clarkmoody.com", "l": "http://bitcoin.clarkmoody.com", "v": 1 },
	"1AaqmLeSnXmNSZY5JeVE88ZoGfE66f17o2": { "n": "Betcoins", "l": "http://www.betcoins.net", "v": 1 },
	"144yTvFm9kaRMdXupb21oPuWurGGwaLBpL": { "n": "Betcoins", "l": "http://www.betcoins.net", "v": 1 },
	"194xig3EDkQK9GcWZn7ucnMswr6MPNEzWT": { "n": "BTC-France", "l": "http://bitcoin-france.org/", "v": 1 },
	"1Lg2rvxbBPC8jp2YJoV5xL7sdyTjueMUot": { "n": "xkcd (old address)", "l": "http://web.archive.org/web/20110414103726/http://xkcd.com/bitcoin/", "v": 1 },
	"1Fw4sRdZYFwULfeE7oQ91GLYKy8j5EcuFW": { "n": "EZTV", "l": "http://eztv.it/", "v": 1 },
	"1DnH629PCMYC8QVutonK1wNH1CdZjaqeNt": { "n": "ic bitcoin-oct", "l": "http://bitcoin-otc.com/viewgpg.php?nick=ic", "v": 1 },
	"1JHA4NgiKpaCsU5ABYQ5jSKK2v9NvvJ9hQ": { "n": "ic earnfreebitcoins referrer", "l": "http://earnfreebitcoins.com/address/1JHA4NgiKpaCsU5ABYQ5jSKK2v9NvvJ9hQ", "v": 1 },
	"1ELrDragwPZSsfLAKarkboiBiEvyS9ja5Z": { "n": "ic main", "l": "http://icweb.eu", "v": 1 },
	"1EoVvpCYyzs67qegXyQAjfQosFBc5tr6Jh": { "n": "FSR mirror", "l": "http://futuristicsexrobotz.net/", "v": 1 },
	"1BLockgUZ45M3NDWmCfbptLRnmiFnHpF2b": { "n": "BlockEnd", "l": "http://blockend.net", "v": 1 },
	"19dnBMy1tKDhz6JsNQzX3VFx1EhrnmBoTy": { "n": "Bitcoin faucet links", "l": "https://sites.google.com/site/bitcoinfaucetlynx/home", "v": 1 },
	"1AibaiCJAzYDpCGJmpP28W1vG6LLWn13cS": { "n": "Aibai,Donation for LGBT Rights", "l": "http://aibai.org/pages.php?linkwords=contact", "v": 1 },
	"1BcpuMcncQae1NL9BuUN9j9ijGSVjDPDev": { "n": "Denom", "l": "https://www.flashback.org/u165509", "v": 1 },
	"1GpSu46nDV6ZLnFc23Dpzt3PvSb5Nub2MN": { "n": "?????", "l": "http://tieba.baidu.com/p/2283224569", "v": 1 },
	"1DUMifqLdCRvx6tAzafwDC2tKRntRAAm3z": { "n": "????????????????", "l": "http://news.mydrivers.com/1/261/261129.htm", "v": 1 },
	"17cRwRPk7Xjz9Qp55B2hYfrZqUk5Z3QypK": { "n": "Luis Aranguren", "l": "http://luisaranguren.com", "v": 1 },
	"LSQBL4Rs1rjP3tZUVb4MfXSQu1JEyWr7ix": { "n": "XSS Hack", "l": "http://www.reddit.com/r/Bitcoin/comments/1ct644/help_me_investigate_this_link_do_not_go_to_unless/", "v": 1 },
	"1DnwcSevrYyUCTxbPmL1TtABoaucDTMTYo": { "n": "XSS Hack", "l": "http://www.reddit.com/r/Bitcoin/comments/1ct644/help_me_investigate_this_link_do_not_go_to_unless/", "v": 1 },
	"1gPTdJMRbbeWcQyw5qBFZHQERNfSZX1Hs": { "n": "VirtualFaucet.com", "l": "http://www.virtualfaucet.com", "v": 1 },
	"1BtEanKRfhYdcZwduPVBuB4UK4jbtG3C72": { "n": "TheFreeBitcoins.com", "l": "http://www.thefreebitcoins.com", "v": 1 },
	"1KUVuPQ6NAT2LzH8NEq35Rpyz79QWqks6B": { "n": "FreeBTC4all.com", "l": "http://www.freebtc4all.com", "v": 1 },
	"1DEyrG9XYNqrxdDgzc4kyCuMFFugFpM5Nv": { "n": "FreeBitcoins.me", "l": "http://www.freebitcoins.me", "v": 1 },
	"1Kqzbv4ekpJX3ohYWGEzMqzvf27VjBux35": { "n": "The Pirate Bay", "l": "http://thepiratebay.se/", "v": 1 },
	"1whiskrpGeZVd5ormX2ihifc9uB2YSz82": { "n": "whiskers75", "l": "https://github.com/whiskers75", "v": 1 },
	"1ArFAXhvMbwJuub4ujnVbLFszqX3McuzsX": { "n": "The Genesis Block", "l": "http://thegenesisblock.com", "v": 1 },
	"19dP3T5ZGz5jfFMZ1NoyFe4uCiX1hFnnqS": { "n": "Bitflip", "l": "http://bitflip.co/", "v": 1 },
	"1CrVMGUSFgAFL2wWx5t64svA93UtSjqMpo": { "n": "Bitcoinfilm.org", "l": "http://bitcoinfilm.org/donate/", "v": 1 },
	"1LMvwHjudMmPNKe5Vd5GPY2pmPTyV2qLtu": { "n": "BTCponzi (KNOWN SCAM)", "l": "http://www.reddit.com/r/Bitcoin/comments/1ck6ez/for_the_new_people_here_btcponzi_is_an_obvious/", "v": 1 },
	"1Gg8hpFfUn6ZCXCH4Shx9QGaPvxYxYBQUq": { "n": "Bitcoins.am", "l": "http://www.bitcoins.am/about-us.html", "v": 1 },
	"1CSFymHagFQoumXwn3x9ndsgxgqZNCKAnD": { "n": "BTCPonzi", "l": "http://btcponzi.org/", "v": 1 },
	"1GvVpDGM426bHp2eXwHzwDNqv8g2xyfznJ": { "n": "Torservers.net", "l": "https://www.torservers.net/donate.html", "v": 1 },
	"19AvgDTy34rtW78SkyHCJKJnqVUMVf51Jw": { "n": "Alan Burns (??)", "l": "https://plus.google.com/114514582186210082618/about", "v": 1 },
	"1Hc3vJfnZRASza6Hz1o8xMR4X4fGdAHPjC": { "n": "Scammer - Manuel Roldan Arroyo", "l": "http://pastie.org/private/mcz4lamj6iei9cvt9z2gw", "v": 1 },
	"1BWF67eELeTvhJFJQGxQH4X4RUjJBKrmxJ": { "n": "Bitcoin World Faucet", "l": "http://faucet.bitcoinworld.me/", "v": 1 },
	"1EtARH7A3xae3xfTQscDR8afq683dBvYuZ": { "n": "faucetbtc.com", "l": "http://www.faucetbtc.com", "v": 1 },
	"1DXq3hJ1xc8ajz1qa5V9MBWiGQGEkFh4CJ": { "n": "BitWebEx Donation", "l": "http://bitwebex.com", "v": 1 },
	"1FMHxhVJo6RREtfaLDVMA1VvoKV1jc12av": { "n": "netzpolitik.org", "l": "http://netzpolitik.org/spenden/", "v": 1 },
	"1FoxubuGrMJg5jf56h2qRjyYQzcrUcBxSf": { "n": "RedditFoxesDonate", "l": "http://www.reddit.com/r/foxes", "v": 1 },
	"1HGub51H32YhUFw4zysMoTazBs88kWJJud": { "n": "openstreetmap", "l": "http://coinmap.org/", "v": 1 },
	"13Eohv7JBRBd4XRCRAgL1n9gFgQKvwdLjJ": { "n": "Samot.org.uk Bitcoin Donations", "l": "http://samot.org.uk/support.html", "v": 1 },
	"12Ui8w9q6eq6TxZmow8H9VHbZdfEnsLDsB": { "n": "MinePeon Donation", "l": "http://mineforeman.com/minepeon/", "v": 1 },
	"18UNd79dmp4okLaBRgmKZzz1s3mSAw2KQY": { "n": "btclotto.de", "l": "http://btclotto.de", "v": 1 },
	"13UG6oTdKgAHDujTZXJXWQsznCgBymwZeK": { "n": "Skami.net", "l": "http://www.skami.net", "v": 1 },
	"18RAfU5sLU2Pz3MzqcT9128EyTDMgURNjS": { "n": "RedditFoxes", "l": "http://www.reddit.com/r/foxes", "v": 1 },
	"1Hb1FsBAhdoLuLh6rgeyTjyRTV9kwyZD5B": { "n": "btc4you.com", "l": "http://btc4you.com/", "v": 1 },
	"1LSUNUUuGWum9hss6rMzx9S4E25Wrwykou": { "n": "Underdogmilitia", "l": "http://www.underdogmilitia.net", "v": 1 },
	"1MEiGq4C9jDT9HmAYwDZn8bNiAUUoCxu7i": { "n": "bitcoin-analysis (IRC)", "l": "http://irc.netsplit.de/channels/details.php?room=%23bitcoin-analysis&net=freenode", "v": 1 },
	"1AQhrfziGW8ozahK8zNDG3ydxeeE4UHewx": { "n": "SCAM", "l": "http://www.reddit.com/r/Bitcoin/comments/1c9vbj/beware_of_the_buttercoin_scam/", "v": 1 },
	"1FHC92swamGHDjBLq6nzKH8x9KW9cJavyJ": { "n": "Ian Campbell", "l": "http://iancampbell.eu/About-Me-Contact", "v": 1 },
	"1SPDM87UUJxqHcnAmyHShezDca11v263i": { "n": "SpreadMaster", "l": "http://spreadMaster.net", "v": 1 },
	"12onJikBcrL1dKXGuT3tw5pQAazr2Dj7hj": { "n": "Give me Bitcoin", "l": "http://blockexplorer.com/address/12onJikBcrL1dKXGuT3tw5pQAazr2Dj7hj", "v": 1 },
	"1Chris11Zho59oV9ttzbtHCtDMr5zS1S2h": { "n": "Chris Schneider", "l": "http://www.vimdrills.com", "v": 1 },
	"1NVHqPo7LaGqNDXF549iVk9yDxdYyfFErJ": { "n": "Btctrack", "l": "http://www.btctrack.com", "v": 1 },
	"1Pzq3NhdVASCXz5EiD2758oV4xJ5psovWH": { "n": "Suspended Coffee in Taiwan", "l": "http://hsnu109128.blogspot.tw/2013/04/blog-post_12.html", "v": 1 },
	"17VyiNJoWBLzc65EjaM1qBVtJMkeD4KAEo": { "n": "PartTimeLegend", "l": "http://bitcoin-otc.com/viewgpg.php?nick=PartTimeLegend", "v": 1 },
	"16YKTNYH4mwtYY6vydkHpfgaGysteT6NjY": { "n": "", "l": "http://www.john.geek.nz", "v": 1 },
	"1Dy91DA8js1uLrKjq8DV3WApgAkBkGBADf": { "n": "Planet Alsh", "l": "http://www.planetalsh.com", "v": 1 },
	"1FvRohzjodKWQVjEoQBCJJtYUvfDpnNQ5r": { "n": "Bitcoinium", "l": "http://bitcoinium.com", "v": 1 },
	"1BULVYwQY1DPwCvHTaveQraJ43A9Va19Z": { "n": "FFFILM", "l": "http://www.fffilm.name/p/ffffriends.html", "v": 1 },
	"15Z8ADxhssKUiwP3jbbqJwA21744KMCfTM": { "n": "nodemailer", "l": "http://www.nodemailer.com/", "v": 1 },
	"12fUCZAD5BJWGyuygUx6t8waVg8PTJV895": { "n": "chibu", "l": "http://ln4.us/", "v": 1 },
	"1comboyNsev2ubWRbPZpxxNhghLfonzuN": { "n": "bitcoinity.org", "l": "http://bitcoinity.org/markets", "v": 1 },
	"1EttqaSSCksRAXrwejoChs5zmGjSikN9mC": { "n": "LorenzoMoney", "l": "http://bitcoin-otc.com/viewgpg.php?nick=LorenzoMoney", "v": 1 },
	"1BwXUekP4sFiR7kcqBxWrCYXU8ZAWQRbFK": { "n": "DOSBox Crew", "l": "http://www.dosbox.com/crew.php", "v": 1 },
	"1Gonhezk1ScHaFqUSYH9VQThaDS4PJSq1o": { "n": "David Schwartz", "l": "http://bitcoin.stackexchange.com/users/85/david-schwartz", "v": 1 },
	"1TumaKwap8rpkLX7TLBvjykNjvYpUQqga": { "n": "TumaK", "l": "http://bitcoin-otc.com/viewgpg.php?nick=TumaK", "v": 1 },
	"16f7NBk47FX49xw6UJb3Wg4L8D2jMK2wFs": { "n": "Realtime Bitcoin", "l": "http://realtimebitcoin.info", "v": 1 },
	"13vCsi1G3rgWu8hutdrMNkT8zyGkgaDaAG": { "n": "SatoshiRaffle", "l": "http://satoshiraffle.com/contest/loft-condo-in-toronto-canada/", "v": 1 },
	"1ivan1niQ9ebRB2keQrT5iZ7PyXFqoTRx": { "n": "Ivan Frimmel", "l": "http://www.linkedin.com/in/ifrimmel", "v": 1 },
	"1Fr33Aidr4gokeCcHHxbnDi8vasKHEaRUm": { "n": "Fr33 Aid", "l": "http://www.fr33aid.com/bitcoin/", "v": 1 },
	"1BTC29DKWcnDgPNGKZTpePFSCX7aAvJY3R": { "n": "BTC Gambling Dices 1", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC28Lb9SuTRDcLWRSJmoqdiET2swjMcL": { "n": "BTC Gambling Dices 2", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC27NCuLSHGycie9eQwYy1YvrQnX6vup": { "n": "BTC Gambling Dices 4", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC267e4JMbisfBo2NJE2mVUNRp7AhTn6": { "n": "BTC Gambling Dices 8", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC25svqBV6pybXQtDV2n6pfNp9UKV8jq": { "n": "BTC Gambling Dices 16", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC24zfcxiNBwUQSwsUQrxMWdW6X9gec5": { "n": "BTC Gambling Dices 32", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC23wyd67sHWL7B9gWPBw8bE75UwZS8j": { "n": "BTC Gambling Dices 64", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC22LKVoQ3prSnkBCf1GtnUEabajiYGb": { "n": "BTC Gambling Dices 128", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC21KZiGPEVxABMQrspJ31fUfPpPoKfs": { "n": "BTC Gambling Dices 256", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC2XFyeo5HdoeQcx8dNYRJoQcMAFDx44": { "n": "BTC Gambling Dices 512", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC19LAFFwr8uXPqXTh5n8URxkY16TbhS": { "n": "BTC Gambling Dices 1000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC18EoRP4i9rY7qyRrmUw6H9A6HNxFC8": { "n": "BTC Gambling Dices 1500", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC17pX7QTNeuLfU5Mck24hFZwYV8aMoW": { "n": "BTC Gambling Dices 2000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC167rY4X9y68zbiz74veoEfsNb4MVej": { "n": "BTC Gambling Dices 3000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC155xEmgZAREkbnATLThWfYa2AJkZLt": { "n": "BTC Gambling Dices 4000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC14JeGUEga3efXsWZSCFZSpt8spBZGW": { "n": "BTC Gambling Dices 6000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC13TmNizKMwiqsxrdRR1nTe9b6J3NCa": { "n": "BTC Gambling Dices 8000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC12rmAxv7JJGZak9SaBrKreWpZK4eZM": { "n": "BTC Gambling Dices 12000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC112W5shWYNHgGZthxCBq6wByyZx3Fk": { "n": "BTC Gambling Dices 16000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTC1XgWQoPDTGB9P9oEfxCphpUFXNSR3K": { "n": "BTC Gambling Dices 24000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTCX98U3S3AHwCh8FkSujpJvVfTCRgbrS": { "n": "BTC Gambling Dices 3200", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTCX8BFZcNTe8dxjHZmEGCKMCpkDcMWx3": { "n": "BTC Gambling Dices 32768", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTCX7fUmCpN4cbJJWHHAAY7ZQXRJLQyRa": { "n": "BTC Gambling Dices 36000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTCX6G1gVqgxUQYStZwHGZhM5ZKcUfXiH": { "n": "BTC Gambling Dices 42000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTCX5t9WUvjdhAZgEb2DGpNqsasQz4Q11": { "n": "BTC Gambling Dices 48000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTCX4V6UwStEJCo9eQMTKu9VfweiFxfWr": { "n": "BTC Gambling Dices 52000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTCX3Q1Fs4svJHMdNCfZS2yrRbRpnKugj": { "n": "BTC Gambling Dices 56000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTCX225JKZadJczi4b8bHazsqVfJ9CPJz": { "n": "BTC Gambling Dices 60000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1BTCX18Bo6kPZyNn2KCXq3h9m3Nn18Cr9w": { "n": "BTC Gambling Dices 64000", "l": "http://www.btc-gambling.net/", "v": 1 },
	"1ppmN57a3zYnEkevTrCDU5c7GBs3AguYW": { "n": "Zhou Tonged Bitcoins Back", "l": "http://www.youtube.com/watch?v=jq57BjBVq7o", "v": 1 },
	"1RhodonBkTHyna6xSBY8Bb8wJDdJoVpTL": { "n": "Rhodon", "l": "http://bitcoin-otc.com/viewgpg.php?nick=Rhodon", "v": 1 },
	"1CSbBAvjMhscMfyQzVV24RSGffQabMhpK8": { "n": "elbitcoingratis.es", "l": "http://www.elbitcoingratis.es/", "v": 1 },
	"1MATH16uCXKSQN9VAUAoPsWXKWhinrJiJv": { "n": "Rhodon", "l": "http://bitcoin-otc.com/viewgpg.php?nick=Rhodon", "v": 1 },
	"1aiBPLdHEW8wu9WpufdBT7kpJRCkGR9P1": { "n": "London Hackspace", "l": "https://london.hackspace.org.uk/donate.php", "v": 1 },
	"1FexWDptSXFWsZvdLoBckZgVFWytHjsSu8": { "n": "Seasteading Institute", "l": "http://www.seasteading.org/donate/", "v": 1 },
	"1JWsjwcgeQVmAcAUj8R4afnF5x3xpWPF9F": { "n": "David Seaman", "l": "http://www.youtube.com/watch?v=9TfDQYkszDE", "v": 1 },
	"19ZYkup2xSwqiJFbc9YBRXtFYvVVHhXDA1": { "n": "bullerbyn", "l": "http://bullerbyn.pl", "v": 1 },
	"196Hk6Qmxwv7PwpeyhpyNZaTiuSbPAdC3A": { "n": "retrominer.com", "l": "http://retrominer.com/", "v": 1 },
	"1LVyTtygdCnESJcQWE136nxKjNr6s4qB5f": { "n": "vanheusden.com bitcoin page", "l": "http://vanheusden.com/bitcoins/", "v": 1 },
	"1GCAfZdNjU4ZjQuUKosZ1xcR2SZJK3uCBe": { "n": "canhasbitcoin.tk", "l": "http://canhasbitcoin.tk", "v": 1 },
	"1GRWQA3wLGL9i5aW371Nd1HnF4QaBNEGxG": { "n": "pinballcoin", "l": "http://www.pinballcoin.com", "v": 1 },
	"1pinqq3aYWTjBvyr9UjkXJDagFvWXYKP9": { "n": "pinballcoin", "l": "http://www.pinballcoin.com", "v": 1 },
	"1J1KhmZxShdEqUpbcTo5VtzJjr6H6nHFME": { "n": "lukegb", "l": "http://bitcoin-otc.com/viewgpg.php?nick=lukegb", "v": 1 },
	"1KARoav2wCP7cTdkTm2poL9JJ3LSzBDUKa": { "n": "karoshi", "l": "http://bitcoin-otc.com/viewgpg.php?nick=karoshi", "v": 1 },
	"1satoshipK52JiSJvaw6K2UKV8DKzk1iY": { "n": "Satoshi", "l": "http://blockexplorer.com/address/1satoshipK52JiSJvaw6K2UKV8DKzk1iY", "v": 1 },
	"1BitCoiN4KJ9crg4S9JiQBz4pwYKSAJwcG": { "n": "Bitcoin", "l": "http://blockexplorer.com/address/1BitCoiN4KJ9crg4S9JiQBz4pwYKSAJwcG", "v": 1 },
	"15pfHVAaLrdQYgPLasdauar7nQ8CTnBJrf": { "n": "Lasduar", "l": "http://bitcoin-otc.com/viewgpg.php?nick=Lasduar", "v": 1 },
	"18As5Cr9K9urMiJVwLLQqyY3wAzvwVeUsW": { "n": "Nguyen Xuan Hoan", "l": "http://xlooter.5gbfree.com", "v": 1 },
	"1QEwimjvW3g4QFC21GFpgK2HpkSeakCCZa": { "n": "Online Poker Freerolls USA", "l": "http://freerollinsider.com", "v": 1 },
	"1B7hLrgymDzmQyS4c3pdFYwP9tbyE9qpVQ": { "n": "James Taylor 2012", "l": "http://www.reddit.com/r/Bitcoin/comments/1bnbmy/greetings_from_nigeria", "v": 1 },
	"14BN8Qj43zebrSo58J8BxGoPFBHtw9t6Y2": { "n": "scam", "l": "http://www.reddit.com/r/Bitcoin/comments/1bobyn/coins_for_kids/", "v": 1 },
	"1DA1Lz3zmr5hLgCZdX5N9QBBj26iDzCBou": { "n": "Erowid Donations (Feb 2013)", "l": "http://www.erowid.org/donations/donations_bitcoin.php", "v": 1 },
	"1EJo2Kern8mtLYUyDiYo6dNWzvuc83PqaA": { "n": "Scammer - Manuel Roldan Arroyo", "l": "http://pastie.org/private/koeaa64ujsjzuvxpmqvcg", "v": 1 },
	"13bZpkFXNVmBLDu4HiFGVaW56RCr3yePVJ": { "n": "scam", "l": "http://www.reddit.com/r/Bitcoin/comments/1bnbmy/greetings_from_nigeria/", "v": 1 },
	"153ByrauFUsm2uA5Pp2j9T7cF5tMcEF6XG": { "n": "Nick McLarty Donations", "l": "https://www.inick.net", "v": 1 },
	"1EGbxDw3FQd5DgAwnoPcvoVsgW8z514kdA": { "n": "NoctumDesign BTC Pool", "l": "http://mining.noctumdesign.com/page/home", "v": 1 },
	"1Mh8UuoUDBq4TGSi7F11QNEfbmdf2qvx57": { "n": "Free", "l": "http://www.voy.com/230349/", "v": 1 },
	"1CURSE1UbjvC7LrsH8QXRRQXC1ZBXb8w9B": { "n": "Bitcoin Curse will hunt you!", "l": "http://bitcoincurse.co.nf/?p=1", "v": 1 },
	"1pbarBA4zP1bbCRydBUxweQxVfsaAHqDo": { "n": "Progressbar Hackerspace", "l": "https://progressbar.sk/contact", "v": 1 },
	"17VhhELY4F9j9hhrTCGVCU2GCxQSs8d94X": { "n": "testing", "l": "http://blockexplorer.com/address/17VhhELY4F9j9hhrTCGVCU2GCxQSs8d94X", "v": 1 },
	"14zoTKB29NdsJRvk4qP3vB9mQZ3dcV3eWk": { "n": "Listentobitcoin.com", "l": "http://www.listentobitcoin.com", "v": 1 },
	"13Jww2WChsxvsB1UB4qtDP9vP6ZcH4P2R8": { "n": "BitSprinkle", "l": "http://bitsprinkle.warp-6.net/", "v": 1 },
	"13DE5wSNA8q46JSuQtDyCJ5bzkcsxS6Akk": { "n": "RealTimeBTC", "l": "http://www.realtimebtc.com", "v": 1 },
	"15eEeWzcY9TjPJAjh1ydFrfXi8xDtULN2y": { "n": "Zhou Tonged Cypress Anthem", "l": "http://www.youtube.com/watch?v=OMAI-OIxLPo", "v": 1 },
	"1K2XgRxm4K8hbbtBTrPePwBWG2dTW23S54": { "n": "mt-aws", "l": "http://mt-aws.com", "v": 1 },
	"1BuFaLavtRq9xA94mp6g9hsQ6YWLrZibEj": { "n": "medsforbitcoin.com", "l": "http://www.medsforbitcoin.com/", "v": 1 },
	"1GojEL4xjHSUkAuf9PWTH9NRUn3txEWNPy": { "n": "syntagmatic", "l": "https://github.com/syntagmatic", "v": 1 },
	"1666aUqVHnqX9qg7SBT8wb8Sae8Ws8kUY4": { "n": "feindura CMS Donations", "l": "http://feindura.org/page/download/", "v": 1 },
	"1whiskD55W4mRtyFYe92bN4jbsBh1sZut": { "n": "whiskers75", "l": "https://github.com/whiskers75", "v": 1 },
	"16dybY71fDTQ5iTcqQausvZhbP2W4yXL3L": { "n": "DeeBG", "l": "http://bitcoin-otc.com/viewgpg.php?nick=DeeBG", "v": 1 },
	"1JJtojxeS5MLiP4zV6cb2eXaQiGghethjS": { "n": "mithrandi", "l": "http://mithrandi.net/", "v": 1 },
	"1Pg5hTxEbdTHz2jMFrBA8CV8YzB8EusvhB": { "n": "fuz.su", "l": "http://fuz.su", "v": 1 },
	"1FbDDrp8VPhbHs19jdND5xxUKgevEWT8jr": { "n": "giladby", "l": "http://benyossef.com/", "v": 1 },
	"16sKgbMZXqTWJm9XfmYyHKixerdqCs79Ef": { "n": "MissingMyCoins", "l": "https://gist.github.com/anonymous/5210596", "v": 1 },
	"1BHErRZJxK6WN76MTyEewTdhz57WA1neND": { "n": "MissingMyCoins", "l": "https://gist.github.com/anonymous/5210596", "v": 1 },
	"18JDQvJZ6PNFNgu4RgPp3M8RdFjFKRTZYV": { "n": "MissingMyCoins", "l": "https://gist.github.com/anonymous/5210596", "v": 1 },
	"1L1jHZ6WqotLXe8xv9Rje2BQZENBAMMmY8": { "n": "MissingMyCoins", "l": "https://gist.github.com/anonymous/5210596", "v": 1 },
	"1MxLCVfNfMh9CdVxspPe2ASjrgZEk6wCbJ": { "n": "MissingMyCoins", "l": "https://gist.github.com/anonymous/5210596", "v": 1 },
	"1MX6PgeeoHvchXFauXJLqibboKWZzsdjrG": { "n": "Betcoins", "l": "http://www.betcoins.net", "v": 1 },
	"1N6weNFroYC54w54KMV3Pwb1mY2MeR3iJA": { "n": "Betcoins", "l": "http://www.betcoins.net", "v": 1 },
	"1EHVb2YJqm8srkGq1LwwR2tG3RWuUQ7bJG": { "n": "Betcoins", "l": "http://www.betcoins.net", "v": 1 },
	"1AZ1oXXwgsgWgMfN3brGpDQc7JM7xkEtKR": { "n": "Betcoins", "l": "http://www.betcoins.net", "v": 1 },
	"17aDRzRQK8ccBLVBzsms3ZasVKc9q3o3Qk": { "n": "Lifeboat Foundation", "l": "https://lifeboat.com/ex/donations", "v": 1 },
	"1NWnXjpZkB1tAurumcDkM4mhawzJGM9ngv": { "n": "BitAurum.eu", "l": "https://www.bitaurum.eu", "v": 1 },
	"1CoinBitU8ise6v2jYBSxYc1PUGW2o4VRn": { "n": "CoinBit", "l": "http://coinbit.tk/about.html", "v": 1 },
	"1GL4H4RUUPj7Q9FG8zh9vxcxcBc16NwZ4k": { "n": "Zhou Tonged Holding", "l": "http://www.youtube.com/watch?v=NG1qooBzE2w", "v": 1 },
	"14G9xZWU1gFpPq8jkxYLbkJDxHWr8NgbD3": { "n": "Zhou Tonged Bitcoins Here", "l": "http://www.youtube.com/watch?v=pID03RrmKow", "v": 1 },
	"167rjYraKtiWcpW7VvJL9kE4eLcSCECzWg": { "n": "Zhou Tonged Bitcoins Back", "l": "http://www.youtube.com/watch?v=jq57BjBVq7o", "v": 1 },
	"1GNCie7qmDKvPHhHmVmqpYHkY689Xx3wkU": { "n": "Legendary Faucet", "l": "http://legendaryfaucet.herokuapp.com/", "v": 1 },
	"1Cvvr8AsCfbbVQ2xoWiFD1Gb2VRbGsEf28": { "n": "Blockexplorer.com", "l": "http://blockexplorer.com/", "v": 1 },
	"13cdhG4x6qCVMxd9vrdE9Vwi1Nza9kr83G": { "n": "hrabbey", "l": "http://bitcoin-otc.com/viewgpg.php?nick=hrabbey", "v": 1 },
	"1BizDivGpckAWiRHcD1RwLSTXrbiea8swn": { "n": "Biz27B-6 Dividends Accumulated", "l": "https://bitfunder.com/asset/Biz27B-6", "v": 1 },
	"1BizMar58Hr3D4EvNmnPnGfuGCVfo1UWzL": { "n": "Biz27B-6 Marketing Account", "l": "https://bitfunder.com/asset/Biz27B-6", "v": 1 },
	"1BizWagyjAgrJaFUm1kJPQXHDGCc1Kgsxk": { "n": "Biz27B-6 Wages and Salaries", "l": "https://bitfunder.com/asset/Biz27B-6", "v": 1 },
	"1BizExpCwCRSLzTwymXGuwPAharPJJt9zK": { "n": "Biz27B-6 Expense Account", "l": "https://bitfunder.com/asset/Biz27B-6", "v": 1 },
	"1BizRevFnLdafsMKACX1rPptFLtAaqChwk": { "n": "Biz27B-6 Revenue", "l": "https://bitfunder.com/asset/Biz27B-6", "v": 1 },
	"1BTCbbjWTym3yD2hGHDedGgGB9TpHb1gic": { "n": "BTCbb", "l": "http://btcbb.netne.net", "v": 1 },
	"1Ect1J4BETE98SBt9vd4pddsMdYQqyp6jj": { "n": "Bitcoin Mining On Raspberry Pi", "l": "https://gist.github.com/PartTimeLegend/5170990", "v": 1 },
	"1AZYFvZCyAuSjT5SWHeRxKMiMJ62tQZ8cS": { "n": "bitcoins4.me", "l": "http://www.bitcoins4.me/", "v": 1 },
	"1KUPFYx2irydjgMLoBg3crHTqzfZJob6u6": { "n": "FunWithBits.com", "l": "http://www.funwithbits.com", "v": 1 },
	"1SwagDQquoqokQCt4kEkY5HFY64BEZ6o1": { "n": "qwertyoruiop", "l": "http://quartz.devkipz.us", "v": 1 },
	"1LQTXi1iWULMd4aKn5tKpcgT3xgJiTV5Dm": { "n": "coinbase-trader", "l": "https://github.com/martindale/coinbase-trader", "v": 1 },
	"13yRijVAANYoHRyFHRNeNFghzFK8YeutAF": { "n": "bitgarden.com", "l": "http://btc.to/6qm", "v": 1 },
	"1MuNPrfNMho5UP9312m3idzauwaCi57fLe": { "n": "bitcointhedocumentary.org", "l": "http://bitcointhedocumentary.org/wordpress/?page_id=61", "v": 1 },
	"1NRfpsqavNut3eKKgXhLn9XgzrwbLmhiYA": { "n": "BitVegas Minecraft", "l": "http://www.bitvegas.net", "v": 1 },
	"1NadVDZGSChYzZGRzJeHyjq68an25sZK4v": { "n": "Instytut Misesa", "l": "http://mises.pl/wsparcie/darowizny/", "v": 1 },
	"13JSvfkcLH66nHZihNVSqL6K8HMcqjFXMd": { "n": "dotnetopenauth.net", "l": "http://www.dotnetopenauth.net", "v": 1 },
	"1Armory1HBqc8dNEvHDuT9AYWPWf98aCzJ": { "n": "Armory OSX bounty", "l": "http://bitcoinarmory.com/get-armory/", "v": 1 },
	"14oYcNZR6CRCe826a2SY3SdqdCTsEk3LWt": { "n": "CLEAR - Cannabis Law Reform", "l": "http://www.clear-uk.org/bitcoin/", "v": 1 },
	"1spin2Nmucj3Vbc3eaEJWKZZo8ss9mck9": { "n": "Test Spin", "l": "http://www.satoshispin.com/", "v": 1 },
	"1spin9pkRw172owbnLrRmwM4uddPP48Um": { "n": "Weekly Spin", "l": "http://www.satoshispin.com/", "v": 1 },
	"1spinWcLw2Mutb4omC7g2AeyDVZRRjz5j": { "n": "Daily Spin", "l": "http://www.satoshispin.com/", "v": 1 },
	"1spinBgpeB4QxVpmF1q2XipxeYxNMHfoR": { "n": "Fast Spin", "l": "http://www.satoshispin.com/", "v": 1 },
	"1H9WkVhTC75rdG8x24y7mZWMVTpQoWL48F": { "n": "dantavares", "l": "http://agotafria.blogspot.com.br/", "v": 1 },
	"18krgoMr5yNRX8dAg1XTuxXmCpvwzDxRgu": { "n": "Bitcoin Exchange Auto Hacker", "l": "https://github.com/PartTimeLegend/BitcoinExchangeAutoHacker", "v": 1 },
	"1hash15iQZBK9a2KXiz5Hpn3851gFLg1y": { "n": "Hashluck", "l": "http://hashluck.net/", "v": 1 },
	"1GtudyamynadVykxHRz8mU4bsPVwCyYGBG": { "n": "cyang", "l": "http://blog.sciencenet.cn/u/sterlesser", "v": 1 },
	"17t38uNHC8YCgTpntZ6igito5ysbkeeGce": { "n": "Help Fund FREE WATER Machine", "l": "http://www.Metaballo.com", "v": 1 },
	"12wSisgie8MHXHdvmFRWQj59HZrH6C7Zz6": { "n": "fr33aid", "l": "http://www.fr33aid.com/bitcoin/", "v": 1 },
	"14hSGGYXa85UbjryvkdMFKwJe3McFi6Ww9": { "n": "Bitcoin POS Donations", "l": "https://github.com/PartTimeLegend/BitcoinPOS", "v": 1 },
	"1CAZizNt53tSiup7Gtqhk3U4inRHhfxUU": { "n": "MaMardom Campaign", "l": "http://www.mamardom.com/donate/", "v": 1 },
	"1LokQrHj14NU93tC6pZfTZyyRHhAVakQmX": { "n": "BtcShares", "l": "http://www.btcshares.com", "v": 1 },
	"1JPvucRfu3ZzEvfBUQTJwsxMrZjeTqD6zR": { "n": "MPOE", "l": "http://polimedia.us/trilema/2012/sa-ne-jucam-de-a-investitiile-n-bitcoini/#comment-78745", "v": 1 },
	"1Fx3N5iFPDQxUKhhmDJqCMmi3U8Y7gSncx": { "n": "MPEx", "l": "http://mpex.co/faq.html", "v": 1 },
	"1GafterN8LEoQXutwGdLMkEQSCh2V9Xyyu": { "n": "Neal Gafter", "l": "http://www.gafter.com/~neal/", "v": 1 },
	"1cBTCvKJ5wPT7eahxnpZqYpCpKRduCpWH": { "n": "Checkmybitcoins.com", "l": "http://checkmybitcoins.com", "v": 1 },
	"16ickTbiTaURuMUPRNPvs8BykvVsMdPmdZ": { "n": "BitAurum.eu", "l": "https://www.bitaurum.eu", "v": 1 },
	"1PdYaT9ygvVSoYZTjEibUJUB5rqzEx8okj": { "n": "BTC Mining Blog", "l": "http://btcmining.livejournal.com/1035.html", "v": 1 },
	"1F6aqFvwTteu6bmVG92yqswrkaQkjRwbUZ": { "n": "Keyfur", "l": "http://www.keyfur.com/", "v": 1 },
	"1N5sJeuxCCtG8mXxhgHD3H7W5FWTHK3H21": { "n": "torservers.net", "l": "http://www.torservers.net/donate.html", "v": 1 },
	"1MSPNCxZUTnkKBCrmhUpqJqWCtJWeXkgeY": { "n": "BurnOne", "l": "http://auntnancyscandles.weebly.com/", "v": 1 },
	"1Le9mGe4Vg5XgJMAJRS8DQ6emvptzbSQDD": { "n": "BitSprinkle", "l": "http://bitsprinkle.warp-6.net/", "v": 1 },
	"1EDwgp7zixNAbvhyqWJjDHDAMTfmf8BvDy": { "n": "humla", "l": "http://humla.info/index.php?q=page/manifesto", "v": 1 },
	"14hBAaBzjCkR6uYCAUJa27okdXrukQVjTN": { "n": "grsecurity", "l": "http://grsecurity.net/donations.php", "v": 1 },
	"1MikiSPbrhCFk7S4wzZP7gQqhwWH866DCb": { "n": "Michele Spagnuolo", "l": "http://michele.spagnuolo.me/about/", "v": 1 },
	"1btc4e23uAfMWZNxNGbrzMUxA5SnVZn2T": { "n": "BTCForMe", "l": "http://www.btcfor.me", "v": 1 },
	"14Z1mazY4HfysZyMaKudFr63EwHqQT2njz": { "n": "bitcoinmonitor.com", "l": "http://www.bitcoinmonitor.com", "v": 1 },
	"1DeBD3rM3MPDS6ZU6ojTsw57BPwXDB2oGK": { "n": "bitcoinexchangerate.org", "l": "http://bitcoinexchangerate.org", "v": 1 },
	"1EUshGGz6KdsRJioozqFmn4FHQk4z3Ggxg": { "n": "TeamWin Project", "l": "http://teamw.in/project/twrp2", "v": 1 },
	"1Gr6sVuvQqqFMh2doMYYpEdGAtVbtfBw9B": { "n": "OSEG - all projects", "l": "http://wiki.opensourceecology.de/wiki/Spenden_generell/Bitcoins", "v": 1 },
	"16ArwQDYoSX2WufRpDjLeoUDHebqt48cft": { "n": "OSEG - Project Wind Turbine", "l": "http://wiki.opensourceecology.de/wiki/Wind_Turbine_Campaign/Bitcoins", "v": 1 },
	"1BboU9QH4kcNeDqdr7xBUZ4GrFgfhNaVBd": { "n": "BUND Berlin e.V. donations", "l": "http://www.bund-berlin.de/bund_berlinde/spenden/bitcoin-spenden/BTC_eng", "v": 1 },
	"14SFeny1LRs2udUPBCwR9FRYpNAYGd9JJi": { "n": "ragmondo", "l": "http://bcfxer.appspot.com/", "v": 1 },
	"1EwtTKJaXAtctSFqCQKU3LiCg9dqYPEkxN": { "n": "NastyFans", "l": "https://bitcointalk.org/index.php?topic=86854.0", "v": 1 },
	"1JqdadgxgxrnbEnfvohxtaSNbHt52kVLtC": { "n": "BitMillions.com - Pool 4", "l": "http://bitmillions.com", "v": 1 },
	"1ETya2BCpwgTuz88ubiLPf2kUvMpUymhBq": { "n": "BitMillions.com - Pool 3", "l": "http://bitmillions.com", "v": 1 },
	"1EnHPvDZfG9CzwK4Ai9ZpT6t7iJWPSCp77": { "n": "BitMillions.com - Pool 2", "l": "http://bitmillions.com", "v": 1 },
	"19tvjv1sqBgnUWqijZDvfoub6ZzZkC3M6x": { "n": "casascius.uberbills.com", "l": "http://casascius.uberbills.com/donate.php", "v": 1 },
	"1HSDNZYfcevZBNCZjj4y5wyxzbc79a6y32": { "n": "BitMillions.com", "l": "http://bitmillions.com", "v": 1 },
	"14TYdpodQQDKVgvUUcpaMzjJwhQ4KYsipa": { "n": "bitcoin.sipa.be", "l": "http://bitcoin.sipa.be", "v": 1 },
	"1Gka8G1Lf7uBicayMTjscahpAh2Hk8hEoJ": { "n": "PDMC Electrum Donations", "l": "http://electrum.pdmc.net/about", "v": 1 },
	"1K5LzPQeVNWP1VkRTD8DHvxcNyD4CRs1xp": { "n": "minetopics.blogspot.com", "l": "http://www.blogger.com/profile/01142778115578644906", "v": 1 },
	"16JvgYjyTNxgJsc2NS3tTrM8QE7721Fzrn": { "n": "bensonsamuel.com", "l": "http://bensonsamuel.com/home-2/about/", "v": 1 },
	"1Beer1BofaGENk8HmCjD4BhuLGPv4aoN5i": { "n": "BeerPong.bg", "l": "http://BeerPong.bg/bitcoin.html", "v": 1 },
	"1DVipMAKrZgtmVVcQfPG3qWkAEB2NPW3Nf": { "n": "Free Talk Live", "l": "http://www.freetalklive.com/bitcoin", "v": 1 },
	"1NxRxasGJTzUifTbcvbxoReWC1s48sP9Nr": { "n": "Dia Open Source Donation", "l": "http://dia-installer.de/support/donations.html", "v": 1 },
	"15TaABLmhxiRQ9DTX6ZcZ9S9RknVZmP5jX": { "n": "TAABL Pick 5", "l": "http://taabl.net/", "v": 1 },
	"14TAAbLiw2QLuRJCGQ3iETYg3vcpweZkTE": { "n": "TAABL Pick 4", "l": "http://taabl.net/", "v": 1 },
	"13TAabLHjNzwg8Mj7XYn76FuVAqj32s8EM": { "n": "TAABL Pick 3", "l": "http://taabl.net/", "v": 1 },
	"12tAabLFLxvUzC5KuX7VKMM8bYRncbQ84E": { "n": "TAABL Pick 2", "l": "http://taabl.net/", "v": 1 },
	"19b62wRL6hGEWa1bLbkdjaiWvZm1C56XuL": { "n": "donateathome.org", "l": "http://donateathome.org/", "v": 1 },
	"18w5k5nJtAjR55aYhDViS4hkiJTMWBf2sa": { "n": "Porc Therapy", "l": "http://btc.to/68m", "v": 1 },
	"1AkZUyVHtVsU6ZmAu1iSDhYiXbqFgKqzbt": { "n": "The Liberty Radio Network", "l": "http://lrn.fm", "v": 1 },
	"1DWepSWJ7YQjDk6BTbihV7ggmj6sWbtqae": { "n": "Justus Ranvier", "l": "https://bitcointalk.org/index.php?action=profile;u=14492", "v": 1 },
	"14gZTuHA4xa4gJQBubn5fj3b4D4QHEDdwY": { "n": "blockviewer.com", "l": "http://blockviewer.com", "v": 1 },
	"13QTW27b3SgqrEjefB9PbiZ6hcrVCJAxfx": { "n": "PayB.TC Donations", "l": "http://payb.tc/donate", "v": 1 },
	"1DUNaNdUaQPXweTMUmd1ma3KjLKFiDcxXk": { "n": "Dunand", "l": "https://bitcointalk.org/index.php?action=profile;u=13832", "v": 1 },
	"1MLxhUkM9NcpQMqGTvECaQ4q5vmvJ77rYj": { "n": "bitcoinity.org", "l": "http://bitcoinity.org/markets", "v": 1 },
	"1GRJ6119tmKDUfr8HWR4VaYrvJ6oKns9jp": { "n": "jonls.dk", "l": "http://jonls.dk/", "v": 1 },
	"1KmeFEHqAH3gC42gB3BtQadd1LWxnaFmNs": { "n": "Bitcoin Faucet", "l": "http://www.bitcoinfaucet.at/", "v": 1 },
	"16c967LEtqBJByCSQC358yoFpJgzHVC346": { "n": "BTC Multiplier 6789C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17HShGAstqFwbow76oz4GCWyjXTgA1MMAX": { "n": "BTC Multiplier 6789B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DFwBvWNx57KHJqKZUhyYr87C2jifnKPFD": { "n": "BTC Multiplier 6789A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15a2pjmje4EUZrvcJqQpAaaJHfPAeYkngy": { "n": "BTC Multiplier 5789C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"123pGSQWQXUxF48xUcaeX76eHc6dYnFpJD": { "n": "BTC Multiplier 5789B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18H6ETzb7KkHeQc2zNgX3RMczR7VnEAGej": { "n": "BTC Multiplier 5789A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15JUiacFganpAFTV9cmZ1693UpcWYe4PSe": { "n": "BTC Multiplier 5689C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17cVKhjcQQ6vzbaQxXfe9NJW69KCezAYWf": { "n": "BTC Multiplier 5689B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JPYarFAYEFSAzunMzeGg4K12wK4HvNthy": { "n": "BTC Multiplier 5689A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MoEpDSkXSMpXpy5pWJrq3cEeMebprEHJ4": { "n": "BTC Multiplier 5679C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1L8om3UM9rzv9eXcwBTBW7y5mvKUx1sqf9": { "n": "BTC Multiplier 5679B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EAjXiSTA9VJaMqXHhehjN6Z6jmYmFW8mr": { "n": "BTC Multiplier 5679A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DwiPXWEPZ6z21kysLRFWd18d1cchRPtwg": { "n": "BTC Multiplier 5678C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1999vPKrjUetJYRUaBLTnevpHCD1S7sSHi": { "n": "BTC Multiplier 5678B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AzWSd4kJvYJUMUcss7j19pAydaZSYAjc3": { "n": "BTC Multiplier 5678A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LgemyVgFghTA1QCAXJKoQpLta2Tfa1g7y": { "n": "BTC Multiplier 4789C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14BojwXZwS2iepDCM4URsfkP3EQQvUM5HU": { "n": "BTC Multiplier 4789B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18J9seDdJPsmhPSjvnP8FSPkTHLwNKGdQj": { "n": "BTC Multiplier 4789A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16Y3yUKpAPkX76aEJwqdDotxFdfLdHdF8F": { "n": "BTC Multiplier 4689C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1E6bSVrvoagjHPf2f2VnEZparx7bgHhHV": { "n": "BTC Multiplier 4689B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12EsY2CG7GSNJ5B9446pLJk4B8pbeGjUKm": { "n": "BTC Multiplier 4689A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GTqtyGwEwD5ftizoA1hptLnouwihi7Ctv": { "n": "BTC Multiplier 4679C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14xWrnggne9h2DYiHAzPyv9xVUktd9tf5L": { "n": "BTC Multiplier 4679B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1H9AVW4PbzBuyUiCsvMUfTFruG3G2V6DwQ": { "n": "BTC Multiplier 4679A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FbzCJdTvuy9pyh7FN4diyQJUYuvotZD2B": { "n": "BTC Multiplier 4678C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"157ke1vRQDvis5Gwmx8ThjRZsoiu47btGr": { "n": "BTC Multiplier 4678B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AocqDckGaoUmG2VLj4q6iXiCruchkGX5v": { "n": "BTC Multiplier 4678A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Kq93X2R7ZoTJKpsjPsWUFNCfaidZeb2gq": { "n": "BTC Multiplier 4589C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1QDdtcPTWETqhr4gqtiFSR3N5WB5B2aM7z": { "n": "BTC Multiplier 4589B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LmvBd6NFtdwTbAXKvpDMsYZKsG7JbBMRj": { "n": "BTC Multiplier 4589A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DvgoJVEsKMJSJcNGxNmrJQuJA9vg7qsaM": { "n": "BTC Multiplier 4579C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KvZ6cAfDeGHwuwfwbxNgRNmziCjWvtm5B": { "n": "BTC Multiplier 4579B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CpyGHb4eje158NSZUnYJkpS6QmPCjsnwd": { "n": "BTC Multiplier 4579A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16zk6oD7s8MmqDDkMWtpuE2nhKPXKDPUGA": { "n": "BTC Multiplier 4578C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Gamo9wY58Qc3gHpN7ti1aCv4sBNksssQj": { "n": "BTC Multiplier 4578B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NUctLqCcvsQhoJqbQ7pFGrWT4E628dZva": { "n": "BTC Multiplier 4578A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Bh1Fwt1JEF3PWgqRnUuxdjoQG9Pu5Cj5f": { "n": "BTC Multiplier 4569C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15Yx7KnQ91oxC5GzZJZfCbzExV2xC5UP4B": { "n": "BTC Multiplier 4569B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DYRvohXLsN3btLRotrXHB8fkCoDeLrPbg": { "n": "BTC Multiplier 4569A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17VsY12paEwQYNR1aScaP3LjZTVbWCfAXH": { "n": "BTC Multiplier 4568C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18ERb6sN26rEjM8rxXDXuU44T2tbGqJedL": { "n": "BTC Multiplier 4568B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"192uzEW58gPN2YB2stU6msh2Weg7v8RWbG": { "n": "BTC Multiplier 4568A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16sJbPvfySe49qiGxmiBxqGDd9r3f21mht": { "n": "BTC Multiplier 4567C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BaAyNjMhhWCEMJAr99Tia4vpRBy2D4m24": { "n": "BTC Multiplier 4567B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Hqhb5JxptGaFvFV9PLp3YfhV6LnbZVvex": { "n": "BTC Multiplier 4567A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JUQzvX67b3DVbWpx8SdNbzwABnTCF8T4d": { "n": "BTC Multiplier 3789C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NWDrytu3A5c9Chm28rq2GFzdiHCp5iTG9": { "n": "BTC Multiplier 3789A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"181KegGSD4BL9ZBYSHkSuetpt3GLBFEvX7": { "n": "BTC Multiplier 3689C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1P5ZaeTXG61ZfoFFM41eWoc661WqoUPWmr": { "n": "BTC Multiplier 3689B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"178UVPL7HxfadoprTTtP7uUQSqVgQzQprZ": { "n": "BTC Multiplier 3689A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17oy7WdcN47xVbmfT6pfBtTPJ3J3DdfWaV": { "n": "BTC Multiplier 3679C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EdPsRdjiEYQHdn9VKXdXo53PS3kuRyVQx": { "n": "BTC Multiplier 3679B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ntt8yKXqsh9GeRd4Za6edgj1aGqP7E4Dy": { "n": "BTC Multiplier 3679A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Fd4hvUsfCKbkuALEJwFGP7aUUqUvPR2qv": { "n": "BTC Multiplier 3678C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1D8EPYJd4DPVT4X4MpGDjKhzWKmfq3wUi6": { "n": "BTC Multiplier 3678B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GW5gynUU38bKJzWrKsKsaPVW2LL38dwee": { "n": "BTC Multiplier 3589C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13heFZxnD8Dy7vgXi9cDQg9cuVWJdydybH": { "n": "BTC Multiplier 3589B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19AH1Bt3tKShshreusBsq5bmX9dEHq8iWj": { "n": "BTC Multiplier 3589A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1bSMYQCt74q3KkuX3DSpvVCL5DfqRJyDv": { "n": "BTC Multiplier 3579C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FuuqNbfPFNVAGgRXxNKuDzs21CN3wTzsv": { "n": "BTC Multiplier 3579B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NtTnhGmJEmdj98T1tQL6TAukQCDEXC6ap": { "n": "BTC Multiplier 3579A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JEhUg47pTJWYuyxL41tQXxVsFLWQ5Xiua": { "n": "BTC Multiplier 3578C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HhQz5wDoGi4NnTWKkSpBEtW6Ny4kRKkjy": { "n": "BTC Multiplier 3578B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1UcaLsaATDi3P1YWDjRaQp5ZGRCTV6kmB": { "n": "BTC Multiplier 3578A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Pp9yqs9Sv34SVp15QnLbTqGscTXdtBdrD": { "n": "BTC Multiplier 3569C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1C2X3Wm5KKbGW8S4sf8ManyzQgbgvmW8ac": { "n": "BTC Multiplier 3569B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BxQZq9YpxaXvj9hSV5bkS9aiBk7KzLDfZ": { "n": "BTC Multiplier 3569A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1N1jxgaAA4pRnpEPZswBQUVZcWz494cHms": { "n": "BTC Multiplier 3568C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MRCxNMGR9rrx4JWxjbB8d6GRDUhAhJofh": { "n": "BTC Multiplier 3568B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LBoshwsSJfSi1UBfP3PP5FYVZUkHAgBso": { "n": "BTC Multiplier 3568A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1N1CmaMRrRLw3KywmopmxQksuxyb95YEST": { "n": "BTC Multiplier 3567C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12r2JWbZfxFXWZuVazcrhiA2DSgmNkExwW": { "n": "BTC Multiplier 3567B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12JHFi7cRqq9LzrgNfGTnj7jGx4KDcmsUu": { "n": "BTC Multiplier 3567A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FWnhDDWTQFpJQxLEj2cuMkPVFCCk3K1aj": { "n": "BTC Multiplier 3489C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14fYf8VPsc8X4zyWubZfjGCLemSUBsL2vH": { "n": "BTC Multiplier 3489B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ApJYJPfMr2jzBCqkgySHdjENnQhLdd7s1": { "n": "BTC Multiplier 3489A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EndFD8HLLurqFybGg2xsXCdbXAx2UVRWU": { "n": "BTC Multiplier 3479C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Kg6EexBFCzQWFYyLHctJQwtYubCUpeUGn": { "n": "BTC Multiplier 3479B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FJgBZ6NPPQeHbwcnfwkiSZCWsgPgmdrJp": { "n": "BTC Multiplier 3479A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1B9fu4KnJR6TWcuzMNnTzjyburg6Pk9Ah": { "n": "BTC Multiplier 3478C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HyV1u8EUiVDxkLWL4EXdiaeNMHr81Uwet": { "n": "BTC Multiplier 3478B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HSPdRyyFpTd2mr2Q5eWgx4g13HKa513CS": { "n": "BTC Multiplier 3478A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ag9BWgGMPVgDE4UNpjfRwhw1ENiis7Dan": { "n": "BTC Multiplier 3469C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DNSYot2SsuTgZLS3SiwoY7B83Mq7YzxRq": { "n": "BTC Multiplier 3469B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1L29RbYT4EUrKqdaDzHrVCYsdEFSfjr5hM": { "n": "BTC Multiplier 3469A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19eH1Lr3qxh71TgGuFpvz8suJ2sHeHv9um": { "n": "BTC Multiplier 3468C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CJHhaAscRjGLwPPRYeW8WBmydVymWtZHr": { "n": "BTC Multiplier 3468B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12KKXjoC4zz6NmJSxQKVBmwvTvi2T8wNme": { "n": "BTC Multiplier 3468A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CkoC4SQNicHrschfBLy3saTW6gcUBN9Qu": { "n": "BTC Multiplier 3467C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AaTTvabKoLZwMagxdAh6LG8AGUo9ofMZ6": { "n": "BTC Multiplier 3467B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Njuwoh3EWZVBoi1neQ2YHALPG5oEgkWCN": { "n": "BTC Multiplier 3467A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"149RrEpoTaQpVisFBSfA8WSsXa3EMsz7FE": { "n": "BTC Multiplier 3459C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GPjJdv4uUFSvDRtshss9zSK8Ku8phbiW3": { "n": "BTC Multiplier 3459B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19EL7ZtQdECsVD5TjerxgVGFdfHTCzTw81": { "n": "BTC Multiplier 3459A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CzeGuhFo2cbq7mz2PTeDTA7V7ZRvQTumJ": { "n": "BTC Multiplier 3458C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DZsTFDBMeiR2qUPiyBoKRatnSvmVsBCnw": { "n": "BTC Multiplier 3458B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1K8Vx9k1UzSFVedbM6Xu2xa39Bg2xzAt9W": { "n": "BTC Multiplier 3458A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16DYy1TZc8jWprzsipve5jCLZkaVTiJb31": { "n": "BTC Multiplier 3457C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JkfgpVUSo9kkp9153jPGMdRgxNxh544cr": { "n": "BTC Multiplier 3457B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HK4ijkGZ36HmzNBiwufk4B3agwnmgesV7": { "n": "BTC Multiplier 3457A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"135kBWoGnrgTj75f1K6wp1m4fb57tB87qg": { "n": "BTC Multiplier 3456C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HAb3KspLMXaxvHJZ4RLkGo59uinYRHZd3": { "n": "BTC Multiplier 3456B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14t3sgQ28iCSSErhbAAuQ7RMtazLmLiScH": { "n": "BTC Multiplier 3456A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17wPUNtKxmTAKC2uv5yYhiZJmNhiCXumVj": { "n": "BTC Multiplier 2789C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1C7vAapc93EW8iPtq34oS6Dt9Nn4wnrKJn": { "n": "BTC Multiplier 2789B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14bPxDdu7B59DQZKFsQqyyWVMMBibGRvGv": { "n": "BTC Multiplier 2789A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AEEmfxynm7ixYyor8AxYRRQuuCJCQ3WHA": { "n": "BTC Multiplier 2689C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15dVmtUSPykyD9t7a245S3MY8tduL5uCGK": { "n": "BTC Multiplier 2689B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Hq26WcinR4XYWviYM8zRE2qYnt7vv3B6L": { "n": "BTC Multiplier 2689A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19vZWEVJL2Pv1HwTYn1z5CcFFZBRK5hX1P": { "n": "BTC Multiplier 2679C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CGGzEQwEPpgka1f2fJhEGn2PzNgXrnCc8": { "n": "BTC Multiplier 2679B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PC2gQBdZ6ayH7fHKo9wMNPitz4BRu1JAY": { "n": "BTC Multiplier 2679A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AD38yGLzetSekVzxn9XyYB64B7xEb1pSP": { "n": "BTC Multiplier 2678C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17q4AVfxaFwBaZf82p7spg8N6wkgx8PahC": { "n": "BTC Multiplier 2678B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13V39EuErrbGntkjYf3qnqkGptGUbvkDxi": { "n": "BTC Multiplier 2678A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15eZGaSHtETJSRToMPCg2qeNoEec14iEvq": { "n": "BTC Multiplier 2589C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NmjR9vjXEPe6sNH62DJtMD3rDngNDx5Jo": { "n": "BTC Multiplier 2589B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"142c7oLXUWzeX5rXPVJzxtiFJ6oUGA99Np": { "n": "BTC Multiplier 2589A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15CiwK5JcoaanWD2D6EdEFvxyZ8E2B8B97": { "n": "BTC Multiplier 2579C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18wJvbrycm52WRHGj41MMB1qEdraLBLYvN": { "n": "BTC Multiplier 2579B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KnuGAPpw7oDKvyMshtc2pK6wT2ZnFAj2S": { "n": "BTC Multiplier 2579A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13EurzgkR9fKZaapi1CtrWWFTTNNNjzV5P": { "n": "BTC Multiplier 2578C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ALugpv4J7vwYmbCXn5FJMh849aXXpJBum": { "n": "BTC Multiplier 2578B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19xULnYZP5nRtRy6v8ojELyWHjX17B1pgi": { "n": "BTC Multiplier 2578A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14DAXjzfkH9fBPaL2ZJVjD5tuR6aPZuEdi": { "n": "BTC Multiplier 2569C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HNxQS5KRCsr97siQXMWNdueCV33ojySQE": { "n": "BTC Multiplier 2569B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15cJmt4o8WD13GZjB4ZK3K7HhCW7LAVcNV": { "n": "BTC Multiplier 2569A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BG8hb3KgtAZ3tpsw3HN1vogvCFJZK76nS": { "n": "BTC Multiplier 2568C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GDPC9VXjxf6uBBwpKN6bhgMF26q2ccwin": { "n": "BTC Multiplier 2568B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Q3Pk1gzZeJykbS3u2AadESidimu1fGKr3": { "n": "BTC Multiplier 2568A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EGt7QiBvGebgDC7TVALbvcqzdmBLifjn": { "n": "BTC Multiplier 2567C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17xdLkt2PrjiamuFi545MxB5hxmbNrTm9": { "n": "BTC Multiplier 2567B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EJAykxQg5uer48jnyDQaFCzJvdrndprSZ": { "n": "BTC Multiplier 2567A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FCprnv9MVtJoEtR1q6kfpiBoDxy1Hcdyu": { "n": "BTC Multiplier 2489C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19h7mw4LprL2gEMaMiK4mXCE65uYWBPbYP": { "n": "BTC Multiplier 2489B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14BW8NRthWaNGHuaBqSNVGmkQgYcqN5D2h": { "n": "BTC Multiplier 2489A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"185g6e1C6mcoav2egFJ7srsHYsgtHFSGNw": { "n": "BTC Multiplier 2479C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1718KuATeVgqLvC5Cekb6RAixgABku3pAE": { "n": "BTC Multiplier 2479B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MTSYK2SywN6NQSuPusm9yhkY66puziJAi": { "n": "BTC Multiplier 2479A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13ozXrM45RLnTCbxwneyPRvGyxa3ABRWfQ": { "n": "BTC Multiplier 2478C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HZQN3NbuUAftjsXf8XvboB95m85KZoPHo": { "n": "BTC Multiplier 2478B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1L557gUF88S3dHRG3WDwexehAvzEPnWs9N": { "n": "BTC Multiplier 2478A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MKkwmMKdPhzwpNCYMafbdMq1y7VPtTN1t": { "n": "BTC Multiplier 2469C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13W23fHT6G2HHNbUi1BPAXsfq9KAKA3uLq": { "n": "BTC Multiplier 2469B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1H5ch93JGau21jXsbAKWvmNSraXQXQWMRt": { "n": "BTC Multiplier 2469A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KNKUhoNZgGCwzECgzsAPvi4WKJZgxua3b": { "n": "BTC Multiplier 2468C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AfDrGSg9YmXzjDLxAvqViR6C4SpRBLNYH": { "n": "BTC Multiplier 2468B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GBJQmqWaDKGt3vfZRTcLEVyW5eJZAUmac": { "n": "BTC Multiplier 2468A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EBrhjERWGSb8cPKZx3CkhPinMYHgfnhcS": { "n": "BTC Multiplier 2467C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ga8XYPKLcfomihrTiko3EK2qD3KyYzV5a": { "n": "BTC Multiplier 2467B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MZn9Phx75GxyTVzTq5pA8GcvHB2EyxGEL": { "n": "BTC Multiplier 2467A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17udENU1kPQUHoes4Z5UtxXYXoqEs7eDr2": { "n": "BTC Multiplier 2459C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EHnRBKAD59C7iVrS3rDMV6WJC6steuGkE": { "n": "BTC Multiplier 2459B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KVsqL9bHNt9TmqDXGmdvUG9GkyaZpvb7s": { "n": "BTC Multiplier 2459A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15Emjus2BEmqgQ2ravBdL4h4LQZ5Xiwesn": { "n": "BTC Multiplier 2458C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14dJNgkeRsjrT1pbsyXxXJTFoqMy3vVtgP": { "n": "BTC Multiplier 2458B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14rpFUTHqyTXBnz3QsVHHxN6nYZDFQDcSb": { "n": "BTC Multiplier 2458A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Q1De3Kwp4UNH5GMAXarYzhkbbTLjUTXfE": { "n": "BTC Multiplier 2457C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1P2GWs8ko6PDFUKLD8CKDyK64rgeYi9UNH": { "n": "BTC Multiplier 2457B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CEU93fDFQxfBFviTCFutMQjmcWyVRRbr8": { "n": "BTC Multiplier 2457A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1J5XHw8cfDDj1313HkzLdnNNkkq19MSuXs": { "n": "BTC Multiplier 2456C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FjmCWf49xYbdrPiB62PHcF9Mrj3ZjtYyT": { "n": "BTC Multiplier 2456B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1C2sFsSMxNV4JCmcZDq24DXwNmsb7Le75Z": { "n": "BTC Multiplier 2456A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EHTgDyEMLyCSRAPY76AynPnhgdYbqWQq3": { "n": "BTC Multiplier 2389C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1F9p6Q6m8qxAmkpEhEpj4i7qe18jxCC25a": { "n": "BTC Multiplier 2389B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Q2sccpAR5FaMnQ73HM7y59CBMYBA89HMK": { "n": "BTC Multiplier 2389A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16EUwhiPSoRor2ezhFDPmsmRBzK7UkGo6d": { "n": "BTC Multiplier 2379C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16XEuFaQncBfUAsEaWKybwHF97SthRqgD1": { "n": "BTC Multiplier 2379B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1tbYX3rUiXQKapjC4Ys7ejPWEEuHupVyw": { "n": "BTC Multiplier 2379A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KdWib3p4eh1XTfaRhwWs9PvQvWe5ho5o8": { "n": "BTC Multiplier 2378C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15dahUJsbqmmo32Bb8YFEeo6N9mufPtq7R": { "n": "BTC Multiplier 2378B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19RZDJPt61vEirW8nj2YQQN5LyJ6F4SAx3": { "n": "BTC Multiplier 2378A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15Eqs5ioEYa9Cn17CEgTkwBzhNkzXgWPHV": { "n": "BTC Multiplier 2369C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AdRBdkH861v9ZfXiy7VZUbKE1aLWFC9XP": { "n": "BTC Multiplier 2369B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"164U925qW86Epuhr9sY6ezRRv38unmwyJx": { "n": "BTC Multiplier 2369A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1N8g3XcjAbvmyXK2usTw7YdX9DKPivHpBc": { "n": "BTC Multiplier 2368C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1McA525Q1kiEHp5sBg1Y3TBxsWA1TKJbLA": { "n": "BTC Multiplier 2368B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1J1qzzrrbihgtBrHYBnhQY9FTu4Bm9TcWk": { "n": "BTC Multiplier 2368A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14dfdQc48Q5SSeKqkzy4ifX8T6Uk8a6htW": { "n": "BTC Multiplier 2367C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13yLoEsNwCADfZKfbaFRWtzSiqMyUwqnhV": { "n": "BTC Multiplier 2367B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ds6m6a9oeTtZ4amqtvaULy5zGYwmDYQAh": { "n": "BTC Multiplier 2367A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1A6wPrVKcGjJGa3xS4D9trmmiuFjn7DJ4K": { "n": "BTC Multiplier 2359C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18JkRwg2oWKSXVpTpg3KKbLQ9ASvajyAMc": { "n": "BTC Multiplier 2359B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JpfCu5wCpwQo5hmGSpbcJXd6eqMzaRAYH": { "n": "BTC Multiplier 2359A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17PPQxHNb4YxqwuMse5NAFSgYVgtsiAVxw": { "n": "BTC Multiplier 2358C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MwQ6VEfqhs27gxQ521trviKSjwrb6yo9e": { "n": "BTC Multiplier 2358B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1P1HtyGf5T2spYpRsucfYKdXdgnxgK4k9f": { "n": "BTC Multiplier 2358A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1K7A3TV4d6xCh8mN9rzcqujz39BRvtK3m9": { "n": "BTC Multiplier 2357C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GvGdWBSpxSGygDNgv9NrrerpMFfTQDafG": { "n": "BTC Multiplier 2357B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JKVeoaEJi16Um9v5RPae9JCHxS7vZwMVM": { "n": "BTC Multiplier 2357A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14RWdMQGbMyK89SmWEgT4NaeZvZGpSp4eC": { "n": "BTC Multiplier 2356C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"186PPwGzD8uD2cYEMH4oWdoGfjwzmMjo5F": { "n": "BTC Multiplier 2356B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13HaTBgrhyRx1yKfuvNM3DY2MPDnG6F5MJ": { "n": "BTC Multiplier 2356A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BdXzHxBrTzpo9gCcDDiDNGimtwriJBQuT": { "n": "BTC Multiplier 2349C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"128dDCE3eBc1p2j7xcpkS8yxcrukUmdGgD": { "n": "BTC Multiplier 2349B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PPjvVJktn5JZrZaPxwDFNUdmbqSQhdgh1": { "n": "BTC Multiplier 2349A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1QJpesmjYYjNBXUQwEDimqxwtDF4P7UGEx": { "n": "BTC Multiplier 2348C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HKD7h7kLQTfHantmgqhuPgEoBQbSyom8b": { "n": "BTC Multiplier 2348B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KNGYpi1yNAW8ZuLU8aS9DgFFxxwZe5CMv": { "n": "BTC Multiplier 2348A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Bun4MhwLpwophFfRKF5xJvj5naqXGPNUy": { "n": "BTC Multiplier 2347C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KrBncMKPJNHGFXqnJT6dbMryj3iBVoaNu": { "n": "BTC Multiplier 2347B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1G3LwjC6eqoinLwK63fYhF125bKymXAgbs": { "n": "BTC Multiplier 2347A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18C4myd6zZ8gqZoXM9pbzSiV9LinED6PeS": { "n": "BTC Multiplier 2346C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PV4xHjY4sKBkqgwxJTkdhLA52RsJajtvs": { "n": "BTC Multiplier 2346B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CWebHZfbyj54ZEYVK6pDsMuJzfP3qfer7": { "n": "BTC Multiplier 2346A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Q3t9WW23TR5HQDvivYcQoL8M7NYLtKKFZ": { "n": "BTC Multiplier 2345C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DtCmDeYTfsJZBkh1p8G5CMgwKCwL38UXt": { "n": "BTC Multiplier 2345B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ApxkB2uCKktA76dr6NffLBqpSmet2SADi": { "n": "BTC Multiplier 2345A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BCka9BENsHLPxhQzGBfQsWQ2rz2zoyav7": { "n": "BTC Multiplier 1789C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16gqvfpmSkSvvo4aKxeZs8CKatMbaQhUHN": { "n": "BTC Multiplier 1789B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GvSWZaqUdhnqmQbipK1L4mRcAhN8Wttm3": { "n": "BTC Multiplier 1789A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18FBK1yN3PVEpNd5RtEWY5UHX9CM11QH1r": { "n": "BTC Multiplier 1689C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1C8DFxsX5ybsQNAkki88XSxPCx6iqwx8S2": { "n": "BTC Multiplier 1689B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HzVjAMd9jXdFE41bYhpWhcqidg9YMtVRo": { "n": "BTC Multiplier 1689A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ehf2Zinf9ozSaRPkQymA2ifVnKthGUzjL": { "n": "BTC Multiplier 1679C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Jo8joMA16ueLCwJAqBA8jnfeEK2paW2Jr": { "n": "BTC Multiplier 1679B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12ieVm1EXHkw4apoY9YgnrbrSvZYfv443x": { "n": "BTC Multiplier 1679A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DBM87woQjWNAqqNG2JKQoyrUyFXaMhEQX": { "n": "BTC Multiplier 1678C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DpTtyisCiYfiL24QtwKCQRNHHFbrGCEMc": { "n": "BTC Multiplier 1678B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"179djiiE8LTuCnrXFFga8F5zfmgTd6cr5F": { "n": "BTC Multiplier 1678A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Sv6afhw4STNvSu8mCYL8wM1FyUnVWGaH": { "n": "BTC Multiplier 1589C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17Fuq8APZCQqvjntWCQEsR1eVR1MLpZy6t": { "n": "BTC Multiplier 1589B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1z7J62UmjoiamLpLSMmUc7mZ934QLtYtN": { "n": "BTC Multiplier 1589A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15XyDXGvBz5ZeTtoduLia6rgavtVKkGLwS": { "n": "BTC Multiplier 1579C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"199B5PG4LUr6Rg7bgmjR7XQ5T3DJfmUtrv": { "n": "BTC Multiplier 1579B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MLvD5teywsr9kjv92R4mxhQhU5xkwdMNh": { "n": "BTC Multiplier 1579A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ac9tAj4vdM3RgW5sS8B7mAA8oe43prrWh": { "n": "BTC Multiplier 1578C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1P2dyDStHYALzGZuTib6DTdmziwpP2maNn": { "n": "BTC Multiplier 1578B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JCxDHFd2YQBSwQye5VRrNEbGfWQg75Dyg": { "n": "BTC Multiplier 1578A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"191VBKzLj4X8qB1GfvBNjs6sYvLWydgcz8": { "n": "BTC Multiplier 1569C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16T9MNN4CQVCNn84Vbu4uMdzmp2fzWMUpg": { "n": "BTC Multiplier 1569B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19Sk6t1sM3jsgQWgPpAsV5cdWCUAuFnJJW": { "n": "BTC Multiplier 1569A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DL9KuptVeQytWBigTmgRmRQzo6Y8kcfLB": { "n": "BTC Multiplier 1568C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"181vmGuEpxmoEhsnxqfQF8CmktHw3AfdQh": { "n": "BTC Multiplier 1568B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1E32FvjvkC7xUhN4doJX58fxcuueiavE6q": { "n": "BTC Multiplier 1568A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15JoxqPn89nC4RY91GAhxpZGWasbRszP9r": { "n": "BTC Multiplier 1567C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13XHD9GoKm87udd52ro14KwPsHWshLkoRA": { "n": "BTC Multiplier 1567B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"199neYfhXpZLr96NHwfYPoq9rZb49rabMM": { "n": "BTC Multiplier 1567A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19x4xzmxvnKLZs1kSmqMEzhG48jhbVDQxP": { "n": "BTC Multiplier 1489C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1J3m5ZLtQGyWPzpc7kL2eWy3S5Lo9FghZd": { "n": "BTC Multiplier 1489B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13WtzDr4n7iWJBQuhvu6zFScDg4bta2CUF": { "n": "BTC Multiplier 1489A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18oKnBhqm3647YzFHVrdS6U8QW2QgPmQr6": { "n": "BTC Multiplier 1479C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EzxMmqre5iEbeiTSsGV35DW3QTF6k8ZYF": { "n": "BTC Multiplier 1479B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CLaVgkSkhs3od8BEUsVLc7LpNC43BaMjq": { "n": "BTC Multiplier 1479A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15sKikh1kfUqt28jyXUKdNB71yfvQG4Xch": { "n": "BTC Multiplier 1478C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Jhy6qNpXhMGheYwomVipRwkAWHcDRgnZV": { "n": "BTC Multiplier 1478B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18urmm7dQhNsZmGM9FkXyLyYV87QYvfEEC": { "n": "BTC Multiplier 1478A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KUPr4ppHBe1oBzr9cZfeKG2EF57Mpqc8d": { "n": "BTC Multiplier 1469C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KjZ6isgXFwcXrH8otqqkY5XSYhFTcMFjr": { "n": "BTC Multiplier 1469B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17iLS2iqndxzSVMrG2i15y1djzpWrLef6u": { "n": "BTC Multiplier 1469A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ASFpGqBxESAa76EcRftKLsLUjBgBNQVJh": { "n": "BTC Multiplier 1468C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13utfU1voDt1ofpFeVuDVgMNxrcMxYMEXH": { "n": "BTC Multiplier 1468B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BtqDVSsRYTsDrQCRJkkvABXY6aTMxmHjq": { "n": "BTC Multiplier 1468A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13hBLbAupYFCwi1cGgnHnSu7kd2nCkUCWE": { "n": "BTC Multiplier 1467C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MtENJtH7vptLK94CJKQ6byZ4B9BHYd9Y8": { "n": "BTC Multiplier 1467B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EQ3vAYENCdCVU7jQim5b5gGiFE7zGfjNn": { "n": "BTC Multiplier 1467A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1A8WSuRGxj8Sm9qxRfagjWiN5iVNkBHcrj": { "n": "BTC Multiplier 1459C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1382nTiKkHKcqhwB5AVynHtRpABh5kBwsN": { "n": "BTC Multiplier 1459B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NmThb5hhRAxyVjeju9fkoM2puCqzjezR6": { "n": "BTC Multiplier 1459A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Q6BQRvrogmtPqohrxXrA2TdnY38Uw56UF": { "n": "BTC Multiplier 1458C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CaG89CFcTzhwAhpQymJFtr2ctvzUwfRbu": { "n": "BTC Multiplier 1458B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MiEa9FYdpFEVNdgKaxrpVz7AgFtQKXUnt": { "n": "BTC Multiplier 1458A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ah8Hoyar3Qdi5mUgSJuXFTfHminHzi5mb": { "n": "BTC Multiplier 1457C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17GHL5jwsWS2xFvsa71uqdZddHqA3xRUuN": { "n": "BTC Multiplier 1457B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"196AFVwybYxZxn9qENKdCNxo4ucgAFkeha": { "n": "BTC Multiplier 1457A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AcT2tZiJV4oumRSxoAEfU1Jtmq9Cazpf2": { "n": "BTC Multiplier 1456C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Q9jCmVuypocMUpSLLbUZhnxtd1Ggiv2Na": { "n": "BTC Multiplier 1456B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16dm7nqJwX2ovdfGr6M8U5TG2KXxsZjvwo": { "n": "BTC Multiplier 1456A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18YSBhQ3p5L8qp7ZkKdc8xVwj7aYX3zsuM": { "n": "BTC Multiplier 1389C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16TNosDa7Z9LZLBcDYF85xsu3fdz3FuEf1": { "n": "BTC Multiplier 1389B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AFHqEDM43vJg4s55YcsovuddoSUyVMqkA": { "n": "BTC Multiplier 1389A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1QLHu71RH7ttttY7rk3eBzu1PXcAraiE2R": { "n": "BTC Multiplier 1379C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12E5vdRCJB1jVd2jmeAm9tQpcYAb7HFCnm": { "n": "BTC Multiplier 1379B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1K7T27QvbzLSasJogVv8FRHbt3krEi3cby": { "n": "BTC Multiplier 1379A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15PwZsvvyCKiXDh5aFEvm3KJ9kCV43DaDc": { "n": "BTC Multiplier 1378C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EshXgXz2cLtS8c2kfkwdg2g7exzrHZd8X": { "n": "BTC Multiplier 1378B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14Pr6WWCmMtgHcdR22VKVAWLLyacRuVCQh": { "n": "BTC Multiplier 1378A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NbW8rSiuybTzjxYxj3MTFKuCSEGSZ2mf9": { "n": "BTC Multiplier 1369C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1h83Niae9EaKoE1A6LJzAmT1cprE6khEc": { "n": "BTC Multiplier 1369B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ho3wPbd5PA6N7cHjy367Zo5mKt6RzvqGb": { "n": "BTC Multiplier 1369A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JzGv5SHmRb1XsPvH7JqtSfHoVhUYp8Dox": { "n": "BTC Multiplier 1368C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Fc8gVrnJGspqJmjcftpKy2xU8jKakd2A1": { "n": "BTC Multiplier 1368B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PD6VmAXcdLgW9H6uDN4ATJEVEi9sKaDtb": { "n": "BTC Multiplier 1368A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1C8M5TmADCy8jBcSXQLrPjsf6tEWKrLTFf": { "n": "BTC Multiplier 1367C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17a18s1LSFP2diVq93RTKmWBzx1JM3pEf5": { "n": "BTC Multiplier 1367B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JRoNJqiguWg7js8CfqaPM6qCh5ADfJwwX": { "n": "BTC Multiplier 1367A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BfMnBf46q7Ny9xuQQAUNCtuux5GVWnh3u": { "n": "BTC Multiplier 1359C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1B3PzsuuT3irGDDvXediusnTtgdDZ7w4Fu": { "n": "BTC Multiplier 1359B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JMYGS5iFcPfLHeguTNwCxUQbxRxdTis6n": { "n": "BTC Multiplier 1359A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BCxPSTMqcmfCGhqJEKtUAzECaz148yoUE": { "n": "BTC Multiplier 1358C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AJ3QwPk6wt54qxZzXHy6KQc758ekDQxnB": { "n": "BTC Multiplier 1358B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1bx9ZgziGiKFPE9hhJXQjGB462JbcPtUG": { "n": "BTC Multiplier 1358A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JqMzM8VC3kXQLNLhJJyFwNwYjcNaD8sLS": { "n": "BTC Multiplier 1357C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DnvbyvfX9ALkpL5ciu2PEiQHJcHZ2Z46C": { "n": "BTC Multiplier 1357B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16cycfhomsQYpqWgBU8PXvvg6Teg6d8eFJ": { "n": "BTC Multiplier 1357A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18qpbb8npJLSnVzGmWcc7RhYckuB1vXxAj": { "n": "BTC Multiplier 1356C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1e6ch3NQ6TYNf5RwURk7oc6gyh3YitA3M": { "n": "BTC Multiplier 1356B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Mqg8j3Ly7jhqCQKmGJTXyHw45SR82KE77": { "n": "BTC Multiplier 1356A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1G4EUziUdGP72sk6LAeTEeaBxWCsFRTs6h": { "n": "BTC Multiplier 1349C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1haFwuFRZzbNMdNkHYWRTzWUDDfucBHgc": { "n": "BTC Multiplier 1349B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13tVCBeAa8U5NbWaBg1dra4WR2UmbcpNHu": { "n": "BTC Multiplier 1349A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1K4eX2f3oV5fWvNRGT7REhWq52LP5mkt3r": { "n": "BTC Multiplier 1348C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MmTuW9PsiBsefDFdDjGodAd98pJpH2bhp": { "n": "BTC Multiplier 1348B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16ZwQfgJBPnjxkipPXTMk2Vw3VSCqHpoPx": { "n": "BTC Multiplier 1348A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14Q5buXp7biyAJRXqyg2ExsAEnPG3G6viD": { "n": "BTC Multiplier 1347C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Gq8bEhrfEdFhtPJeRnXtJ5bdxYYSBVgE3": { "n": "BTC Multiplier 1347B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"149SauiHYKswcuiDk4EGgqNhZBVN7i955P": { "n": "BTC Multiplier 1347A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GUFLMZjTbAsf55hSm61RJDSNHA2nBzxra": { "n": "BTC Multiplier 1346C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Nr2oQ9iS461HgGjhz6iv7XA4Z232tV97w": { "n": "BTC Multiplier 1346B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FMkFjGaAm216yYqRPczFj2biZirSzgj7P": { "n": "BTC Multiplier 1346A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Lz54iu9pa2tgyrWoBbMTz58HMZy7aCzQn": { "n": "BTC Multiplier 1345C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14dw1qXTN5WCcTj5uStcu2Dk7Wwg4TdNTA": { "n": "BTC Multiplier 1345B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AkksC9NhQj32BFnYRNET5YbRFVMntK6Sn": { "n": "BTC Multiplier 1345A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15TyfMmS1d9qsXjZnE9NHWmokZek9sTnxB": { "n": "BTC Multiplier 1289C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18rSDZApQFhPy2kjETQ8X3ZQQWa2ZtyowK": { "n": "BTC Multiplier 1289B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Hk9Hra8H1XHVdK3FkWFWmnZy7SmNiVxub": { "n": "BTC Multiplier 1289A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"129S1hJd2ipwfxywwe1wPGuVFzARJKDZzk": { "n": "BTC Multiplier 1279C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NdM3A9xQJ513QAQ1eeYXhu5iRctcsroHU": { "n": "BTC Multiplier 1279B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14YyCqCGN45m74t7yqhjCtfu2oc4TVxd8D": { "n": "BTC Multiplier 1279A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17ooSk3Tgn7dYypht21PcgjZe33PCKShim": { "n": "BTC Multiplier 1278C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13aVABHwaL56cSfBtRg25n6LWkYBWpdc34": { "n": "BTC Multiplier 1278B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16CU7LtN5PHkG76uzJ1kJfbhB8Ew5vVGuy": { "n": "BTC Multiplier 1278A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19nPCiQpwRKTyft6bzLy1be5gd4u9zxKcD": { "n": "BTC Multiplier 1269C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12MbLtcytkGxv2svRm5MGg1A8RqKnQzbDH": { "n": "BTC Multiplier 1269B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KNPSEqvCyo9pexiYXrsj7bGu7DYjAWrFk": { "n": "BTC Multiplier 1269A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HjzsBCFcABRti2FT3hTRxFKLJ6TDodXVK": { "n": "BTC Multiplier 1268C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AX8Mi2ine3BApjQxsqwiy9UGU19Jr7GXm": { "n": "BTC Multiplier 1268B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MU2WvkdpzyGc91msnyBmbBGsLQmsEsSm8": { "n": "BTC Multiplier 1268A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1N281GKQdssLmjttyAotquhkuecUVQ1sVV": { "n": "BTC Multiplier 1267C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DcLHC5P38jnYGbqHYcawwb8H5HuTbGHP6": { "n": "BTC Multiplier 1267B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18j7McATM7F3KpM6DRsGFG4E5pwxbwDXHB": { "n": "BTC Multiplier 1267A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MFppCwJggxAGRLyArUAvJnz7RrBFYT9D4": { "n": "BTC Multiplier 1259C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18JpdsE78LqCnTBVdpW6D1J9fmVGvxYzsE": { "n": "BTC Multiplier 1259B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12DiTQU99aa3AqsMb6p3Srh92nWrbGaHKS": { "n": "BTC Multiplier 1259A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PMTgEg5GVmqfak7X2i9Yv9ZCYWE5TtH3d": { "n": "BTC Multiplier 1258C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KcAa3pjPu1xwRZQhkB2C76EGBrvU4Q4EC": { "n": "BTC Multiplier 1258B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Nx1ZAaYF8zd8LKYFH8o44RzxZBcB1MDmk": { "n": "BTC Multiplier 1258A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1727pBnNDPDVbDVnZ5mD1q5YwXFZiz4ia3": { "n": "BTC Multiplier 1257C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18Go1oiGNGhTHsipEgtTW2dTqToeaEv7Aj": { "n": "BTC Multiplier 1257B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1u4x59f5PenK68L7pAnsftRbkp9obfFwZ": { "n": "BTC Multiplier 1257A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ms9reLvPDyMcWPmKgqz1NnEyANBaxLenT": { "n": "BTC Multiplier 1256C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EnDkCNPFAGNSp9ftD1KqpibXrVKqNwFKY": { "n": "BTC Multiplier 1256B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KosHUiRLkXnGye3GY1Ye5Q1zLgoyLikTj": { "n": "BTC Multiplier 1256A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EYvTK7cTzJqYSTcjPiCaScR2RJHpyuvAV": { "n": "BTC Multiplier 1249C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16JBn9FS2E7NYAi5UE8yWRh5BcgseBhDZo": { "n": "BTC Multiplier 1249B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PyDej9EeLEyK3wwGyiYXNZPeSd2LFfRyg": { "n": "BTC Multiplier 1249A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15Gpry419j76v6WJouDdTdHF6YgQrJr7mh": { "n": "BTC Multiplier 1248C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AbRcBLdqS95QpbXF2LmrDu6izda9SZf8H": { "n": "BTC Multiplier 1248B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15hLqrC84rvMJftU5LnZa7S5NCxG6XFjxp": { "n": "BTC Multiplier 1248A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13B4c91XzhyoB31tH26BZC8JNjJU1Kn7Jv": { "n": "BTC Multiplier 1247C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1J3pcBjseT6gh91GcEKnE6RkfmoX6eRPkU": { "n": "BTC Multiplier 1247B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19s4yqDG8VoHDYgzH6PX3nKCqSkVZQRSXJ": { "n": "BTC Multiplier 1247A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15c1iZodQt7sc7YCfxSVJfzNDgXEVr2Ka4": { "n": "BTC Multiplier 1246C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AXz3pG7wsKyVUoLcULAfa47gXKU8bs7MB": { "n": "BTC Multiplier 1246B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PrqTyFYNmP2BNejKdCnE5m3TrV5rEJvuf": { "n": "BTC Multiplier 1246A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17ZC5p4ABEvXft1YTCA12XXH72J6DLLhca": { "n": "BTC Multiplier 1245C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DkNeXA35QiocZEfwdMFGcB8a1us8Fc38P": { "n": "BTC Multiplier 1245B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EBNo7yETaSaQidvHz6dCABAyqLTeYD2RE": { "n": "BTC Multiplier 1245A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ARTzTkjYDpZJgxvaT1PQdo19EsVyQYCZA": { "n": "BTC Multiplier 1239C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CGGVdTHUZTfTnpE6WuDFd8tcUzoBDho2n": { "n": "BTC Multiplier 1239B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1N3PkDP37Y7r9j9Rb54cSXxuF6e5759ecj": { "n": "BTC Multiplier 1239A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17UzwNNwqeK9uX8Byu2KjU7tzMVNuVCmz3": { "n": "BTC Multiplier 1238C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Cs5qq4eo8ks6de71pTwcbo4oJEqFgv4b": { "n": "BTC Multiplier 1238B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15mxibF3uo4ozfEo7rjri5jxmcAMhHfdqU": { "n": "BTC Multiplier 1238A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NURryk3wi5wd59469RE5bMC7oZ4mgmjwM": { "n": "BTC Multiplier 1237C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NNUdXoqbr9Kk7iSmabe8puekRFbXKzCQw": { "n": "BTC Multiplier 1237B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BJUVFXyozoray75ASPbyPxUKXiiUohST5": { "n": "BTC Multiplier 1237A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BPT8SqL29f9VfPTRPiyocYMoctj43ED1T": { "n": "BTC Multiplier 1236C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Kcsuu17ReaC5cZda4Uac39E1w8VtmBeFW": { "n": "BTC Multiplier 1236B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1G2xGqPMjA9BBwf6qL5rU6WSjqpbyhstG5": { "n": "BTC Multiplier 1236A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16kfSgvVsm8fqDDmysZRXjabzwaDvTaBai": { "n": "BTC Multiplier 1235C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NBSaiXqn7HPGh97LJMGA6fGSRQ7rYsyyv": { "n": "BTC Multiplier 1235B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Gkmu1ce7Tb7Xpr61CBtv7gdJo42RgbXdE": { "n": "BTC Multiplier 1235A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DbSmna764SgL2EgKNFCEU49qmFzPudaGP": { "n": "BTC Multiplier 1234C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12CwWiWGg1kzkTPguQZXe5AiVAB99zMeuv": { "n": "BTC Multiplier 1234B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18CZ3jBm6RyamP5mkYVyWfB56Xtpe52TW2": { "n": "BTC Multiplier 1234A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13YZfjrGPAKrwYqMpRX5uvPg3hiVw6DzuQ": { "n": "BTC Multiplier 789C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18E7u38kVYF22HxJQfx9i8ktstq4Mjnz9B": { "n": "BTC Multiplier 789B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PAHdEbGcfJcBzSk8m18iaK8gQcHsw79Uw": { "n": "BTC Multiplier 789A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CSRrfeGfqPoJNPuMfcyyTruqTFm6Muv69": { "n": "BTC Multiplier 689C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17oVJR9TenJYDmhXvukZaWeeXAv3phz7ww": { "n": "BTC Multiplier 689B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Fb5D94X5KqnoLFcfBmkERs1JqdrJCywjV": { "n": "BTC Multiplier 689A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1J29sgakm8gZMP2WFtpz3kqxDrgWqfeMyo": { "n": "BTC Multiplier 679C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1r9uhteDJYnqYV6V8wCJQDynDHiCes741": { "n": "BTC Multiplier 679B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KkM1wzqNrJQ46dToEC4UQT1hPV3JLF6mp": { "n": "BTC Multiplier 679A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Lb58v5xZVNnHvo2qDQWru4Vd6YubyfdCm": { "n": "BTC Multiplier 678C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LsGWJJCJikZS1cXfuZjboVocFtxPgP31B": { "n": "BTC Multiplier 678B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CFu13aLjF55FegEoYrKVfcxgcYV2zFBdC": { "n": "BTC Multiplier 678A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AQkGAPYmXD1SqNeq7GVHtBN98nByRxyY": { "n": "BTC Multiplier 589C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ugBpsrzFQA8PNUGD3Sb7Gxk18cq9ujSn": { "n": "BTC Multiplier 589B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1QGpiLP2GD2vTNy4sNspWp8o3Jc5E4fkWA": { "n": "BTC Multiplier 589A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GqDf8KhszmDfB3LcEq51AVKFT8rmRzAAr": { "n": "BTC Multiplier 579C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16SLXKTx7Kaa1e64QWzcUNkjSAjdjMoojD": { "n": "BTC Multiplier 579B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KZUMVHwygJ7ne6MomN47JKjrsq6kEreGx": { "n": "BTC Multiplier 579A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GECFAQqvjdUzU14FfqiDT4TtuNf8bBGnt": { "n": "BTC Multiplier 578C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PbbkdRSphesACENQGgZeDtpGpdXbzCH4T": { "n": "BTC Multiplier 578B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HDanKSJ4oEsDoyvamHYyJ9arK7g2QTKFZ": { "n": "BTC Multiplier 578A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BX3P4hfg4zjqbMhd17W8GhK1vZGsM2U14": { "n": "BTC Multiplier 569C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13UqPrXMx2cYTEHq4nWbBboUqjTiZUfqZT": { "n": "BTC Multiplier 569B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"145royTvWJXQeX5XQoFzhpNvv2hHcLXmVm": { "n": "BTC Multiplier 569A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13j8QJAwSQbwxPNEKc4hqkPzQ4Ri5wvmrn": { "n": "BTC Multiplier 568C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13zu8EbpwiWUXRu23czDHZTyU2SKmsFoLr": { "n": "BTC Multiplier 568B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KxYMNj7g24zgvTM63qT2ngK5A69tMngHM": { "n": "BTC Multiplier 568A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1E84rnirAunxuL6FtqLjiDxcwWCoJacLtr": { "n": "BTC Multiplier 567C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ajjt9LPLgUMzqVVgG6yQ3vTxuu56EHXdK": { "n": "BTC Multiplier 567B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GcbEcpk6ri88xcbrB9Bmo94xg31Qh29yz": { "n": "BTC Multiplier 567A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LcJcre7Z5khFbRtn6AdkgwRz3uxEvLAHQ": { "n": "BTC Multiplier 489C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"198yNZHWsSDbwMpXxoQZtzLDPocCzbYw9Y": { "n": "BTC Multiplier 489B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12RnhPHkEL3dZSy249bD5Q5mbYeK7fYGAK": { "n": "BTC Multiplier 489A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Q2ovFWzPnoUhjF9NDvAceYCb97bHWgbP5": { "n": "BTC Multiplier 479C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NrubLJSvhb6rvzyEn6vof4H23GGDopXq5": { "n": "BTC Multiplier 479B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JYBMHCasAJAm6caz27kLuY4VYTbjWi7MK": { "n": "BTC Multiplier 479A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18AWZHWf3u5YjzUdmM93KhokBzfz96TWzp": { "n": "BTC Multiplier 478C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1H7vz9vLvK7KTCVjWED8kpZymxnMLNfV32": { "n": "BTC Multiplier 478B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1J8xPAHBs4r29zeq2KYpL1MC2qk913giNH": { "n": "BTC Multiplier 478A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13H4yHNDpDA37zNyC9eoWwgg6ZqSESrXyY": { "n": "BTC Multiplier 469C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EhTiXhV4Snx8mGtzfMnSELh67vnz9abLf": { "n": "BTC Multiplier 469B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17JmLzCP4Abk1anUHScfMhUqeWqSzkNzyE": { "n": "BTC Multiplier 469A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1P6CkaFfnTy8QLYYSjYQ6cAbFFDQvPZSQ6": { "n": "BTC Multiplier 468C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EzGNDKyCYJQyryKgWEQajyJkKFoJo4hDg": { "n": "BTC Multiplier 468B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1YDcJbbGu8HjCJjDBQG4PkT2wkibPPFpe": { "n": "BTC Multiplier 468A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CzPwpXU8LaWeQyXS6DD8ZvKoWZcqo74HJ": { "n": "BTC Multiplier 467C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18o2pX4AVcNbXD5xLpeoPt5H7cAPpK57CR": { "n": "BTC Multiplier 467B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16KBSHkRGtVuvdY8E8qmjfpJbQr3DPZGXB": { "n": "BTC Multiplier 467A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AntgXBjrtvdbbwMYdQq9v3nRFoAyHCadF": { "n": "BTC Multiplier 459C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Q3VfKF3Cjzi17kgKAVRk4TZc9avhYCs9x": { "n": "BTC Multiplier 459B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NBfC1K2TRc42LUVaHNRi6msw76VnDz57B": { "n": "BTC Multiplier 459A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13bmrvCpJHER8i81UYX45SB39J4kEXYSee": { "n": "BTC Multiplier 458C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LhrWirngQbHCguJCnUFiLqDgwp69JRScY": { "n": "BTC Multiplier 458B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GVXwqTm9LbixF3xajKVh9gSEdSEjWDndf": { "n": "BTC Multiplier 458A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EVzj7emK5s8p9KYkGCjngvQAMZ8Jf5QhW": { "n": "BTC Multiplier 457C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GLtEk8p9Ngzs3xjuC5YiSb8ESf9HPqXmy": { "n": "BTC Multiplier 457B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1K3Vo8vR2YeM5bPbU4cBLeBBF1BvEvypqS": { "n": "BTC Multiplier 457A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LwXBjM5VNgUs6fnRgAfE5TdyxDUWRigyS": { "n": "BTC Multiplier 456C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BFtGD3bu51fh1xb1rL8uag48T3KNPNBXz": { "n": "BTC Multiplier 456B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FbtnZXpg2M4RnTCGioMnXJC2noZv6xj3N": { "n": "BTC Multiplier 456A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"125Tnxpit8Ma2xjQHjRyCqxY27q17Q28hi": { "n": "BTC Multiplier 389C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Fhcb9bWaqyJcSFrNApTT8XFR9qyNJvMVy": { "n": "BTC Multiplier 389B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1QG3Rfw9xghGT3wo3BSFgtrkMSWWw44AX9": { "n": "BTC Multiplier 389A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GybwvW1mNoNq4taZWpfV2tkukiiycQD8p": { "n": "BTC Multiplier 379C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17bBRwnRq1Eb4wTCPKsrzpc6uY2xzDtUpN": { "n": "BTC Multiplier 379B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Nikau12KFx6Qa6rnjcjkzX6Hdj6YjCfjy": { "n": "BTC Multiplier 379A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17s9LCyy7QJ2CHiVSAFEh6Tvq5KS62G7K9": { "n": "BTC Multiplier 378C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13Msedgu4Dp55AvtrMVavSs1mK2n7uZrRx": { "n": "BTC Multiplier 378B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Paiu8ibAfKcCoL8ZWCWbry7VDjqBUbW6H": { "n": "BTC Multiplier 378A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14Yn3RVjRrKpnS1ZAhAhQcvzQeVuNquLU6": { "n": "BTC Multiplier 369C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FB3u65aWY2kUbCSYckf5DQXFmuL331LdG": { "n": "BTC Multiplier 369B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1cdmEWboWxa8nXtzSQy33b5XtCLeUDRNA": { "n": "BTC Multiplier 369A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EL5CHfxMPZMXSnaa1KU1ZRh8sv3hv3vxk": { "n": "BTC Multiplier 368C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ErYucKtqgdeyS4kEy7Q8kCjyeKFiUvRcw": { "n": "BTC Multiplier 368B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19TgU4rGDdKb44jHexLGiWaoK766MgtiNt": { "n": "BTC Multiplier 368A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DT7R2Fpifw5VrckPYUBR8ooNFP1T4UpJj": { "n": "BTC Multiplier 367C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NA5Ns38hnc6v5FRWRPHgYtStYY1eM1y2B": { "n": "BTC Multiplier 367B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16CpzxrWQZr1uK2GSK8L9terRh871xmKQd": { "n": "BTC Multiplier 367A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"11KRwTQz7ePHajdW2ZWJp3HU7hNMru7mX": { "n": "BTC Multiplier 359C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FxtFXhnvSCCAZrS6nVgdF6oJwkWUuspmx": { "n": "BTC Multiplier 359B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NnvXz5DFJu9aPc5exCyKtjE9zYuUrGP8r": { "n": "BTC Multiplier 359A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12sPBaNtwRNgihxFLAqioDjrPv29VdiEzH": { "n": "BTC Multiplier 358C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NkDN6capdxnkQ16UPcJukD2TNT1cMG23U": { "n": "BTC Multiplier 358B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"195bymXt9rC6uXGh48aK5mYgyNzhdzUMR1": { "n": "BTC Multiplier 358A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12hfaRVFjFVDveqZbrdpizNKQhg6BYpen9": { "n": "BTC Multiplier 357C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19AHQRS87EvQinVQbytMnTyQJydPB4JYjN": { "n": "BTC Multiplier 357B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19bYdpUyMQiWkdkx2wsNV9rNpnYCDYcGWd": { "n": "BTC Multiplier 357A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DY3TfKyoVXYBuwVvPooGJQjYYUd9XkEdj": { "n": "BTC Multiplier 356C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12USqVdYqCHhJ7PP7A8uHc26W8kT41Sn2j": { "n": "BTC Multiplier 356B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17prvUaRRj1jxXoNvgkgVwmcQjTjHSw34r": { "n": "BTC Multiplier 356A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1E2vDVSRRPS3Dij7pavLLKv5yZwAxerUMz": { "n": "BTC Multiplier 349C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12hH4TEgP23RKtc9HR3eFMnK3e3X9Vcm12": { "n": "BTC Multiplier 349B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LYD9aZEWJz8wLaA4ZRtPS4ACVMTMPA1gd": { "n": "BTC Multiplier 349A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18s4YZXicGcAqBBPcxSby6VjqezEt2uLsR": { "n": "BTC Multiplier 348C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1J6ommx8fBXBMR3zShSPp7JUCsqo1dBHdb": { "n": "BTC Multiplier 348B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FaMd897nKEksbYT397iXGmV7CvY7F3qWU": { "n": "BTC Multiplier 348A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JpkDnjyU89seocdgTzPmY7XJoAxzY4Bw5": { "n": "BTC Multiplier 347C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PQewbp1X59okcMLfaN7z3Drid6dAVmm8d": { "n": "BTC Multiplier 347B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Gzc6VaxMiGPdUTfFggUBpqWKurkThe7H7": { "n": "BTC Multiplier 347A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1C1PEuxFMvdTAgFEFz1SqvpEJVBe7cMfRh": { "n": "BTC Multiplier 346C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Gq6SoCu88yb4Cep7X31CtewdqCKp9hZ2D": { "n": "BTC Multiplier 346B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AUgg6UCYSFw43pJWrDxnPAMF56uNRVe6i": { "n": "BTC Multiplier 346A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"129y4ZoRQV4VTsjbYVfG31G3T9LHUXEqMs": { "n": "BTC Multiplier 345C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HJvmbTndAyAnd7Djb38jzmgktShWMAib9": { "n": "BTC Multiplier 345B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14viRfnEsEs88aYD5qrJ2k59CQT7ACdAhG": { "n": "BTC Multiplier 345A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17wH79PEXWU4dTJCVoVX4xNpTnvdppA5ma": { "n": "BTC Multiplier 289C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Jot7pSL8DYScGwr7ciBKi3Y8cNb9Ru8Xz": { "n": "BTC Multiplier 289B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FPJ7fXXbdu1spzHvAWxj4JuyNa3cdm3Wa": { "n": "BTC Multiplier 289A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LV9mZN61b7kdEtFqJkKgsVPmFfVkmcKRT": { "n": "BTC Multiplier 279C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13LdTQqJSp1qb93Rp76ASVMUxZf5pU3QWw": { "n": "BTC Multiplier 279B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PtAWHouxgMViuMNWsXxjc7jXmZTK2Zykd": { "n": "BTC Multiplier 279A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LojjLy4vV5uC4C5PVaovz8qcs3tst4v2V": { "n": "BTC Multiplier 278C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AJbEP12nrEHdb7RCw2A4r8rpY561EREpi": { "n": "BTC Multiplier 278B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JUnEaxUYwN4zPk2gj9sq4sHDH8eoymiMz": { "n": "BTC Multiplier 278A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DmS9GtkN3inN4vvfr4C3AZkynhuuEZhqk": { "n": "BTC Multiplier 269C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Aax3mox7cbCXZp1kWR4yzhh2EKAjZbc6t": { "n": "BTC Multiplier 269B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AKStHAvQNrKByfZLFKDY49FhqkMRHwgNx": { "n": "BTC Multiplier 269A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18nBTgNpthcvZFaHNAKjQT181U8VMsnsjG": { "n": "BTC Multiplier 268C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15nW6i4KbhBBtC1HomFgpnrq3BcjUCVikA": { "n": "BTC Multiplier 268B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AWUBvDpzRZcRDLRSFyiSjTf1rdjNb7qYj": { "n": "BTC Multiplier 268A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"196GGbmjDk7TiUGyLv6bJzGjmJFAPjxa7a": { "n": "BTC Multiplier 267C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GPXfm82xdM1XuJo41PTg4DA2XtRGruMsD": { "n": "BTC Multiplier 267B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1B3scbqRhbrnf9gkjhRk3g4Uf3J8nrj8jY": { "n": "BTC Multiplier 267A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1N6ZDPXi9VV9yuGfhCMBswBWqN83Gb9vyi": { "n": "BTC Multiplier 259C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1A72nvZiqrBJnhLiq4APw1MZDDpVXAnCaG": { "n": "BTC Multiplier 259B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FJaK7eJcFDWtoHWJ5zrU8jp7x1ebEg73E": { "n": "BTC Multiplier 259A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12okVjyc1x8H7BTukXoqexVEDHLeDLpNyh": { "n": "BTC Multiplier 258C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PJUJwr6wbJFhQj7YFSbZfDwPtG3UkfTxP": { "n": "BTC Multiplier 258B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13oMpVFK5SK1yYU2jXFSrHf7vo3mzg6zme": { "n": "BTC Multiplier 258A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HrVG7wjXB9LWGamSvtLPLZkyLguYbW9XF": { "n": "BTC Multiplier 257C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1H5MPmJoAcmFTSLF1krxDQ9LyyZi7vcpft": { "n": "BTC Multiplier 257B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CmQwKbgHo4hMVtpSUiqQkbweZAYd6EDfJ": { "n": "BTC Multiplier 257A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BUganZf5eer8WsAE5XJ94pNHJ3MS7EpT": { "n": "BTC Multiplier 256C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16oDRHWKyJxVQcivf8ovjso2d1yCSCWAwF": { "n": "BTC Multiplier 256B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Etea3fWeEmjtyHX9RfVzv2fHE3twfCtgN": { "n": "BTC Multiplier 256A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EKCovBzGAu4TBXenPQxbsPZBgH14EQo3i": { "n": "BTC Multiplier 249C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Mr9DDm6PyBAgAC5DXCHzkDQCmFPmrTf6m": { "n": "BTC Multiplier 249B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AxErBF3HU5u7cVLte8c7KghhBedgEh1ok": { "n": "BTC Multiplier 249A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19kr8yQsVkeADmgkf8dTcxU8pkjMA4Yjjc": { "n": "BTC Multiplier 248C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DPJS8vLfwu4a3mvFLrmkBqpfMHDPgyhFa": { "n": "BTC Multiplier 248B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13Zhk2iJGAjACzsKE7S7n1rVnLYirKoNFe": { "n": "BTC Multiplier 248A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12YUcSnNQQkzVKpJBMnASF5gqzVrree5Sq": { "n": "BTC Multiplier 247C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PmZHXuYeRfvoER6TqPQFBko6ScDV3kEnh": { "n": "BTC Multiplier 247B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1C9xMK1fMiM1eLwjyYAVBw1iQ8rrXMgGif": { "n": "BTC Multiplier 247A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"178ETUAuUcuckhmvRntZzk8TprZEPQv15Y": { "n": "BTC Multiplier 246C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18bQwDXt1gtKCiwwj9NHn3FpgrmxadoaaB": { "n": "BTC Multiplier 246B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18uXqXYjs4EHThcfNnXXGWFttc7DPJxvMY": { "n": "BTC Multiplier 246A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KDx8QBGYdRVqd7eDou2qcDZor3GkRAyAN": { "n": "BTC Multiplier 245C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CA2R5WkT1rx6brX2r2429sZRn1Vh5BbHt": { "n": "BTC Multiplier 245B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PjSWSohVJ8k2jREou8x7XDZiZUBTQdbdS": { "n": "BTC Multiplier 245A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15CMyaTsCF66hXpLRcWFr2YNSVedEoYYyp": { "n": "BTC Multiplier 239C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Lq9mmibRsQmu3V6kmbPNQCmeD8k5RDoRh": { "n": "BTC Multiplier 239B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Hen25qnmvwg5AVhSDDHRf6YWpFEu2QMr4": { "n": "BTC Multiplier 239A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1QLXhi7q3QqLFCattuL1dfrafe3M78t5HL": { "n": "BTC Multiplier 238C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KgKHzdjwadKc9sHE8d9WY2eHZJQa3UVvD": { "n": "BTC Multiplier 238B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Nw9UQt8Bn9ZtyTtkmh2H8DLxsiKyfPxuR": { "n": "BTC Multiplier 238A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Gn7D6ELCWFxZPhbwT3f8RQXDeAS6bEo7r": { "n": "BTC Multiplier 237C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1K1cLMVW7mWgnEQ6rFBznTBSee3zy6noWt": { "n": "BTC Multiplier 237B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18GNnA6AoVW2D5jRN2d3GjFvMUXe16EJKz": { "n": "BTC Multiplier 237A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1F4kDYxbQCYhihMwx9vLBJ96G4xRCJK1if": { "n": "BTC Multiplier 236C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GFmybmY49oZGMX3FQJR2CwARADM6MpGSQ": { "n": "BTC Multiplier 236B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JztUZsbVytyKc2bHd83H8MM4NEV1z73dL": { "n": "BTC Multiplier 236A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14g9wuzPo7FGddVeMR8S8o5RKHwYybbNXq": { "n": "BTC Multiplier 235C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1QFoD6wkGJhMTYoC6EamPTMdtkoxv6D35d": { "n": "BTC Multiplier 235B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DjpqjaUBg8gKLJkWgnKnhUsx5YS6FFKh6": { "n": "BTC Multiplier 235A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KegZhm4Gs1Sn4pU7gshmmUxMSWVnqGb1h": { "n": "BTC Multiplier 234C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AyU88C4JEv1v1jbZxHgqVuUyn85t8Ykc1": { "n": "BTC Multiplier 234B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FfXBjZqum5TpjkggS8SbPA3YuqyqPwZp7": { "n": "BTC Multiplier 234A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HvNTQP813TEW5ARRM7kL39ZrT3bbuscZ2": { "n": "BTC Multiplier 189C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DJe38ZKU1ViZuqtz4deZoP58b8M6XuRDZ": { "n": "BTC Multiplier 189B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19wacFqvyf55cXf8d1xkPh8kPZDPvZ5N5i": { "n": "BTC Multiplier 189A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PXNcd2sgZhXM1jruGufyB4JzNnGPBVU8P": { "n": "BTC Multiplier 179C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PG7YtCXyca5jLDsU7kwfd18wLnU2qmE92": { "n": "BTC Multiplier 179B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13Rzoz17raGvxzgxyNRxin1UAHmyymq8yf": { "n": "BTC Multiplier 179A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EVUe7pbifHns91PJZ5hbru13om3h9WVBW": { "n": "BTC Multiplier 178C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1B8xzxA35pABWMJJcvw7yCunAoLp48igNp": { "n": "BTC Multiplier 178B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1428ccJzaTzWBCGxZnPmfTxDaQLornd6hM": { "n": "BTC Multiplier 178A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1B94P2x3uUSBJywEi2WjqGZt9ackVeVLBg": { "n": "BTC Multiplier 169C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BELrHjSZDyL1QnvF7CDf5mSbyBJgaDoQR": { "n": "BTC Multiplier 169B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19dWRg4CjJoZ5edGBkKfp9bVyZY6r2CTEh": { "n": "BTC Multiplier 169A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JjXK1gGct3SVaFkYSnR3d6o3W4rHHEuYj": { "n": "BTC Multiplier 168C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Jh1DzF5aAXUyTJTAP8GFcW8znXQU8gqPK": { "n": "BTC Multiplier 168B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14sWKQgPU3zQH7RwHXv1zMvpCuUYj3Pb7T": { "n": "BTC Multiplier 168A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"127ZTQ4EVnJXpUDNujiCSvsVpD56KCW4ci": { "n": "BTC Multiplier 167C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18dxEWAte2LvwDNXyhXvPVJxJhgWJ2SZUk": { "n": "BTC Multiplier 167B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Eh5oHJ6MrYusTqCoZYV8FwGHgoRTUNtYZ": { "n": "BTC Multiplier 167A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19xgANpX2odijDAejbX4ftBP92K7WTuEPw": { "n": "BTC Multiplier 159C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NQ2jAR5ntvjiTzPH1qoAB9UhPan2VUHSd": { "n": "BTC Multiplier 159B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1M1RBpTPSWNDk27ABP36muyA9Zqgv8zJNm": { "n": "BTC Multiplier 159A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15N41ME1XMNhqFSXG4e8Uyuds1PDJtbsGM": { "n": "BTC Multiplier 158C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AY5bvCDE5xGVpXkJzR7yJHkUywJ3pGx9a": { "n": "BTC Multiplier 158B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JYrwmnkeYGqhxNsxrA8KxReVLQLZDQvzE": { "n": "BTC Multiplier 158A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JoqVmFCJ6jNNnBQpba4hJqhXcPAV6gvqu": { "n": "BTC Multiplier 157C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MuRMtDcrmS1XBhS4k6QwAJBTbFfYEFjBa": { "n": "BTC Multiplier 157B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CBYXuz1bLeo6DsU8YsF7mdtMUQuyL6hov": { "n": "BTC Multiplier 157A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15toJBsaWKW3T3BfhW8LJzhh8W8htpCyCL": { "n": "BTC Multiplier 156C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16fZFiPqrdCh1jHATE5zC6An5axhQBgQdT": { "n": "BTC Multiplier 156B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1QF9Pu8VtochJkWsz1dMjkusfTGuAs5TmV": { "n": "BTC Multiplier 156A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Nxg31UtBgezo3ddiph1bWrXZCKiWrSNFT": { "n": "BTC Multiplier 149C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1K6HwPbUq5WY9zLQ3faMCNhzBjHfDCTLRs": { "n": "BTC Multiplier 149B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HS5281NqBu2sDRsQqarNdbj4QWjeyAZ3n": { "n": "BTC Multiplier 149A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15yrAW64Nm1LxThgzsuUWBvtLU1hfYDJsW": { "n": "BTC Multiplier 148C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GseeMtiePUUi3kWvo4ZyX7yd8kTZQFHja": { "n": "BTC Multiplier 148B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FtLkY62aHGKBZwtL8kEMAQXddy5UvUTAr": { "n": "BTC Multiplier 148A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18u8pd1A5haR4MwmDLD2cwupT4KBFq8N82": { "n": "BTC Multiplier 147C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MV7TRfyjJEtgsvbD1ogA297Yb8SPTAY6Q": { "n": "BTC Multiplier 147B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1APidBPBZBB1oiJbguw7QvP2q25QUbqfQs": { "n": "BTC Multiplier 147A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NzzWeuKxj25JdeH3pf3EHquN5w41HHW7r": { "n": "BTC Multiplier 146C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19uiNRgev2pHoo9tvddyKog1qQaH11kxLG": { "n": "BTC Multiplier 146B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1F4TFP8UeqE8TciZCdpmoxHeiRAVnckcHi": { "n": "BTC Multiplier 146A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16hxt4tyRGPqsQSkbwhm1cbbeCzVxSPENS": { "n": "BTC Multiplier 145C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ZQ6jFG42GJbNrZeJUizxQh8CieaqxULq": { "n": "BTC Multiplier 145B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MV9mVLiNkdNr4QgHXwzjRety9fouiuWLs": { "n": "BTC Multiplier 145A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17vZ4FqoPAiEMKXvNzmfBjjmE8dsjbexY2": { "n": "BTC Multiplier 139C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1L9qgVkycxdGWspxwE2Ny7sQQyGCbaGw2a": { "n": "BTC Multiplier 139B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EvMfgMHYqxs54noVoG5mFNea9ENFbQgeS": { "n": "BTC Multiplier 139A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15KitBmTcXH8NV95BLRKNre8vGNSpYdx8n": { "n": "BTC Multiplier 138C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13kjumTYh1nHQiTcEd2LtYRorzkFN3KQgx": { "n": "BTC Multiplier 138B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1E8ttMxj2BrP9usWCqBqLf8DAhk6UBqhEg": { "n": "BTC Multiplier 138A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1w6yxQDXPD67H3vS16CzxE7r9n8wx7sHi": { "n": "BTC Multiplier 137C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MYpAMfkyVmccseSJouDjSJKdPPeu6x6JS": { "n": "BTC Multiplier 137B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KuuBJ9mh5oiHNiknGsJEfTMhCjg2Jae5b": { "n": "BTC Multiplier 137A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12re3SFnBn1XhhakUz2efgJ3aay5pigi7X": { "n": "BTC Multiplier 136C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GKokVZD6oQSjXBBgLrVUHVtJxuhWfUZuA": { "n": "BTC Multiplier 136B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KJaEpUb5sSpswhkJ32RCQAfncJkY8erNH": { "n": "BTC Multiplier 136A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MFRvEBe9WbD2fExq8HFYyiCwjNpZ4RYyE": { "n": "BTC Multiplier 135C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JdVD5pLg8fT47PxNq7ePZbCWdq1KrrVr8": { "n": "BTC Multiplier 135B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LKEFBeuAMdu1mrPx2Mo2HXDMzsDbUJA4E": { "n": "BTC Multiplier 135A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1T8V7fz3bRgX4nXDkB9G9mweJbmGvPPwj": { "n": "BTC Multiplier 134C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GZdoHBZLEoM8ciJva1D8RUys3VCz8nPeH": { "n": "BTC Multiplier 134B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18T9kd8DAvLz28wnFSxG6Cdw3EYSyp98aA": { "n": "BTC Multiplier 134A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CdhPrUWgUeR6WYg6TLns3UFubPWhdkB5T": { "n": "BTC Multiplier 129C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EKv1C9TuQG9LUUB23sAJBe3pifNx57YEc": { "n": "BTC Multiplier 129B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FZcsNiknDvoaiMnXeb6tDSaQuvfhk9DtP": { "n": "BTC Multiplier 129A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BySGaZpYmkfPEQANw1UP9rxTK1w5QDmgU": { "n": "BTC Multiplier 128C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17vhHmwJGwcs4QHKFPAJSstY7BhnojTwF7": { "n": "BTC Multiplier 128B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PDY1WkssEnYMQ4vFk1c8whvDPoKLyQKoy": { "n": "BTC Multiplier 128A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MCY7Q8UnWpjY7RBw8nFQ8hiHBH9ThZETA": { "n": "BTC Multiplier 127C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14PKabigaNt1z3sBXuhHhxgqFZ95kPWDHw": { "n": "BTC Multiplier 127B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14bqSeGXcdLDNMahTzjayR7b6mK2s8oywT": { "n": "BTC Multiplier 127A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NhMTXFjH6DNViGv5X2AxwDWQbJFGKFJ6F": { "n": "BTC Multiplier 126C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FhMEmVcCZuA3E7sYjxmewr2K5ePqguBWt": { "n": "BTC Multiplier 126B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1694yqgoU115utig1ra5Zt3yK4WbUGZpjQ": { "n": "BTC Multiplier 126A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18RAiiL9z7QL6RubRmMpP4pZgrFSGeg27Y": { "n": "BTC Multiplier 125C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"16ppMCE9ApzjX3B7accCiknhvkX5ypu4SU": { "n": "BTC Multiplier 125B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1wZQgkjkdivnKMzZSNWV6GXtGFoLXBuXH": { "n": "BTC Multiplier 125A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MWbCmbNvHpm47kjwkLbsVNn7oZoA5i5XE": { "n": "BTC Multiplier 124C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18yHhh24qNsp8z98wAhpq3ajw1e4h6N4Vh": { "n": "BTC Multiplier 124B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1F62bPshMHDuzGePPQZ4xHZP9TBPEaGFR6": { "n": "BTC Multiplier 124A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NdcMiWtcJWQ42myAjs45ZZCXbmobFZDtc": { "n": "BTC Multiplier 123C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1619jwHHPX2Ykvkf71HbfGCvqngfiG26vD": { "n": "BTC Multiplier 123B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NCQmcZR1g4GgMtvqp49beNh6BT2yLSkdi": { "n": "BTC Multiplier 123A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1rt98S1Wu7zgjhF3CMy5Zqf4eknuYNYL6": { "n": "BTC Multiplier 89C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LPoajsginRZgw247gZjDBxnxAc6Ngwn35": { "n": "BTC Multiplier 89B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Ar8vZ4iQvQD84KTLZjdX3MHGvMfcNm1ZJ": { "n": "BTC Multiplier 89A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Na8CH11iXWBs87XpDcYCWWbQrUfnzLXQ2": { "n": "BTC Multiplier 79C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"112P3XBE3CtJKKQS1p6XMjxCSgRenfh7pi": { "n": "BTC Multiplier 79B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12mMsk3GrxikPucXiXdvo9Qq46sdWFVQVH": { "n": "BTC Multiplier 79A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Cj6kUybMUWtvdjDnrdMGYLzMpMvJgFEFB": { "n": "BTC Multiplier 78C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ETooMDXLnrDmTGgNPBfbXgS9A9gUUTAQL": { "n": "BTC Multiplier 78B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13JukfPmmKHuA2KLtwKjENWNYrRMVqY7PK": { "n": "BTC Multiplier 78A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1YosHb3GnfNHYkwYowcgBVPd9Q787J99k": { "n": "BTC Multiplier 69C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14Sw1RmKMyQhKSzX1WHsGczJSYB7kNfeE4": { "n": "BTC Multiplier 69B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JJk7zbcUYbDQiK1KDHUcw6FQmpPYQvErK": { "n": "BTC Multiplier 69A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1B5oTHB2sy2uaouhrwbo8WMsMp1Z66pNCU": { "n": "BTC Multiplier 68C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EeDkrVdZhZyFfF21w3TUQnMahAyWvFaYs": { "n": "BTC Multiplier 68B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KXH3nRx5w9s31DYjtbYVijhd35SPB8zh8": { "n": "BTC Multiplier 68A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LWWfSE5m7J5hkmNn5esd9vEPLuSY2XsJr": { "n": "BTC Multiplier 67C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FEsxu1JE5NaYz66GTTrJP3j1L9YUgDnLw": { "n": "BTC Multiplier 67B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1F64RjJW7xnBp2cHQmFu87d7CCSrkhx5at": { "n": "BTC Multiplier 67A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LEUMmeZwH2BMd8ThEmBHRyJaMLCffF6Uw": { "n": "BTC Multiplier 59C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18t8en3s8s2k9ayjdfcxnbaFU2Qy6Cc82m": { "n": "BTC Multiplier 59B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ERciXRDuyBwdS3TUNUNMzRQnuNKXqjdqV": { "n": "BTC Multiplier 59A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1F7TW2zmPB27gJ4xBd9mo7M5S7nRNw6cgc": { "n": "BTC Multiplier 58C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AJnYNFasUyuVxxEiccV3VVbBxHMbx1Z1u": { "n": "BTC Multiplier 58B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17GEGBLKMKhDPoE6E19DwBctYcK92QEGvF": { "n": "BTC Multiplier 58A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12J2NECwAxXZTA1vRAq7hbZR3K8poHC13U": { "n": "BTC Multiplier 57C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PCEZ74HTnB5Bs3x5z1Ee69v4wk6691VVo": { "n": "BTC Multiplier 57B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12GEEkFtuh3Eme3Fnvto6g5R5FnLwHiqff": { "n": "BTC Multiplier 57A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FogvVngaCQtWKEtL4NMrELhZ1wKufGQrn": { "n": "BTC Multiplier 56C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17TC8Km8kV55GvgWVSHQiHAri5fFDSLacC": { "n": "BTC Multiplier 56B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Be5TsdQcc2vMR2jGa2BBtNft4RipRDYsf": { "n": "BTC Multiplier 56A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Cau4okLvpqgcwmSXknoLfdfHyr7H6ETek": { "n": "BTC Multiplier 49C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14SXzuJppL9Pmv5k8qRPV1MarDXyWyd7cz": { "n": "BTC Multiplier 49B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1LDSrJQZgSg9ZqZTAGDzzitsiZnJsJrjwM": { "n": "BTC Multiplier 49A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JGm1Pga73zKEfF8v7Doc8QZCyvbznT7QT": { "n": "BTC Multiplier 48C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17nFTXhcv2A32qzzagMmuGBZ3wV9dYXBJ4": { "n": "BTC Multiplier 48B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1L2Xnmy4LVQFSMJzVghr1BU4zAVC2HLieb": { "n": "BTC Multiplier 48A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KokeHuXgGTdeCjz8BBpjH5YfNLVKj27TT": { "n": "BTC Multiplier 47C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1H8qtBN8SD9A8iQ8wD7TbqRp37UmwhgGHq": { "n": "BTC Multiplier 47B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HMbn16cVXwRSJsnYLJj9PQC3Y3hVRH27i": { "n": "BTC Multiplier 47A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FZKpKVyj8ZUQXPWtPt8P3r6kUFEvUiHn1": { "n": "BTC Multiplier 46C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1B8NSYwuJ5UiMCRJ83FKY4AQJk9SKjQCVh": { "n": "BTC Multiplier 46B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CQMqwRQ6KjbhTDmz49FmpopkeqdPTGDfS": { "n": "BTC Multiplier 46A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Napnqf7CgaU6sTbgrscMNUHCYkVZMzV8s": { "n": "BTC Multiplier 45C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12yWZyFsC56Ffuhu6KDwQBn1i2Lz2QxLYh": { "n": "BTC Multiplier 45B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13xFAf6ZBpqXAazEa5jfLrKGccm1oeERKP": { "n": "BTC Multiplier 45A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FJJTqpF5pJceq1CrjT6ypVQHE4CvbWhxg": { "n": "BTC Multiplier 39C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AVq5hNMX9SHDKEAy9ZcTfQYGbo1y1S5Bj": { "n": "BTC Multiplier 39B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1KvYmA6WPsXX3cTkwjvgARe1GdcBZp2Ghu": { "n": "BTC Multiplier 39A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1jLpd1958rWNK85TE6mNEgWYRPUa1xvnp": { "n": "BTC Multiplier 38C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"162wQwHcZA8Guzd8FNBHTJQUr6BC57hF18": { "n": "BTC Multiplier 38B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PKNGieQLZpDwYoWiCNNjRETw8m2LwHBTT": { "n": "BTC Multiplier 38A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"131uYCioC6Tke9T1nqP4jcDBDKLn25g4NX": { "n": "BTC Multiplier 37C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1G5VDiprzZoSow2CLVAdjdRumBx7u3PvhT": { "n": "BTC Multiplier 37B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ET1QiShN6ZeTgGEUgi18UEAv69cA1BiiN": { "n": "BTC Multiplier 37A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1L51PcjNAMPdQfjayTiT2byCiHBuepcMA": { "n": "BTC Multiplier 36C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18CtHF4NLmzrdW8987yG7JPKopCYrQzNbK": { "n": "BTC Multiplier 36B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1ET9ErE5k6d9qiDjsFdmxovb2aUd6u36Wr": { "n": "BTC Multiplier 36A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1H1nmLrip7YPtrYMZMMg8UbTTGzVT9YAQb": { "n": "BTC Multiplier 35C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1C1AXsXsqKXTkLtgRJ7rSvfnD2GKV6VbGm": { "n": "BTC Multiplier 35B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"142XthK4gbpaQvybcRv6N5p1e1MZJJELBN": { "n": "BTC Multiplier 35A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GugaJNqf7gqCRbc3vDzRMV6sf1aB8AiUa": { "n": "BTC Multiplier 34C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PfG9i18mSLzbzr5tqm1LTCn4yvKZUjsJp": { "n": "BTC Multiplier 34B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18yAcn2BTffJocn1oZj4RR5mQQp64th7NG": { "n": "BTC Multiplier 29C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17ggc4JC35dxP2M3BBJ6ksYvNynAAn5NwC": { "n": "BTC Multiplier 29B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Lffbn2nAv9tnq3Ffwe6c4RnUzrPP9a96g": { "n": "BTC Multiplier 29A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"125dfz4PCdMyqAPt66uWzx5tn7uw2yrcEA": { "n": "BTC Multiplier 28C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1iesu21Fv59tPMw9TA3vcuLAFQjRyp4Bk": { "n": "BTC Multiplier 28B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JJRPJKcZKhk6H8CYEuocnyvDKh1VNxoFz": { "n": "BTC Multiplier 28A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GQwphqNKvneq5tok1S7rWvbVR2nYPKPc8": { "n": "BTC Multiplier 27C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EQpRf33n1hbGFZ2dhiZaH9BAwBoHwTMih": { "n": "BTC Multiplier 27B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JXotHppQcY1PBE8NXndu7yDeC8yRFF8o": { "n": "BTC Multiplier 27A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PHXknHiLfUKQP8eEm1u8jT9rVymXNgqG5": { "n": "BTC Multiplier 26C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FeoEX51iLUZM6nq4rSfuRRfFG1R4PMio9": { "n": "BTC Multiplier 26B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PgqMmTLp5bUZeQRai3MyFhkd61mP3BM2h": { "n": "BTC Multiplier 26A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Kdohz5cUenRPjZKuM9ZuKGamYz6hDAEti": { "n": "BTC Multiplier 25C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Jc7LetZKvFWGxArPdseThrPvkXAAT8L5Y": { "n": "BTC Multiplier 25B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12PazrUb62VFHwjEHTyJCfBiyj2Ped2NLP": { "n": "BTC Multiplier 25A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1J6hrmEHrs4pZi4LBPYfeJAwb5mdrv88CZ": { "n": "BTC Multiplier 24C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GR4HGbjEKnMv5nSiWz89EVM8attJeoJZc": { "n": "BTC Multiplier 24B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15XC4A4QXhUis1FDhWzV34E89JDHQSfND1": { "n": "BTC Multiplier 24A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1BSHiG4MbREuBK7vUcYFFs6HYk6VfkKNfe": { "n": "BTC Multiplier 23C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PBKU13xaXPYhF8qQWDrwrYwAmunKbKdSY": { "n": "BTC Multiplier 23B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"152uSkhGdbRDUQpyRpSdkqR4DqxbjVBeqR": { "n": "BTC Multiplier 23A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PnVSpRiaYr2FF6Lcx5iUakPX6UifawjYP": { "n": "BTC Multiplier 19C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1541Ncz1Vesbki8MomHH9c2ejNaSFkup8r": { "n": "BTC Multiplier 19B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1FyhJXKfCXVy44jQqTyMf52CJW1KrBPgy7": { "n": "BTC Multiplier 19A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1J9V4HihGSp2MmtueHpJheUV2gE3u2pF3g": { "n": "BTC Multiplier 18C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"13wgPMMMrQxwwhchxfJx8ZtjCQvyEACMRT": { "n": "BTC Multiplier 18B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18FouPoKzxpccwhxcEKChzyWEyyMFr7LoW": { "n": "BTC Multiplier 18A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1A7opJX69e3k8MAwP4DWXUg14iZXCmjxMa": { "n": "BTC Multiplier 17C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"136hNVt5L9vEqaNh8cC4rnupe9AFbZu2Hk": { "n": "BTC Multiplier 17B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Eyti8Jg9hVNAeUUT8sqB1J334x4u6RF44": { "n": "BTC Multiplier 17A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1MZVKwHdw4aMXjgJ77yVSPDhunkCX1t29x": { "n": "BTC Multiplier 16C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"12Ch5f7H7vVRz8VbL6GTVhYAvnmcfChYan": { "n": "BTC Multiplier 16B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15WFs6ru4qLDVJgrpZQ8uZuTXmRN6QdvTy": { "n": "BTC Multiplier 16A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17gDCZx3o6SqGEyk1DfQpjgeLGSftVidtX": { "n": "BTC Multiplier 15C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17TaLetxAPUddwwFtmiE3dCvrjCARBdmBa": { "n": "BTC Multiplier 15B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15dXcxuHJKVRYWfm3ZNq5t9L13mkFmBLwC": { "n": "BTC Multiplier 15A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17fDtST8d8TXvFtKLvy5KXf97UVCRrWqf1": { "n": "BTC Multiplier 14C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1PmNYBYkXMnXd1LDSXqxvHv9P7mY6Ppdwv": { "n": "BTC Multiplier 14B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GmvTJVFLMpVyEEWz9A9BAB7BJHCzXyVrU": { "n": "BTC Multiplier 14A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17ZUSKLD3YhV5tZ4ck1eyacN4LpgnEhW9": { "n": "BTC Multiplier 13C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NwohN27nxpH5xaX2u45t6TBTcq3cuj83Y": { "n": "BTC Multiplier 13B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1Nps3A3qMV8m17LMW8YYQtzXfNCtYr8FT6": { "n": "BTC Multiplier 13A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14modtt3bnqwsnsmT7M12hMKabELjXPaAT": { "n": "BTC Multiplier 12C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"15XzSGnywc3KWHBWY4seNLJSn7VZDQSASD": { "n": "BTC Multiplier 12B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"124SYJErwvWxuWDZRtRKUw2v2gZarRN7aA": { "n": "BTC Multiplier 12A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17wRDEktixAUa3x2xmzt7yi4c7BFMXQaHt": { "n": "BTC Multiplier 9C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AJrhf1XBqe49axHx1GsXhXB5SBcLcjvqk": { "n": "BTC Multiplier 9B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1HDoEsAEsQtRFJucpnc318BvDhjQPhoJjk": { "n": "BTC Multiplier 9A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14wgQf3KCLc29gheBAKoQJPDGniTbJCnrf": { "n": "BTC Multiplier 8C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EpKaycwUPFrmAZ9KkdBPJWtynWVD5xrhv": { "n": "BTC Multiplier 8B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JC7APoZigj5j5cGDuniPSswxLPTA8mw4T": { "n": "BTC Multiplier 8A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17SUjq6sQLGFegtKhCRUdHAdwYuZWDgZh2": { "n": "BTC Multiplier 7C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GtDi6mVSmXpioavTMVUSY2A7Y11NHZp9o": { "n": "BTC Multiplier 7B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"134c7N1NpCEvAFLFHMBqXTS6JGn1Fzrv9d": { "n": "BTC Multiplier 7A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17ZenMDEisZhM8yWwbv5fb16mzZVvoTNVC": { "n": "BTC Multiplier 6C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"17EKaL4KwTP7LidutMfa36XVMLySRW4Z8X": { "n": "BTC Multiplier 6B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1DFehxigaKMoRPGXkVKipTm5gGwPiMMcno": { "n": "BTC Multiplier 6A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1EZRLfrHZcygMQY29T6UbFkxM8Yaw1Sj3v": { "n": "BTC Multiplier 5C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1AE2uysEWpQa174MPSvQJjq7i3qwVc8UKr": { "n": "BTC Multiplier 5B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GSvdwLEMbUdyC5hvHje8fq56qSj1sAvM": { "n": "BTC Multiplier 5A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1JpeYXMyo2xhiF9rUmpPANsXu2wBPGkdSD": { "n": "BTC Multiplier 4C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"14AZ9PpxdMoxEbcpaJj6siAZYjt3iR7Kpy": { "n": "BTC Multiplier 4B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"19XDPatprgR82Ekntq9MCvQSq71qhB6doX": { "n": "BTC Multiplier 4A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1CEgoidyYo2Bhvxvo2FWAJ8t9yFBM2Z5s1": { "n": "BTC Multiplier 3C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NXuuvTRGf1Csyq8XX8oSij7WRHRugNu49": { "n": "BTC Multiplier 3B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1P8MBg9y8BFVYJTw6ujR9gW1J7oAzgqZSM": { "n": "BTC Multiplier 3A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1GwekGWoMJWVCdqsvH1WxT19Eraa7Hjwnr": { "n": "BTC Multiplier 2C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1NYD3R1PZsGMBEz1yc978Fq2ZebtXX2QZf": { "n": "BTC Multiplier 2B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1N6s4nhbVPQ89JvRpcgnJg5GhAF8RiQu7V": { "n": "BTC Multiplier 2A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"157Hj6WqFFSE9b4QzXvMfdsLLC8AnpwJk1": { "n": "BTC Multiplier 1C", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"18FJDTjjAqkWhh9PLi15nXyyzXkUPs5Uvo": { "n": "BTC Multiplier 1B", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"1E29yqLnvqCATLShSLnMYM9p3AcanGysBp": { "n": "BTC Multiplier 1A", "l": "http://btcmultiplier.com/games.php", "v": 1 },
	"188m4SS6z4yUSETwRcfTARopSXZTyhM2Yc": { "n": "Bitplay Donations", "l": "http://www.bitplay.co.uk", "v": 1 },
	"13dhfDmPEvMXCBs44rU6vCuTDK42rVoTtw": { "n": "The Universal Packing List", "l": "http://upl.codeq.info/", "v": 1 },
	"13vWVjrWNGpcq6XSS4BQQvHYgsLqevsKS4": { "n": "ftpbox.org", "l": "http://ftpbox.org/about/", "v": 1 },
	"1AjBcNSvnZsn3ESAH491hUbBrwM4Jmcuy9": { "n": "Antony Bailey - IT Consultant", "l": "http://www.antonybailey.net/payment", "v": 1 },
	"1EXfBqvLTyFbL6Dr5CG1fjxNKEPSezg7yF": { "n": "wizkid057 Eligius Mining", "l": "http://eligius.st/~wizkid057/newstats/userstats.php/1EXfBqvLTyFbL6Dr5CG1fjxNKEPSezg7yF", "v": 1 },
	"1CNyuBDVjy9EaFrsBEHBLAxpiyW3jeww8D": { "n": "megabitcoin", "l": "http://megabitcoin.blogspot.com.br/", "v": 1 },
	"166yC48RakrZdtsBj36vY9q29CpzknHbxY": { "n": "opensourceecology.org", "l": "http://opensourceecology.org/join.php", "v": 1 },
	"1F4Ka3nHH3Ef1P2f66AwLEqwHo6J9wFHKC": { "n": "nyc.wikimedia.org", "l": "https://nyc.wikimedia.org/wiki/Home", "v": 1 },
	"16oZXSGAcDrSbZeBnSu84w5UWwbLtZsBms": { "n": "The Daily Paul", "l": "http://www.dailypaul.com/270457/the-daily-paul-needs-your-help-fundraiser", "v": 1 },
	"1GovHK2U5cdErx1u4GQLX8MpYhmRZnFg75": { "n": "Jim Gauthier", "l": "https://sites.google.com/site/buriedkeys/", "v": 1 },
	"1MQVYyHAEE3S4iGCPUS6Kx3FYABconWBV6": { "n": "Jim Gauthier", "l": "https://sites.google.com/site/buriedkeys/", "v": 1 },
	"1KCdkqp1DE6wMWqN4rbv9vWp6wfVk6AeCX": { "n": "MuttsWorld", "l": "http://muttsworldmine.com/forums/topic/8731-bitcoins/", "v": 1 },
	"12PsJxbTdSSU5bkmNfqQcNASFkKgXUia6k": { "n": "Kai Elvin", "l": "http://kaielvin.org/", "v": 1 },
	"1JYYWLaFthqk2L59MXahkkQmaYmPz3hWVT": { "n": "Thebitcoinreview.com", "l": "http://www.thebitcoinreview.com", "v": 1 },
	"1N9DPbpKyeXNppELMx7QBhJRxDtFvHqsLH": { "n": "Howtobitcoin.info", "l": "http://howtobitcoin.info", "v": 1 },
	"1HsCdq5NZz71TEvb5rekYAsZsDjRyJKE2w": { "n": "Marty Anstey", "l": "http://marty.anstey.ca/", "v": 1 },
	"1faucetVPwoLCLU7kvGaanLGcbuprkFi3": { "n": "faucet.bitcoin.st", "l": "http://faucet.bitcoin.st/", "v": 1 },
	"1GCER7Fi3ZTFyxsBLLYgw4P7yitpc1WcG": { "n": "Bit Elfin 1", "l": "http://www.bitelfin.com", "v": 1 },
	"127wxm7auiMnBVFKiQ71PrpFHFPs7ob6Lj": { "n": "Bit Elfin 2", "l": "http://www.bitelfin.com", "v": 1 },
	"12eLUuMAZ7BAx7NLDPddUvgcaqoXbVfKPr": { "n": "Bit Elfin 4", "l": "http://www.bitelfin.com", "v": 1 },
	"13HBCMHZXuwvP25gw1fVsJtgpkhftK8QoW": { "n": "Bit Elfin 8", "l": "http://www.bitelfin.com", "v": 1 },
	"13RJi3H8sYP1tZzj4opEfxYCkXfGXDQMcX": { "n": "Bit Elfin 16", "l": "http://www.bitelfin.com", "v": 1 },
	"14UBW1YJVtiUcQbUd4dLq3tPaNE3Mna29q": { "n": "Bit Elfin 32", "l": "http://www.bitelfin.com", "v": 1 },
	"14afRMZm1iUKGt5qEBYPWj5WqixHXLUrMp": { "n": "Bit Elfin 64", "l": "http://www.bitelfin.com", "v": 1 },
	"16WjPJNtfKzQZDzCCdWseAfQBaACox2ktE": { "n": "Bit Elfin 128", "l": "http://www.bitelfin.com", "v": 1 },
	"15C92t8TCS93vBFR8Scxh54mrZ2v1NhavT": { "n": "Bit Elfin 256", "l": "http://www.bitelfin.com", "v": 1 },
	"18o16honiRV2ejf4yW2TqbgCJkT2yC5Xs3": { "n": "Bit Elfin 512", "l": "http://www.bitelfin.com", "v": 1 },
	"1AQykMhfLQuRNdcb2VctCehQqhBeXKosi3": { "n": "Bit Elfin 1000", "l": "http://www.bitelfin.com", "v": 1 },
	"1ATYXJbtT9wG5McpZEdFqJ3t5hFc9aDZ64": { "n": "Bit Elfin 1500", "l": "http://www.bitelfin.com", "v": 1 },
	"1BaK17zWPpyLtCkebmaxG55kkm14sLoHaE": { "n": "Bit Elfin 3000", "l": "http://www.bitelfin.com", "v": 1 },
	"1DzRAuir1tyfmwgr6LAXB4rh52fJPAjwR9": { "n": "Bit Elfin 4000", "l": "http://www.bitelfin.com", "v": 1 },
	"1ETjgqRfHbVUF48UTC4xVcswDeMVTS6LT9": { "n": "Bit Elfin 6000", "l": "http://www.bitelfin.com", "v": 1 },
	"1EcFcSCo2ByPvsyZ1wZweCGheWz5eAz2k9": { "n": "Bit Elfin 8000", "l": "http://www.bitelfin.com", "v": 1 },
	"1GfWXRdHvZifKqdYjEicVVugKDahSNyxCn": { "n": "Bit Elfin 12000", "l": "http://www.bitelfin.com", "v": 1 },
	"1HB6Ec2fS3Qo5cdAjUKDUAgpm5d2j9MMzT": { "n": "Bit Elfin 16000", "l": "http://www.bitelfin.com", "v": 1 },
	"18YRXXAa4q7JTfHjNDmqY8a91JKhH2JZfj": { "n": "Bit Elfin 32768", "l": "http://www.bitelfin.com", "v": 1 },
	"1LX4JDLY1nLi8zXg6Kdi3pcjUTNpbKuJ6E": { "n": "Bit Elfin 40000", "l": "http://www.bitelfin.com", "v": 1 },
	"1PDPiDXnjTPSguC7A9cw951C8MdtDGW2GS": { "n": "Bit Elfin 48000", "l": "http://www.bitelfin.com", "v": 1 },
	"1MjXKEnb7qBRvk8AxnbQgBVL1Q1heZ2QGP": { "n": "Bit Elfin 52000", "l": "http://www.bitelfin.com", "v": 1 },
	"1MWLKfzq4qvXrJH4bF35b8nYrSUfFAkiJT": { "n": "Bit Elfin 56000", "l": "http://www.bitelfin.com", "v": 1 },
	"1M6k1wwFyHf3eo5Nao2E5RhCUf1fFcPR8n": { "n": "Bit Elfin 60000", "l": "http://www.bitelfin.com", "v": 1 },
	"1LfdYVkjaCLj24s8uAoJsS8g6ULuVWXuW7": { "n": "Bit Elfin 64000", "l": "http://www.bitelfin.com", "v": 1 },
	"1EGMTY1hdq8xpmxNSR9UMh9TA4xY25f6f8": { "n": "c.zu.io", "l": "http://c.zu.io", "v": 1 },
	"1GATA3hUsxq3DmAhpACBHvB4r7u32xBRur": { "n": "GATA - Gold Anti Trust Action", "l": "http://www.gata.org/node/16", "v": 1 },
	"19m7Q8rb7tNy7TtbuUBvEmkHjcX7jQc2gn": { "n": "XAVOA", "l": "http://www.xavoa.com", "v": 1 },
	"1Az9K6WJrFXkjopNtsdLWKzCsehiAoNsux": { "n": "Queesbitcoin.info", "l": "http://www.queesbitcoin.info/", "v": 1 },
	"18fautnkHdkHBPBRvjL3Sd87KgH8mNebLc": { "n": "Bit Elfin", "l": "http://www.bitelfin.com", "v": 1 },
	"19txDGtqYQkSGqEPDjBD9BcCQvih1tYkZn": { "n": "Bit Elfin", "l": "http://www.bitelfin.com", "v": 1 },
	"12uArTbz4JnEZZq5Yk5y7GvXPu6tdHTDaf": { "n": "Happy Cat", "l": "http://bitcoingamblin.com", "v": 1 },
	"1CrKWKmoPTeS3ypDeJ1Creji8KPdFcLqn4": { "n": "Grumpy Cat", "l": "http://bitcoingamblin.com", "v": 1 },
	"15bPd9YSB3kpuAFFz2tBZh39A3XdnN5UoX": { "n": "leijurv", "l": "http://stinkopus.comyr.com/", "v": 1 },
	"1TBLoBWpg4N2H5oPo7XEsdj3EXaMK5U1k": { "n": "The Big List of Bitcoin", "l": "http://www.tblob.org/", "v": 1 },
	"1AmgrZLGhqaYtMGb1tauRuM22HFkXyM8np": { "n": "BitAurum.eu", "l": "https://www.bitaurum.eu/", "v": 1 },
	"1QATWksNFGeUJCWBrN4g6hGM178Lovm7Wh": { "n": "BFGMiner donations", "l": "https://bitcointalk.org/index.php?topic=78192.0", "v": 1 },
	"1E1igiusfEjs1pCaGjEERExE9gYcrFwow7": { "n": "Eligius mining pool donation", "l": "http://eligius.st/wiki/index.php/Eligius_mining_pool", "v": 1 },
	"1StatsgBq3C8PbF1SJw487MEUHhZahyvR": { "n": "Eligius wk stats donation", "l": "http://eligius.st/~wizkid057/newstats/", "v": 1 },
	"1A6JqrAjw22L4SDqBcjxfv6V8yqo4aPWsg": { "n": "drivelights", "l": "http://bitcoin-otc.com/viewgpg.php?nick=drivelights", "v": 1 },
	"1HDPXVhXLb445n54w5jcDXby9R4FGXPg5M": { "n": "webpg.org", "l": "http://webpg.org/?view=contribute#monetary", "v": 1 },
	"12YnJY2GHdyCw3LDsUiq39AXkDaM158EiD": { "n": "freifunk-rheinland.org", "l": "http://freifunk-rheinland.org/operation-storerhaftung.html", "v": 1 },
	"1wiki2XrnbicYg4XzrASXJ5pdyNrvPXP4": { "n": "Yamwat Open Source Project", "l": "https://github.com/yamwat/yamwat", "v": 1 },
	"1iJrUKjj57WoUHqBVMTzpK5z1XZxq2jed": { "n": "Mogambo Guru Report!", "l": "http://mogamboguru.blogspot.com.br/", "v": 1 },
	"1HeLbQaRRkRne2yoFj3mu9zoSRty3eeoPD": { "n": "Ballad of the Bitcoin", "l": "http://www.youtube.com/watch?v=1KsxHlJuVBU", "v": 1 },
	"1FinaerYEkMvCw2isEGFb9G2jSaGP328bD": { "n": "Max Min - Alpaca Socks", "l": "http://www.youtube.com/watch?v=pYqqS7aTBVQ", "v": 1 },
	"1MjCgW5E36mCYYsDrAUKzcxattcW4Bwi1X": { "n": "TOR Relay Node", "l": "http://torstatus.blutmagie.de/router_detail.php?FP=ca37697301883de9e895f642d76f3cd31e855434", "v": 1 },
	"1JDtLCrPABsWVAnmx1M3ZxbCTzEAueSiFy": { "n": "Robert Galovic", "l": "http://www.galovic.at/index.php?url=archives/3-Kontakt.html&serendipity[cview]=linear", "v": 1 },
	"143wiPvBqDG5kUkxv58tj6dSgaKPu2PP7H": { "n": "Pirate Party of Austria", "l": "http://wiki.piratenpartei.at/wiki/Kategorie:Spenden", "v": 1 },
	"19Y65w18A6pz1oJWWPuGN5bzxnQc5L3wbj": { "n": "W.Handl Scientology Lawsuit", "l": "http://www.wilfriedhandl.com/blog/zum-gerichtsprozess-von-scientology-gegen-mich/", "v": 1 },
	"15jwVv3y215iygkrVQuBXpQxRbKEkTJrAF": { "n": "Max Keiser Cigar Fund", "l": "http://maxkeiser.com/", "v": 1 },
	"1MgD6rah5zUgEGYZnNmdpnXMaDR3itKYzU": { "n": "Gribble IRC Bot", "l": "https://bitcointalk.org/index.php?topic=9753.0", "v": 1 },
	"1H14UUyCguVSJHbrAmXLS3Fk1BhGmqQB8b": { "n": "Torstatus.info", "l": "http://torstatus.info/donate.php", "v": 1 },
	"1DCDC1r1QAQLXyzZGELfoKTvCkfas2BrV": { "n": "Douglas County Dental Clinic", "l": "http://www.dcdclinic.org/", "v": 1 },
	"14nwg8VujSJAEpp798piRUYU25gApkWuoS": { "n": "BTC LTC China FUND", "l": "http://ltcbbs.com/forum.php?mod=viewthread&tid=137&extra=page%3D1", "v": 1 },
	"1G3c7ruLcjA6KPPesPbHZUvnX8e9NUTsPZ": { "n": "nlnet.nl", "l": "http://nlnet.nl/donating/donate.cgi?for=foundation", "v": 1 },
	"15oWEoG9dUPovwmUL9KWAnYRtNJEkP1u1b": { "n": "Petter Reinholdtsen", "l": "http://people.skolelinux.org/pere/blog/How_to_backport_bitcoin_qt_version_0_7_2_2_to_Debian_Squeeze.html", "v": 1 },
	"157i5gK7iN4bNAN39Ahuoiq6Tx5TaQukTE": { "n": "Hal Finney", "l": "https://bitcointalk.org/index.php?action=profile;u=2436", "v": 1 },
	"1FRQ2PgEPjTWAM6AzEL7zgoNQkTFjQS4tv": { "n": "Lurf", "l": "http://stinkopus.comyr.com/", "v": 1 },
	"12wr6DRVYaNkBpfegzFPaepZxRDZ9QTyS8": { "n": "Freedomsphoenix.com", "l": "https://www.freedomsphoenix.com/Secure/Contributions.htm?EdNo=001", "v": 1 },
	"1F7jqTihu4aGavq561vQzjDBDpfHsnyZs3": { "n": "Fairewinds.com", "l": "http://www.fairewinds.com/donations", "v": 1 },
	"15TUpE7Qtehxzrx2gMdE6jbHdQa42Edk4G": { "n": "Convergence.io", "l": "http://convergence.io/involved.html", "v": 1 },
	"129aYgYwr9YNimdjjaRxVvWF4bcyUxv2Zg": { "n": "Bitcoin paranoid", "l": "https://play.google.com/store/apps/details?id=br.eti.fml.satoshi&feature=search_result#?t=W251bGwsMSwyLDEsImJyLmV0aS5mbWwuc2F0b3NoaSJd", "v": 1 },
	"17vdUoaz2yaSdtZwxGYxX7fFxcHw5FfPdt": { "n": "yorba.org", "l": "http://yorba.org/donate", "v": 1 },
	"1BNTMBoTbAKfLtwCZrMb7XNPyroY9aVnYt": { "n": "TweepCoin", "l": "http://www.tweetsbroker.com/", "v": 1 },
	"15ZwRLnrfFxT9SzQTrKA5TKBQ6HM4Y4Pha": { "n": "TweetsBroker", "l": "http://www.tweetsbroker.com/", "v": 1 },
	"1FANHwPbfvb5NMKJKkCv9ujm5rHKBUjWUy": { "n": "BitCrate", "l": "http://www.bitcrate.net/", "v": 1 },
	"1FVUWTZiXuDBQWpMqgE725LGTyf5RhHs5a": { "n": "melvincarvalho.com", "l": "http://melvincarvalho.com/", "v": 1 },
	"1GfhjK6kYnPjVPhSP3bS1xuYu7cpEYxU1c": { "n": "Tuxavant", "l": "https://bitcointalk.org/index.php?action=profile;u=38164", "v": 1 },
	"12HdLgeeuA87t2JU8m4tbRo247Yj5u2TVP": { "n": "wearechange.org", "l": "http://wearechange.org/donate/", "v": 1 },
	"16KaCJB7fVuT6hvA7wzgzVjAnHz28bNvvh": { "n": "Bitcoin Reddit", "l": "http://www.reddit.com/r/Bitcoin/", "v": 1 },
	"15Mcm8ogeeGmsfhN4Y4zXF3nUgyuFMs9Kz": { "n": "ldmicro-jp", "l": "https://github.com/snipsnipsnip/ldmicro-jp/wiki", "v": 1 },
	"1LP3UcXPeL2U1juGwLSfQJdqPeXUZpwsBq": { "n": "Radio Reddit", "l": "http://www.reddit.com/r/RadioReddit", "v": 1 },
	"1DonatemDfMvQsLweYxPyA29rdgsXsxEc7": { "n": "Tampermonkey", "l": "http://tampermonkey.net/donate.html", "v": 1 },
	"19cdh1jEpRCGGZuLTszYzBGpnQr8xKsgF4": { "n": "Hardcoreforensics", "l": "http://hardcoreforensics.com/", "v": 1 },
	"18ix3ikc51sKTwmfho5fjmfqe2miJBQR2c": { "n": "Weenfan BCT", "l": "https://bitcointalk.org/index.php?action=profile;u=53499", "v": 1 },
	"12wnpFqYdg5SUngKHSEMUftt6CembCgwcW": { "n": "blockchained.com", "l": "http://blockchained.com/", "v": 1 },
	"1geeki6uL3Mq8xLMAkneT7Axjw1DR7VQC": { "n": "Geekbauchery", "l": "http://www.geekbauchery.com/home.html", "v": 1 },
	"12ctRXVVPAXQ6CQyEXkBhvi33K7kP4CMB5": { "n": "OpenCart_Bitcoin", "l": "https://github.com/btcgear/OpenCart_Bitcoin", "v": 1 },
	"1FA2GvT219G7ho8JcT6huFw6pmVdpTZwad": { "n": "Bitmarket.eu", "l": "https://bitmarket.eu/donate", "v": 1 },
	"13SjwsodtKsAhQwPx14s7aqKpnooeep4i5": { "n": "BitcoinJS", "l": "http://bitcoinjs.org/about.html", "v": 1 },
	"1FfcjP9jYCKi6chcdzXGAdtaJ5WSwRcYSY": { "n": "onion.to", "l": "http://onion.to/", "v": 1 },
	"1EVKwdLo4d5G3GJ2Xghi1s7XXxG5H6dZ5F": { "n": "The Bitcoin Trader", "l": "http://www.thebitcointrader.com/", "v": 1 },
	"1vrFK3JbzX3F2XRmejE675C4JZTTgf4on": { "n": "Bitcoin-24", "l": "https://bitcoin-24.com/donation", "v": 1 },
	"1Asaaki1CtV8zAUMwrnPviM7oLFmWUQ3cQ": { "n": "asaaki", "l": "http://christophgrabo.de/", "v": 1 },
	"19yHss6kekHJz6rfttyGjUVaLztKcVTHhq": { "n": "The Atheist Society", "l": "http://jointheatheistsociety.com/bitcoin-donations/", "v": 1 },
	"1NFDrKXQT5tQnfrXjj84UupTtCJEaYGG7K": { "n": "moartr4dez", "l": "http://bitcoin-otc.com/viewgpg.php?nick=moartr4dez", "v": 1 },
	"16eqgTLEoAqBFLxF5NDUMx8C82eeAmLq56": { "n": "Ektoplazm", "l": "http://www.ektoplazm.com/donate", "v": 1 },
	"1FABHACKq4emwb1FN9d9cfNCK8nyMC8gad": { "n": "fabhack", "l": "http://fabhack.com/", "v": 1 },
	"1DsQmTzYYn2roViiNQ24ZDFBez5at7dBeh": { "n": "Hardcoded Software", "l": "http://www.hardcoded.net/bitcoin", "v": 1 },
	"1BxG2ynUJrmHA6tsVkzKRaLHqoub8A5noB": { "n": "Tetranon Library Project", "l": "http://tetranon.org", "v": 1 },
	"1BRMLAB7nryYgFGrG8x9SYaokb8r2ZwAsX": { "n": "brmlab hackerspace prague", "l": "http://brmlab.cz/index-donate.html", "v": 1 },
	"1EQoqrJ6HjwzN2JiCowFWqD66YX4S6Xxvt": { "n": "Cryto Coding Collective", "l": "http://cryto.net/donate/", "v": 1 },
	"1ArmoryXcfq7TnCSuZa9fQjRYwJ4bkRKfv": { "n": "Armory Bitcoin Client", "l": "http://bitcoinarmory.com/", "v": 1 },
	"1AhN6rPdrMuKBGFDKR1k9A8SCLYaNgXhty": { "n": "MultiBit donations", "l": "http://multibit.org/index.html", "v": 1 },
	"1N65efiNUhH6sEQg7Z6oUC76kJS9Yhevyf": { "n": "tbcoin", "l": "https://bitcointalk.org/index.php?action=profile;u=48809", "v": 1 },
	"1Tro113yruFzZVECjjQMuQeMVtitDLwyM": { "n": "Troll! Film Crowdfunding", "l": "http://www.visionbakery.com/vision/650", "v": 1 },
	"1969VR2qCchXMW94tpcYirbVLUfFw4Pw7b": { "n": "CoinAd.com", "l": "https://coinad.com", "v": 1 },
	"1sewesoHPpnc43wJndLQaRU9V6Y4TWkyh": { "n": "seweso", "l": "http://seweso.com", "v": 1 },
	"18Dzeb3tkxFWWLk528XcxrHFRznyJ4dkZs": { "n": "BitcoinX", "l": "http://www.bitcoinx.org/donate/", "v": 1 },
	"1J6xJ4Z4wNXw7yGDQSVjHGjLtg3iLpMraM": { "n": "JURN", "l": "http://www.jurn.org/", "v": 1 },
	"1F9iT5J7PHNFp93yYq8EtjKpYC8WxcWe6Q": { "n": "Protest Barrick", "l": "http://protestbarrick.net/article.php?id=764", "v": 1 },
	"1794BjDc9Q7GED4DW7MYWkM5fEhMc7U6zU": { "n": "adaptive.mobi", "l": "http://adaptive.mobi", "v": 1 },
	"17Pa8QMdxxbuzZjWiwmfjMZLXb1tAUrUM7": { "n": "BitAurum.eu", "l": "https://www.bitaurum.eu", "v": 1 },
	"1CPKAMtD4bcLrh8SRHfSxBBMmQQ5cqahPZ": { "n": "Raided for Tor", "l": "http://raided4tor.cryto.net/donate/", "v": 1 },
	"157WZSD1bDyJNWVQrKqaf5oF343q9Dscuf": { "n": "OpenELEC", "l": "http://openelec.tv/", "v": 1 },
	"1LDCRDhNBiTaurUmJKqRef3cGpWLWfEpFk": { "n": "BitAurum.eu", "l": "https://www.bitaurum.eu", "v": 1 },
	"1NmduGNyC5XejoysbuioodCN3jR3yf64xM": { "n": "Electrum", "l": "http://electrum.ecdsa.org/community.html", "v": 1 },
	"1BTC24yVKQdQNAa4vX71xLUC5A8Za7Rr71": { "n": "Bitcoin-24.com", "l": "https://bitcoin-24.com", "v": 1 },
	"14FHqYSgAi39CEJksUJJsK8JzJzyqFpLVk": { "n": "xkcd", "l": "http://xkcd.com/bitcoin/", "v": 1 },
	"16xTfttqg6DbvkAGpPvWWpEhEC4e1fCG7G": { "n": "Genesis2church.org", "l": "http://genesis2church.org/donate-with-bitcoin.html", "v": 1 },
	"13RcqwggWi9VwcPCZ5BeScxZLWPtt3NVzf": { "n": "Skeptinerd", "l": "http://www.skeptinerd.com/donate-with-bitcoin/", "v": 1 },
	"1Kj7V3CYk4TzmE5cgYR7UVbejgFVRbqSwu": { "n": "WeUseCoins", "l": "http://www.weusecoins.com/about.php", "v": 1 },
	"1HCMw4nJMT9C6aXaE4EFUb4UbYLg9qpGqw": { "n": "A Lightning War for Liberty", "l": "http://libertyblitzkrieg.com/donate-via-bitcoin-2/", "v": 1 },
	"1N1WivuXZaHYtBrTMLkUwwctGriyxSh8Nz": { "n": "Earthquake &amp; Tsunami", "l": "https://twitter.com/EQTW/status/273758324858687489", "v": 1 },
	"1trosVaFXcjY5Efo2eW4ENFakp3RFsNxw": { "n": "tehtros", "l": "https://twitter.com/tehtros", "v": 1 },
	"1J2W6fK4oSgd6s1jYr2qv5WL8rtXpGRXfP": { "n": "The Rational Argumentator", "l": "http://www.rationalargumentator.com/index/", "v": 1 },
	"1M87hiTAa49enJKVeT9gzLjYmJoYh9V98": { "n": "Antiwar.com", "l": "http://antiwar.com/blog/2012/11/27/an-alternative-way-to-help-antiwar-com/", "v": 1 },
	"1DhiGZoPMWW2L46Cr5RZoZUCsKTB6bab6a": { "n": "Bitcoin Revolution", "l": "http://www.bitcoinrevolution.com.br/", "v": 1 },
	"1KJokeJXBt2u5WcKQ2QMqH6erz8VszDPmi": { "n": "sebaygo1", "l": "http://sebaygo1.blogspot.com.br/", "v": 1 },
	"1HUrNJfVFwQkbuMXwiPxSQcpyr3ktn1wc9": { "n": "Singularity Institute", "l": "http://singularity.org/donate/", "v": 1 },
	"15u8aAPK4jJ5N8wpWJ5gutAyyeHtKX5i18": { "n": "F-Droid", "l": "http://f-droid.org/", "v": 1 },
	"1DjkcdQgkpa3obWPTnbxk7gcsW6qS7h7ni": { "n": "Digital Precursor", "l": "http://www.digitalprecursor.org/content.php/93-Anonymous-Donations-Now-Available", "v": 1 },
	"1KrPPM8VTyLTzjf7goCnHgj11QJZvtSRvY": { "n": "Chamba Project", "l": "http://www.chambaproject.in/contribute/", "v": 1 },
	"12y11u5DBXpQ8XM3g6o6Wc155S16maTWL6": { "n": "Bluetile", "l": "http://www.bluetile.org/#development", "v": 1 },
	"1LwSugK8X8kRpV3sex9f8KTjVPc52FPaEq": { "n": "dyne.org", "l": "http://www.dyne.org/donate/", "v": 1 },
	"1ESKsNEfjmCZJt3yEYjdE31L1QKqnRVcmn": { "n": "Juice Rap News", "l": "http://thejuicemedia.com/donate/", "v": 1 },
	"1fakk2uakbGyz9M3bADeYXDSRzX4aBFyG": { "n": "J-Norm", "l": "https://bitcointalk.org/index.php?action=profile;u=71533", "v": 1 },
	"1kqHKEYYC8CQPxyV53nCju4Lk2ufpQqA2": { "n": "Bitcoin Charts", "l": "http://bitcoincharts.com", "v": 1 },
	"1PPVzjfPZece9mwJKdPB5Kbhv4JiSemFCu": { "n": "Bitcoin Watch", "l": "http://bitcoinwatch.com", "v": 1 },
	"1PMPKn2iHWeRrDNrVDBeZV35s4NK5vdnzx": { "n": "Bitcoin Classifieds", "l": "http://www.bitcoinclassifieds.net", "v": 1 },
	"1BrBtEHhwP8L5xqNscqrPSVvBjuVhMEDGD": { "n": "The Biggest Fish", "l": "https://bitcointalk.org/index.php?topic=127159.0", "v": 1 },
	"129aqQRs1dwws3bfPQ9YggKhRmPBPYNoCW": { "n": "Tuxavant", "l": "https://bitcointalk.org/index.php?action=profile;u=38164", "v": 1 },
	"15J7hFh7xVYyVtMnuotZgxzhDFDQa71w3a": { "n": "Bitcoin.Travel", "l": "http://bitcoin.travel/donate/", "v": 1 },
	"1STRonGxnFTeJiA7pgyneKknR29AwBM77": { "n": "Strongcoin", "l": "http://strongcoin.com", "v": 1 },
	"1KNowBiT5wKF3q6dosBr6BR2JMjCpPasK8": { "n": "Know A Bit More", "l": "http://bitcoin.chromaticcreative.net/bitcoin/kabm/", "v": 1 },
	"1F1dPZxdxVVigpGdsafnZ3cFBdMGDADFDe": { "n": "Bitcoin-otc Donations", "l": "http://bitcoin-otc.com", "v": 1 },
	"1PPVupRRz7tHvfvJWEDBnDr7bFVFFYLu6G": { "n": "AnonNews", "l": "http://anonnews.org/static/donate", "v": 1 },
	"1BnJERBvSSDCqskpFqjStZSwJ8jxcfBtZV": { "n": "Awesome window manager", "l": "http://awesome.naquadah.org/community/", "v": 1 },
	"1PWiRE16PJsEuax2Yr7EuK93q3ueDB58AE": { "n": "ReactOS Project", "l": "http://www.reactos.org/en/foundation_donate.html", "v": 1 },
	"1LLFyRqHopLAf9RrxwtpUGbqSQ7QgrbkGY": { "n": "CubeSpawn", "l": "http://cubespawn.com/donate.html", "v": 1 },
	"1CRACkbiJSxfDaLNEoaNsHjNtU4KttwHyo": { "n": "DICEonCRACK [Busto]", "l": "http://diceoncrack.com", "v": 1 },
	"1CRACKafkXsQzUYmu2fUM3j9c2y4yDhvfh": { "n": "DICEonCRACK [Exit]", "l": "http://diceoncrack.com", "v": 1 },
	"1CRACKLiwFrZbAQz1yb9w22onHCMLbiMTY": { "n": "DICEonCRACK Martingale", "l": "http://diceoncrack.com", "v": 1 },
	"1CRACK25QvpVdcEmPZVD5ixtf99cMF9stg": { "n": "DICEonCRACK Simple", "l": "http://diceoncrack.com", "v": 1 },
	"1Stackh8FGpMphHHjAtUuzDGk8wDYk8fn": { "n": "Stackunderflow", "l": "http://www.stackunderflow.com/", "v": 1 },
	"16bLvD2Vzmn2LGXvgyb42RC6jYZZ68uA7v": { "n": "Dawid Ci&#281;&#380;arkiewicz", "l": "http://dpc.ucore.info", "v": 1 },
	"1AuzS9Ldzc4Fr4ESNGqsEYE1ekcZehjK7d": { "n": "Nicolas Mendoza", "l": "http://nicolasmendo.wordpress.com/", "v": 1 },
	"12JiynsQcfNLbeWnM7cdnYGo3axPXDcwCV": { "n": "Wikispeed", "l": "http://wikispeed.com/wikispeed-team-blog/wikispeed-first-car-maker-in-the-world-to-accept-bitcoin-press-release", "v": 1 },
	"18tuJSMNt7jcrUpqrbncH3jEPdUPxdHaq": { "n": "Seymour Buhts", "l": "http://seymourbuhts.tumblr.com/", "v": 1 },
	"16cv6gTgN2U8DfKxAg7m4pDhChxQPvqJoK": { "n": "Thejeshgn Developer", "l": "http://thejeshgn.com", "v": 1 },
	"1AGriCoCBRbgca61ZJrqgVt78HJ94QXNcg": { "n": "Agricocb", "l": "http://theagricolas.org/craig/#Bitcoin", "v": 1 },
	"1FrtkNXastDoMAaorowys27AKQERxgmZjY": { "n": "Instawallet Cold Storage", "l": "http://instawallet.org", "v": 1 },
	"1Aosc1wUGx9s4h42sPKbHXzGJHKt8LijZp": { "n": "Alloscomp Donations", "l": "http://www.alloscomp.com/donate.html.php", "v": 1 },
	"139ys2VPMLWrpqMRek2E8xe5c7Ui8CHnf7": { "n": "Game Slayer", "l": "http://www.gameslayer.org", "v": 1 },
	"15xrSpmhP4WriZhbpx5o6udpVw76TPsmWX": { "n": "gooldengoose", "l": "http://pastebin.ca/2262402", "v": 1 },
	"17VMak2Y8sdjK8NTk7ppFmFaVxSVD9ZgaL": { "n": "TN3T TOR", "l": "http://tn3t.com/", "v": 1 },
	"1Nu17Zts5WFjgWexW3mMxrbzZy5phmWtQ4": { "n": "Boulder Meshnet", "l": "https://github.com/evbogue/bouldermeshnet", "v": 1 },
	"1DhNogiveWuLvhhhjBq5BYozS1kaYHE2ZX": { "n": "JuicinJake", "l": "http://juicingvegetables.me/", "v": 1 },
	"12ekC8f3ThkWRJYpEKYaa3vqYbtjHZy3PA": { "n": "YelloSoft", "l": "http://www.yellosoft.us/donate", "v": 1 },
	"13m8dAb16KqWv7v9oEsr97mYMXbynR6CoD": { "n": "MinecraftCC Mine4BTC Project", "l": "http://minecraftcc.com/index.php?threads/information-about-getting-paid-to-mine.4613/", "v": 1 },
	"1JoyZBGXKdSSeTpLHMLGTSLUDKbLLjWqjt": { "n": "Daily Anarchist", "l": "http://dailyanarchist.com/contribute/", "v": 1 },
	"1QEgRqvF3sVqzpqb95B7TgZg8Km8grTeRk": { "n": "Chris Wilmer", "l": "http://chriswilmer.webatu.com/about.php", "v": 1 },
	"1BTCorgHwCg6u2YSAWKgS17qUad6kHmtQW": { "n": "Bitcoin Foundation", "l": "https://bitcoinfoundation.org/donate", "v": 1 },
	"1HB5XMLmzFVj8ALj6mfBsbifRoD4miY36v": { "n": "WikiLeaks", "l": "http://shop.wikileaks.org/donate", "v": 1 },
	"19HcFgnnJseANJAHUjFifVwz68AGYrHc7v": { "n": "P2P Foundation", "l": "http://blog.p2pfoundation.net/why-the-p2p-foundation-is-paying-its-salaries-in-bitcoin/2012/03/28", "v": 1 },
	"1BteW1uy7zNXMNqhFdvFafbJLd1HcHVPLx": { "n": "Ripplepay", "l": "https://ripplepay.com/donate/", "v": 1 },
	"1MyZjxnLgun6APrDkkh7ffrQJyy6xbuDho": { "n": "FreedomBox Foundation", "l": "http://freedomboxfoundation.org/donate/", "v": 1 },
	"1Gpa3NKn8nR9ipXPZbwkjYxqZX3cmz7q97": { "n": "Ancientbeast.com", "l": "http://ancientbeast.com/donate/", "v": 1 },
	"1Pug3dAjqXYUkYkjppHjQyZia2xgM79YZV": { "n": "Blockbox Linux", "l": "http://www.backbox.org/donate", "v": 1 },
	"1wdociqV3xXf8AnEeoPR2jzvVpk1ptH9N": { "n": "Osiris-sps.org", "l": "http://www.osiris-sps.org/donations/", "v": 1 },
	"18S8ugWEuWLbMP9DBpBdDk9SN6CiRxZB8S": { "n": "The Free Network Foundation", "l": "http://commons.thefnf.org/index.php/Needs", "v": 1 },
	"17RTTUAiiPqUTKtEggJPec8RxLMi2n9EZ9": { "n": "Bitcointalk Forums", "l": "https://bitcointalk.org/donate.html", "v": 1 },
	"1Q1Vh8Mfr2yNeDogtJWNLMZCdxteCwbueE": { "n": "OpenGameArt", "l": "http://opengameart.org/content/donate-bitcoins", "v": 1 },
	"1KLhvgi9exzvea7fr1CNdHroDC28SkkvEL": { "n": "Torservers", "l": "https://www.torservers.net/donate.html", "v": 1 },
	"1PC9aZC4hNX2rmmrt7uHTfYAS3hRbph4UN": { "n": "Free Software Foundation", "l": "https://my.fsf.org/donate/other/", "v": 1 },
	"1HkJCceXf7of1sTNRVJbXiZHfDTLL71Siy": { "n": "I2P Network", "l": "http://www.i2p2.de/donate.html", "v": 1 },
	"1966U1pjj15tLxPXZ19U48c99EJDkdXeqb": { "n": "The Freenet Project", "l": "https://freenetproject.org/donate.html", "v": 1 },
	"1PJrWFMVipCtLZX296zi8fP3iWuPQu2gz3": { "n": "Encyclopedia Dramatica", "l": "https://encyclopediadramatica.se/Encyclopedia_Dramatica:Donate", "v": 1 },
	"17gN64BPHtxi4mEM3qWrxdwhieUvRq8R2r": { "n": "Archive.org", "l": "http://archive.org/about/faqs.php", "v": 1 },
	"1ALzEGMCU5EmycJZVCpAymXEaUVkV3V2cp": { "n": "Erowid donations", "l": "http://www.erowid.org/donations/donations_bitcoin.php", "v": 1 },
	"1BTCDiceLs79syendE1DM1XCaHcKkzBNnP": { "n": "BTC Dice 73%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDicen28RVKQeMCPKyEcEWFVE9MpJ1i": { "n": "BTC Dice 50%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDicesCsTaUFWwQb7XbQhAKv4bAiFK8": { "n": "BTC Dice 48%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceqN5FPKDYKuLWV1nrnngpw5Yw6x": { "n": "BTC Dice 36%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceVit4ZoX62ksdLCbD3fsUww1hX6": { "n": "BTC Dice 24%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceCn5s35GXZUqrTGjhuvkQs178hk": { "n": "BTC Dice 18.3105%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceANi5VQdNZowTCvLmYgTGfk84cR": { "n": "BTC Dice 12.2070%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceGyxvznJb7XSKdWB9NdA1T2fdLG": { "n": "BTC Dice 9.1553%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceWpWYwuvpANwbaGKG9snBdsGgtN": { "n": "BTC Dice 6.1035%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDice1jWgi1jKgtXogwz5c66kbwm4dP": { "n": "BTC Dice 4.5776%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDicempBsRnQ7u1xnG23SAtggUtbq13": { "n": "BTC Dice 3.0518%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDicei8W5eHzLzv1eqzfSGhhinNqkzd": { "n": "BTC Dice 2.2888%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDicekz95rwEcj4rZefDVJtyTwPt7KX": { "n": "BTC Dice 1.5259%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDice7EStrgsTSi5rX4qB5ER65KnF1r": { "n": "BTC Dice 0.7813%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDice8b3ChyAXFJEx2JAZwTk3i3UCcm": { "n": "BTC Dice 0.3906%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceDic8QqnLzh8p7HsV1RUsR27nPf": { "n": "BTC Dice 0.1953%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceLVZ53UAVhbtXGcMfGEJ7BCt8yK": { "n": "BTC Dice 0.0977%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceEd3hyYuVtE4MgoTK9weqSojwgg": { "n": "BTC Dice 0.0488%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceAUjAC1KSq1VWoQnurBEgpEQH2V": { "n": "BTC Dice 0.0244%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDicedocDkrvtpNZdREWL8wKoSE5wGw": { "n": "BTC Dice 0.0122%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDiceyPUP9jMerproE7xz38Mx43rD5x": { "n": "BTC Dice 0.0061%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDicesyDrMQZFDdfUnohtrwzzcs7B5e": { "n": "BTC Dice 0.0031%", "l": "http://btcdice.com", "v": 1 },
	"1BTCDicebPtiq4kH9HfYQn9Gzx2F3j26s5": { "n": "BTC Dice 0.0015%", "l": "http://btcdice.com", "v": 1 },
	"1LuckyaCJbZr8P3nk2VmsFEBw25PPFjkou": { "n": "BtcLucky 0.0015%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyujubWhEc2C4uWu33R4PEbErVF1vg": { "n": "BtcLucky 0.003%", "l": "http://btclucky.com/", "v": 1 },
	"1Luckyr8eVz7Ze89Mfy1wrPsBwJqq3ov1u": { "n": "BtcLucky 0.007%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckymncBiTfKF9FT9UvqQfH4s1PC9N7P": { "n": "BtcLucky 0.01%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyNW4fjUBU1fBPiSocsb9rzohPvRMt": { "n": "BtcLucky 0.02%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyGkR5RMWrBC4LT4d9YRc787KMfq9w": { "n": "BtcLucky 0.05%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyFYuRPfuQE9JqvHt5NSkSTTkyZniy": { "n": "BtcLucky 0.09%", "l": "http://btclucky.com/", "v": 1 },
	"1Lucky9uxBxoUH48K19Zj2Vy9xgAvPZQL1": { "n": "BtcLucky 0.2%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyEPZn3pj1AxyMfh1kakYAaCtB4C8i": { "n": "BtcLucky 0.3%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyK5vuwkp35VEHFQqFX6ZdGxiYjpr3": { "n": "BtcLucky 0.7%", "l": "http://btclucky.com/", "v": 1 },
	"1Luckygj8fEkYZWdyfFkRq4c9yyyNUY45L": { "n": "BtcLucky 1.5%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyYRDwP4xsrFuBUzPFRn4m6bHVG42d": { "n": "BtcLucky 2.2%", "l": "http://btclucky.com/", "v": 1 },
	"1Lucky7cM7kYtG2kZ7YP5y1okzWJqNRsMD": { "n": "BtcLucky 3%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyhJMBiBDKoxke1fHgkGCqD6ApkfHa": { "n": "BtcLucky 4.5%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyYq3JS3nS3kmEUtejnZB5qb28gXNP": { "n": "BtcLucky 6%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyFTfJs7kKYpGR3m6YvsaK43C8YKLV": { "n": "BtcLucky 9%", "l": "http://btclucky.com/", "v": 1 },
	"1Lucky4JHyoP85DzCBxVfem8Ki6rP9CQpH": { "n": "BtcLucky 12%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyUx6vhw2dsDZPAxYDdkzWepPvFcvT": { "n": "BtcLucky 18%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyRScxX9DYXxRuVDwTJgQLZrtto2At": { "n": "BtcLucky 24%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyzKVkntzmUykxxgVEgB2U6rQF4xQ3": { "n": "BtcLucky 36%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyDN5abkrCiK4rZP6SKQmoRbGc8BTG": { "n": "BtcLucky 48%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyrM48Faa9nK725mX7J5X7FSeFqTar": { "n": "BtcLucky 50%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyoLb6EBLbrbzKWU2N9MSmMuHSNBwZ": { "n": "BtcLucky 73%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyiHScrbaaH47yDcTCPbnVmAE2AG5h": { "n": "BtcLucky 79%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyZciMQbsNFRD7NHhh1ZMzPHi3ei7d": { "n": "BtcLucky 85%", "l": "http://btclucky.com/", "v": 1 },
	"1LuckyPnzCDiY5MbCotfzqr3yRb6GreAkX": { "n": "BtcLucky 91%", "l": "http://btclucky.com/", "v": 1 },
	"1Luckyd4jkxhANGvoBMSU77naksgFLzWXu": { "n": "BtcLucky 97%", "l": "http://btclucky.com/", "v": 1 },
	"1CDysWzQ5Z4hMLhsj4AKAEFwrgXRC8DqRN": { "n": "Instawallet", "l": "https://instawallet.org", "v": 1 },
	"1LNWw6yCxkUmkhArb2Nf2MPw6vG7u5WG7q": { "n": "Mt.Gox", "l": "https://mtgox.com", "v": 1 },
	"1dice1e6pdhLzzWQq7yMidf6j8eAg7pkY": { "n": "SatoshiDICE 0.0015%", "l": "http://satoshidice.com", "v": 1 },
	"1dice1Qf4Br5EYjj9rnHWqgMVYnQWehYG": { "n": "SatoshiDICE 0.003%", "l": "http://satoshidice.com", "v": 1 },
	"1dice2pxmRZrtqBVzixvWnxsMa7wN2GCK": { "n": "SatoshiDICE 0.006%", "l": "http://satoshidice.com", "v": 1 },
	"1dice2vQoUkQwDMbfDACM1xz6svEXdhYb": { "n": "SatoshiDICE 0.01%", "l": "http://satoshidice.com", "v": 1 },
	"1dice2WmRTLf1dEk4HH3Xs8LDuXzaHEQU": { "n": "SatoshiDICE 0.02%", "l": "http://satoshidice.com", "v": 1 },
	"1dice2xkjAAiphomEJA5NoowpuJ18HT1s": { "n": "SatoshiDICE 0.04%", "l": "http://satoshidice.com", "v": 1 },
	"1dice2zdoxQHpGRNaAWiqbK82FQhr4fb5": { "n": "SatoshiDICE 0.09%", "l": "http://satoshidice.com", "v": 1 },
	"1dice37EemX64oHssTreXEFT3DXtZxVXK": { "n": "SatoshiDICE 0.19%", "l": "http://satoshidice.com", "v": 1 },
	"1dice3jkpTvevsohA4Np1yP4uKzG1SRLv": { "n": "SatoshiDICE 0.39%", "l": "http://satoshidice.com", "v": 1 },
	"1dice4J1mFEvVuFqD14HzdViHFGi9h4Pp": { "n": "SatoshiDICE 0.78%", "l": "http://satoshidice.com", "v": 1 },
	"1dice61SNWEKWdA8LN6G44ewsiQfuCvge": { "n": "SatoshiDICE 2%", "l": "http://satoshidice.com", "v": 1 },
	"1dice6DPtUMBpWgv8i4pG8HMjXv9qDJWN": { "n": "SatoshiDICE 3%", "l": "http://satoshidice.com", "v": 1 },
}

var nodes = []
var links = []


var width = window.innerWidth
var height = window.innerHeight

String.prototype.trunc = String.prototype.trunc || function (n) { return (this.length > n) ? this.substr(0, n) + '...' : this }

Number.prototype.formatMoney = function (c, d, t) {
	var n = this,
		c = isNaN(c = Math.abs(c)) ? 2 : c,
		d = d == undefined ? "." : d,
		t = t == undefined ? "," : t,
		s = n < 0 ? "-" : "",
		i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
		j = (j = i.length) > 3 ? j % 3 : 0;
	return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
}

var svg = d3.select('svg')
svg.attr('width', width).attr('height', height)

svg.append('defs').append('marker')
	.attr('id', 'arrowhead')
	.attr('viewBox', '-0 -5 10 10')
	.attr('refX', 20)
	.attr('refY', 0)
	.attr('orient', 'auto')
	.attr('markerWidth', 10)
	.attr('markerHeight', 10)
	.attr('xoverflow', 'visible')
	.append('svg:path')
	.attr('d', 'M 0,-5 L 10 ,0 L 0,5')
	.attr('fill', 'rgb(127, 127, 127)')
	.style('stroke', 'none')

var linkElements, nodeElements

var linkGroup = svg.append('g').attr('class', 'links')
var nodeGroup = svg.append('g').attr('class', 'nodes')

var collide = d3.forceCollide().radius(function (node) {
	var balance = (discoveredAddresses.has(node.id) ? discoveredAddresses.get(node.id)["final_balance"] : estimatedAddreses.get(node.id)) / 100000000.0
	return 2 * (Math.log(Math.max(1, balance)) * 10 + 10)
})

var simulation = d3
	.forceSimulation()
	.force("collide", collide)
	.force('link', d3.forceLink().id(function (link) { return link.id }))
	.force('charge', d3.forceManyBody().strength(-100).distanceMax(200))
	.force('center', d3.forceCenter(width / 2, height / 2))
	.velocityDecay(0.95)

var dragDrop = d3.drag().on('start', function (node) {
	node.fx = node.x
	node.fy = node.y
}).on('drag', function (node) {
	simulation.alphaTarget(0.7).restart()
	node.fx = d3.event.x
	node.fy = d3.event.y
}).on('end', function (node) {
	if (!d3.event.active) simulation.alphaTarget(0)
	node.fx = null
	node.fy = null
})

d3.select(window).on('resize', resize);
function resize() {
	var width = window.innerWidth, height = window.innerHeight;
	svg.size([width, height]);
	simulation.force('center', d3.forceCenter(width / 2, height / 2))
	simulation.restart()
}


var tooltip = d3.select("#tooltip");

tooltip.style("max-width", "450px")
    .style("background-color", "#F0ECE5")
    .style("border-radius", "30px")
    .style("padding", "12px")
    .style("display", "none");

var tooltipActive = false

svg.call(d3.zoom().scaleExtent([1 / 8, 8]).on("zoom", zoomed));
function zoomed() {
	nodeGroup.attr("transform", d3.event.transform);
	linkGroup.attr("transform", d3.event.transform);
}

function selectNode(selectedNode) {
	d3.select(this).attr('fill', 'rgba(127, 127, 127, 0.5)')
	M.toast({ html: 'Loading ' + selectedNode.id, displayLength: 2000 })
	lookup(selectedNode.id, 0, function (result) { updateBlockchain(selectedNode.id, result, 0, selectedNode.distance) }, function (status) {
		M.toast({ html: "Error:" + status, displayLength: Infinity })
		console.error("Error", status)
	})
}

var fillStyle = 0;
var updateFillStyle = function (choosen) {
	fillStyle = choosen
	nodeElements.remove()
	updateSimulation()
}

function updateGraph() {
	// links
	linkElements = linkGroup.selectAll('line')
		.data(links, function (link) { return link.target.id + link.source.id })

	linkElements.exit().remove()

	var linkEnter = linkElements
		.enter().append('line')
		.attr('stroke-width', 1)
		.attr('id', function (node) { return 'link_' + node.source + '_' + node.target })
		.attr('class', function (node) { return 'connects_' + node.source + ' connects_' + node.target })
		.attr('stroke', 'rgb(127, 127, 127)')
		.attr('opacity', '0.25')
		.attr('marker-end', 'url(#arrowhead)')

	linkElements = linkEnter.merge(linkElements)

	nodeElements = nodeGroup.selectAll('circle')
		.data(nodes, function (node) { return node.id })

	nodeElements.exit().remove()

	var nodeEnter = nodeElements
		.enter()
		.append('circle')
		.attr('r', function (node) {
			var balance = (discoveredAddresses.has(node.id) ? discoveredAddresses.get(node.id)["final_balance"] : estimatedAddreses.get(node.id)) / 100000000.0
			return Math.log(Math.max(1, balance)) * 10 + 10
		})
		.attr('id', function (node) { ; return 'node_' + node.id })
		.attr('fill', function (node) {

			// its a wallet
			if (node.id in jsonList) {
				return 'rgba(0, 255, 0, 1)'
			}
			// its malicious
			else if (node.id in addressTags) {
				return 'rgba(255, 0, 0, 1)'
			}
			else {
				return 'rgba(127, 127, 127, 0.85)'
			}

		})
		.style('cursor', 'pointer')
		.call(dragDrop)
		.on('click', selectNode)
		.on("mouseover", function (d) {
			var balance = (discoveredAddresses.has(d.id) ? discoveredAddresses.get(d.id)["final_balance"] : estimatedAddreses.has(d.id) ? estimatedAddreses.get(d.id) : 0) / 100000000.0

			tooltip.select('#tooltip-title').html(d.label)
			tooltip.select('#tooltip-value').html((!discoveredAddresses.has(d.id) ? "Estimated: " : "") + "<b>" + balance.toLocaleString() + " BTC </b> (" + (balance * dollarsToBitcoin).formatMoney(2, '.', ',') + " USD)")
			tooltip.select('#tooltip-hash').html(linkedAddresses.get(d.id)["hash"]);
			tooltip.select('#tooltip-hash').style('font-size', '10px'); 


			if (taintedAddresses.has(d.id)) {
				var taintedness = taintedAddresses.get(d.id)
				tooltip.select('#tooltip-value').html(tooltip.select('#tooltip-value').html() +
					(taintedness["poison"] ? "<br />Poisoned" : "") +
					(taintedness["haircut"] > 0 ? "<br />Haircut: " + (taintedness["haircut"] * 100).toFixed(3) + "%" : "") +
					(taintedness["fifo"] > 0 ? "<br />LIFO: " + (taintedness["fifo"] / 100000000.0).toLocaleString() + " BTC" : "")
				)
			}

			tooltip.select('#tooltip-allcount').html(linkedAddresses.get(d.id)["out"].size + linkedAddresses.get(d.id)["in"].size)
			tooltip.select('#tooltip-outcount').html(linkedAddresses.get(d.id)["out"].size)
			tooltip.select('#tooltip-incount').html(linkedAddresses.get(d.id)["in"].size)

			var tx_log = "";

			linkedAddresses.get(d.id)["all"].forEach(function (value, key, map) {
				if (linkedAddresses.get(d.id)["out"].has(value['hash'])) {
					for (var i = 0; i < value['out'].length; i++) {
						var y = value['out'][i]

						var txt = '<b>' + (y['value'] / 100000000.0) + '</b> ';
						tx_log += "<button style='width: 100%; margin: 2px;' class=\"btn waves-effect waves-light red\" onclick=\"traceTransactionOut('" + d.id + "', '" + value["hash"] + "'," + i + ")\" title=\"Trace\">" +
							"<i class=\"material-icons left\">keyboard_arrow_left</i> " + txt + " (" + ("addr" in y ? y['addr'].trunc(10) : "???") + ")</button><br />";
					}
				} else {
					for (var i = 0; i < value['out'].length; i++) {
						var y = value['out'][i]
						var address = y['addr'];
						if (address === d.label) {
							var txt = '<b>' + (y['value'] / 100000000.0) + '</b> ';
							tx_log += "<button style='width: 100%; margin: 2px;' class=\"btn waves-effect waves-light\" onclick=\"traceTransactionIn('" + d.id + "', '" + value["hash"] + "'," + i + ")\" title=\"Trace\">" +
								"<i class=\"material-icons left\">keyboard_arrow_right</i> " + txt.trunc(10) + " (" + address.trunc(10) + ")</button><br />";
						}
					}
				}
			});

			tooltip.select('#tooltip-log').html(tx_log)
			tooltip.style("left", (d3.event.pageX + 15) + "px").style("top", (d3.event.pageY - 28) + "px")
			tooltipActive = true
			d3.selectAll(".connects_" + d.id).attr('opacity', '1')
			tooltip.style("display", "block")
		})
		.on("mouseout", function (d) {
			tooltipActive = false
			setTimeout(function () {
				if (!tooltipActive) tooltip.style("display", "none")
			}, 500)
			d3.selectAll(".connects_" + d.id).attr('opacity', '0.25')
		})

	nodeElements = nodeEnter.merge(nodeElements)
}

document.getElementById('tooltip').addEventListener("mouseenter", function () {
	tooltipActive = true
})
document.getElementById('tooltip').addEventListener("mouseleave", function () {
	tooltipActive = false
})

function KeyPress(e) {
	var evtobj = window.event ? event : e
	if (evtobj.keyCode == 84 && evtobj.shiftKey) toggleTooltip();
}

document.onkeydown = KeyPress;

function toggleTooltip() {
	var tooltip = document.getElementById('tooltip');
	if (tooltip.style.visibility == 'hidden') {
		tooltip.style.visibility = 'visible';
	} else {
		tooltip.style.visibility = 'hidden';
	}

}

function updateSimulation() {
	updateGraph()

	simulation.nodes(nodes).on('tick', function () {
		nodeElements
			.attr('cx', function (node) { return node.x })
			.attr('cy', function (node) { return node.y })
		linkElements
			.attr('x1', function (link) { return link.source.x })
			.attr('y1', function (link) { return link.source.y })
			.attr('x2', function (link) { return link.target.x })
			.attr('y2', function (link) { return link.target.y })
	})
	simulation.force('link').links(links)
	simulation.alphaTarget(0.7).restart()
}

updateSimulation()
